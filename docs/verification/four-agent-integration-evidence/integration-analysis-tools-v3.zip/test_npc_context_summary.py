"""Offline coverage counters: first retained contexts and sampled decision state."""
import unittest
import json
import tempfile
from pathlib import Path

from summarize_integration import npc_summary, summarize


NPC = "npc.audit"


def request(ordinal=0, identifier="decision-a", minute=720, step=1, **fields):
    return ({"callOrdinal": ordinal, "dispatchTick": ordinal, "dispatchRealSeconds": ordinal / 2},
        {"npcId": NPC, "decisionId": identifier, "gameTotalMinutes": minute,
            "step": step, "worldRunId": "world-a", **fields})


def timeline(minute=720, **flags):
    return {"gameMinutes": minute, "tick": 1, "worldRunId": "world-a",
        "residents": [{"npcId": NPC, **flags}]}


class NpcContextSummaryTests(unittest.TestCase):
    def test_correction_does_not_count_the_same_decision_or_trigger_twice(self):
        initial = request(persona="Initial persona", triggers=[{"kind": "WorldRebuilt"}, {"kind": "WorldRebuilt"}],
            social={"memories": [{"kind": "meeting.invited"}]})
        correction = request(1, step=2, persona="Later context", triggers=[{"kind": "WorldRebuilt"}],
            social={"memories": [1, 2, 3]})
        result = npc_summary(NPC, [correction, initial], [], [], [])
        day = result["days"]["D1"]
        self.assertEqual(day["dispatches"], 2)
        context = day["firstRetainedRequestContexts"]
        self.assertEqual(context["dispatchedDecisionN"], 1)
        self.assertEqual(context["decisionsWithTriggerKind"], {"WorldRebuilt": 1})
        self.assertEqual(context["persona"]["stringValues"], ["Initial persona"])
        self.assertEqual(context["socialMemories"]["maxCount"], 1)
        self.assertEqual(context["sources"][0]["callOrdinal"], 0)
        self.assertEqual(context["sources"][0]["traceCallIndex"], 1)

    def test_rebuilt_world_records_new_decision_on_its_game_day(self):
        first = request(persona="Mina", triggers=[{"kind": "WorldRebuilt"}], social={"memories": []})
        rebuilt = request(1, "decision-b", 2160, persona="Mina", worldRunId="world-b",
            triggers=[{"kind": "WorldRebuilt"}], social={"memories": [1, 2]})
        samples = [timeline(hasPending=True, hasWaitingTurn=False, hasCurrent=False),
            timeline(2160, hasPending=False, hasWaitingTurn=True, hasCurrent=True),
            timeline(2161, hasPending=False, hasWaitingTurn=False, hasCurrent=None)]
        samples[1]["worldRunId"] = samples[2]["worldRunId"] = "world-b"
        result = npc_summary(NPC, [first, rebuilt], [], samples, [])
        for day in ("D1", "D2"):
            self.assertEqual(result["days"][day]["firstRetainedRequestContexts"]["decisionsWithTriggerKind"], {"WorldRebuilt": 1})
        observed = result["days"]["D2"]["timelineStateObservations"]
        self.assertEqual(observed["rowN"], 2)
        self.assertEqual(observed["hasWaitingTurn"], {"trueN": 1, "falseN": 1, "unknownN": 0})
        self.assertEqual(observed["hasCurrent"], {"trueN": 1, "falseN": 0, "unknownN": 1})
        self.assertEqual(observed["firstSample"]["timelineRecordIndex"], 1)
        self.assertEqual(observed["lastSample"]["timelineRecordIndex"], 2)

    def test_unavailable_trace_and_timeline_remain_unknown(self):
        result = npc_summary(NPC, None, None, None, None)
        self.assertIsNone(result["timelineSamples"])
        for day in ("D1", "D2"):
            context = result["days"][day]["firstRetainedRequestContexts"]
            self.assertIsNone(context["dispatchedDecisionN"])
            self.assertIsNone(context["persona"]["nonemptyN"])
            self.assertIsNone(context["decisionsWithTriggerKind"])
            self.assertIsNone(context["socialMemories"]["arrayKnownN"])
            self.assertIsNone(result["days"][day]["timelineStateObservations"]["hasPending"]["trueN"])

    def test_known_empty_context_fields_differ_from_missing_values(self):
        missing = request(persona=None, triggers=None, social=None)
        empty = request(1, "decision-b", persona="", triggers=[], social={"memories": []})
        result = npc_summary(NPC, [missing, empty], [], [timeline(hasPending="true")], [])
        context = result["days"]["D1"]["firstRetainedRequestContexts"]
        self.assertEqual(context["persona"], {"stringKnownN": 1, "unknownN": 1, "nonemptyN": 0, "stringValues": [""]})
        self.assertEqual(context["socialMemories"], {"arrayKnownN": 1, "unknownN": 1, "nonemptyN": 0, "maxCount": 0})
        self.assertEqual(context["triggerArrayKnownN"], 1)
        self.assertEqual(context["triggerArrayUnknownN"], 1)
        self.assertEqual(result["days"]["D1"]["timelineStateObservations"]["hasPending"]["unknownN"], 1)

    def test_missing_resident_record_counts_as_unknown_observation(self):
        sample = timeline()
        sample["residents"] = None
        result = npc_summary(NPC, [], [], [sample], [])
        observed = result["days"]["D1"]["timelineStateObservations"]
        self.assertEqual(observed["rowN"], 1)
        self.assertEqual(observed["residentRecordN"], 0)
        self.assertEqual(observed["hasCurrent"]["unknownN"], 1)

    def test_missing_ids_do_not_merge_unrelated_requests(self):
        result = npc_summary(NPC, [request(identifier=None), request(1, identifier=None)], [], [], [])
        self.assertEqual(result["days"]["D1"]["firstRetainedRequestContexts"]["dispatchedDecisionN"], 2)

    def test_resumed_first_request_is_explicit_and_not_counted_again_next_day(self):
        first = request(step=2, triggers=[{"kind": "ActivityEnded"}])
        following = request(1, minute=2160, step=3, triggers=[{"kind": "ActivityEnded"}])
        result = npc_summary(NPC, [first, following], [], None, [])
        context = result["days"]["D1"]["firstRetainedRequestContexts"]
        self.assertEqual(context["step1N"], 0)
        self.assertEqual(context["resumedOrUnknownFirstStepN"], 1)
        self.assertEqual(context["decisionsWithTriggerKind"], {"ActivityEnded": 1})
        self.assertEqual(result["days"]["D2"]["firstRetainedRequestContexts"]["dispatchedDecisionN"], 0)
        self.assertIsNone(result["days"]["D1"]["timelineStateObservations"]["rowN"])

    def test_unstarted_world_preserves_missing_trace_and_timeline_in_full_summary(self):
        with tempfile.TemporaryDirectory(prefix="npc-summary-fixture-", dir=Path(__file__).parent) as name:
            root = Path(name)
            (root / "plan.json").write_text(json.dumps({"worlds": [{"ordinal": 1, "worldId": "fixture"}]}))
            (root / "status.json").write_text(json.dumps({"worlds": [{"worldId": "fixture", "status": "not_started"}]}))
            result = summarize(root)
        world = result["worlds"][0]
        self.assertIsNone(world["timelineSamples"])
        for npc in world["npcs"]:
            self.assertIsNone(npc["timelineSamples"])
            self.assertIsNone(npc["days"]["D1"]["firstRetainedRequestContexts"]["dispatchedDecisionN"])
            self.assertIsNone(npc["days"]["D2"]["timelineStateObservations"]["rowN"])


if __name__ == "__main__":
    unittest.main()
