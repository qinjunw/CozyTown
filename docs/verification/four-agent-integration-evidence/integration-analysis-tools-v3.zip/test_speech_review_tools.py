import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import subprocess
import sys

from validate_speech_reviews import validate
from aggregate_speech_reviews import aggregate


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


class ReviewToolsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.pack_path = self.root / "blind.json"
        self.review_path = self.root / "review.json"
        self.pack = {"schemaVersion": 1, "packId": "fixture-pack", "samples": [
            {"sampleId": "sample-a", "question": None, "targetFactIds": [],
             "context": {"observation": {"facts": [{"factId": "fish", "value": 2}]}},
             "committedTranscript": {"text": "🐟我有两条鱼。", "gameMinutes": 740}},
            {"sampleId": "sample-b", "question": None, "targetFactIds": [],
             "context": {}, "committedTranscript": {"text": "你好。", "gameMinutes": 741}}]}
        self.review = {"schemaVersion": 1, "packId": "fixture-pack", "samples": [
            {"sampleId": "sample-a", "committedText": "🐟我有两条鱼。", "claims": [
                {"claimId": "a", "quote": "我有两条鱼", "start": 1, "end": 6,
                 "verdict": "unsupported", "evidenceRefs": [
                     {"pointer": "/samples/0/context/observation/facts/0", "factId": "fish"}]}]},
            {"sampleId": "sample-b", "committedText": "你好。", "claims": [
                {"claimId": "b", "quote": "你好。", "start": 0, "end": 3,
                 "verdict": "not_factual", "evidenceRefs": []}]}]}
        for sample in self.review["samples"]:
            for dimension in ("relevance", "refusal", "repetition", "persona"):
                sample[dimension] = {"status": "fixture", "evidenceRefs": []}
            sample["qaCoverage"] = {"status": "N/A"}

    def tearDown(self):
        self.temporary.cleanup()

    def run_validator(self):
        raw = encoded(self.pack)
        self.pack_path.write_bytes(raw)
        self.review["inputSha256"] = hashlib.sha256(raw).hexdigest()
        self.review_path.write_bytes(encoded(self.review))
        return validate(self.pack_path, self.review_path)

    def test_unicode_quotes_and_declared_verdicts_produce_separate_denominators(self):
        report = self.run_validator()
        self.assertTrue(report["valid"], report["errors"])
        self.assertEqual({"n": 1, "N": 1, "rate": 1.0}, report["statistics"]["assertions"]["clearIssues"])
        self.assertEqual({"n": 1, "N": 2, "rate": 0.5}, report["statistics"]["utterances"]["clearIssues"])
        self.assertEqual(1, report["statistics"]["noFactualUtterances"])

    def test_invalid_coverage_quotes_and_evidence_are_reported_without_editing_inputs(self):
        cases = {
            "duplicate_sample": lambda d: d["samples"].append(copy.deepcopy(d["samples"][0])),
            "missing_sample": lambda d: d["samples"].pop(),
            "changed_text": lambda d: d["samples"][0].update(committedText="different"),
            "utf16_offset": lambda d: d["samples"][0]["claims"][0].update(start=2, end=7),
            "unknown_verdict": lambda d: d["samples"][0]["claims"][0].update(verdict="looks_good"),
            "wrong_fact": lambda d: d["samples"][0]["claims"][0]["evidenceRefs"][0].update(factId="missing"),
            "missing_pointer": lambda d: d["samples"][0]["claims"][0]["evidenceRefs"][0].update(pointer="/samples/0/context/missing"),
            "other_sample": lambda d: d["samples"][0]["relevance"].update(evidenceRefs=[{"pointer": "/samples/1/context"}]),
            "wrong_pack": lambda d: d.update(packId="other"),
            "unfinished_review": lambda d: d.update(completed=False),
            "wrong_factual_flag": lambda d: d["samples"][0]["claims"][0].update(includedInFactualDenominator=False),
        }
        original = copy.deepcopy(self.review)
        for name, mutate in cases.items():
            with self.subTest(name=name):
                self.review = copy.deepcopy(original)
                mutate(self.review)
                report = self.run_validator()
                self.assertFalse(report["valid"], name)
                self.assertTrue(report["errors"], name)

    def test_sha_mismatch_is_rejected(self):
        self.run_validator()
        self.pack_path.write_bytes(self.pack_path.read_bytes() + b" ")
        self.assertFalse(validate(self.pack_path, self.review_path)["valid"])

    def test_missing_evidence_is_retained_separately_from_no_factual_speech(self):
        self.pack["samples"][0]["committedTranscript"]["text"] = None
        sample = self.review["samples"][0]
        sample["committedText"] = None
        sample["claims"] = [{"claimId": "a", "quote": None, "start": None, "end": None,
                            "verdict": "insufficient_review_evidence", "evidenceRefs": []}]
        report = self.run_validator()
        self.assertTrue(report["valid"], report["errors"])
        self.assertEqual(1, report["statistics"]["reviewEvidenceMissingUnits"])
        self.assertEqual(1, report["statistics"]["noFactualUtterances"])
        self.assertEqual(0, report["statistics"]["factualAssertions"])

    def aggregate_fixture(self):
        self.run_validator()
        self.review["adjudicatorId"] = "fixture-adjudicator"
        self.review["reviewers"] = {}
        for name in ("a", "b"):
            path = self.root / (name + ".json")
            raw = self.review_path.read_bytes()
            path.write_bytes(raw)
            self.review["reviewers"][name] = {"file": path.name, "sha256": hashlib.sha256(raw).hexdigest()}
        self.review_path.write_bytes(encoded(self.review))
        identity = {"schemaVersion": 1, "packId": "fixture-pack", "blindPackSha256": self.review["inputSha256"],
            "study": {"studyId": "fixture", "stage": "fixed", "sourceRevision": "fixture-v1"},
            "worldDenominator": [], "samples": [], "sourceFiles": {"plan.json": {"sha256": "a" * 64, "bytes": 1}},
            "denominator": {"plannedWorlds": 2, "sampleRows": 2, "sourceSpeechRows": 2}}
        for index, sample in enumerate(self.pack["samples"]):
            world = "world" + str(index)
            identity["worldDenominator"].append({"worldId": world, "status": "completed", "ordinal": index + 1})
            row = {"sampleId": sample["sampleId"], "worldId": world, "speechMode": "F" if index == 0 else "S",
                   "npcId": "ren" if index == 0 else "mina", "scenarioId": "available", "speechPath": world + "/speech.json",
                   "manifestPath": world + "/manifest.json"}
            identity["samples"].append(row)
            for field in ("speechPath", "manifestPath"):
                identity["sourceFiles"][row[field]] = {"sha256": "b" * 64, "bytes": 2}
        self.identity_path = self.root / "identity.json"
        self.identity_path.write_bytes(encoded(identity))
        return identity

    def test_exact_union_preserves_factual_and_utterance_denominators_per_arm(self):
        self.aggregate_fixture()
        report = aggregate(self.pack_path, self.identity_path,
                           [(self.pack_path, self.identity_path, self.review_path)])
        self.assertTrue(report["valid"], report["errors"])
        self.assertEqual(2, report["coverage"]["finalSampleRows"])
        self.assertEqual({"n": 1, "N": 1, "rate": 1.0}, report["groups"]["bySpeechMode"]["F"]["assertions"]["clearIssues"])
        self.assertEqual({"n": 0, "N": 0, "rate": None}, report["groups"]["bySpeechMode"]["S"]["assertions"]["clearIssues"])
        self.assertEqual(1, report["groups"]["bySpeechMode"]["S"]["noFactualUtterances"])

    def test_aggregate_rejects_missing_duplicate_running_or_changed_provenance(self):
        identity = self.aggregate_fixture()
        original_review = self.review_path.read_bytes()
        batch = (self.pack_path, self.identity_path, self.review_path)
        cases = {
            "missing_batch": lambda: [],
            "duplicate_batch": lambda: [batch, batch],
            "running_final": lambda: self.changed_identity(identity, {"worldDenominator": [
                {"worldId": "world0", "status": "running"}, {"worldId": "world1", "status": "completed"}]}, batch),
            "changed_mapping_hash": lambda: self.changed_identity(identity, {"blindPackSha256": "0" * 64}, batch),
            "missing_identity_row": lambda: self.changed_identity(identity, {"samples": identity["samples"][:1]}, batch),
            "changed_reviewer": lambda: self.changed_reviewer(batch),
        }
        for name, mutate in cases.items():
            with self.subTest(name=name):
                self.identity_path.write_bytes(encoded(identity))
                self.review_path.write_bytes(original_review)
                report = aggregate(self.pack_path, self.identity_path, mutate())
                self.assertFalse(report["valid"], name)
                self.assertIsNone(report["groups"], name)
                self.assertTrue(report["errors"], name)

    def changed_identity(self, original, change, batch):
        self.identity_path.write_bytes(encoded(dict(original, **change)))
        return [batch]

    def changed_reviewer(self, batch):
        review = json.loads(self.review_path.read_bytes())
        review["reviewers"]["a"]["sha256"] = "0" * 64
        self.review_path.write_bytes(encoded(review))
        return [batch]

    def incremental_fixture(self):
        identity = self.aggregate_fixture()
        source_pack_path = self.root / "source-blind.json"
        source_identity_path = self.root / "source-identity.json"
        source_pack_path.write_bytes(self.pack_path.read_bytes())
        source_identity_path.write_bytes(self.identity_path.read_bytes())
        self.pack.update(packId="incremental", sourcePackId="fixture-pack", isIncrementalBatch=True)
        self.pack_path.write_bytes(encoded(self.pack))
        batch_sha = hashlib.sha256(self.pack_path.read_bytes()).hexdigest()
        self.review.update(packId="incremental", inputSha256=batch_sha)
        for name, metadata in self.review["reviewers"].items():
            raw_review = json.loads((self.root / metadata["file"]).read_bytes())
            raw_review.update(packId="incremental", inputSha256=batch_sha)
            raw = encoded(raw_review)
            (self.root / metadata["file"]).write_bytes(raw)
            metadata["sha256"] = hashlib.sha256(raw).hexdigest()
        self.review_path.write_bytes(encoded(self.review))
        identity.update(packId="incremental", sourcePackId="fixture-pack", isIncrementalBatch=True,
                        blindPackSha256=batch_sha, sourceBlindSha256=hashlib.sha256(source_pack_path.read_bytes()).hexdigest(),
                        sourceIdentitySha256=hashlib.sha256(source_identity_path.read_bytes()).hexdigest(),
                        sourcePacketFiles={"blind": source_pack_path.name, "identity": source_identity_path.name},
                        previousPacks=[])
        self.identity_path.write_bytes(encoded(identity))
        return source_pack_path, source_identity_path, identity

    def test_incremental_source_chain_is_verified_before_grouping(self):
        source_pack, source_identity, identity = self.incremental_fixture()
        batch = (self.pack_path, self.identity_path, self.review_path)
        self.assertTrue(aggregate(source_pack, source_identity, [batch])["valid"])
        cases = {
            "source_blind_sha": {"sourceBlindSha256": "0" * 64},
            "source_identity_sha": {"sourceIdentitySha256": "0" * 64},
            "source_pack_id": {"sourcePackId": "wrong"},
            "outside_source_file": {"sourcePacketFiles": {"blind": "../outside.json", "identity": "source-identity.json"}},
            "unprovided_previous": {"previousPacks": [{"fileName": "missing.json", "sha256": "0" * 64, "packId": "missing"}]},
        }
        for name, changes in cases.items():
            with self.subTest(name=name):
                self.identity_path.write_bytes(encoded(dict(identity, **changes)))
                report = aggregate(source_pack, source_identity, [batch])
                self.assertFalse(report["valid"], name)
                self.assertIsNone(report["statistics"], name)

    def test_malformed_dimension_reports_invalid_instead_of_crashing(self):
        self.review["samples"][0]["persona"]["status"] = ["invalid"]
        report = self.run_validator()
        self.assertFalse(report["valid"])

    def test_alias_schema_and_escaped_fact_child_pointer_are_supported(self):
        self.pack["samples"][0]["context"]["a/b~c"] = {"factId": "nested", "value": 2}
        self.review["samples"][0]["claims"][0]["evidenceRefs"] = [
            {"pointer": "/samples/0/context/a~1b~0c/value", "factId": "nested"}]
        for sample in self.review["samples"]:
            sample["text"] = sample.pop("committedText")
            sample["relevance"]["questionCoverage"] = sample.pop("qaCoverage")["status"]
        self.run_validator()
        self.review["inputSHA256"] = self.review.pop("inputSha256")
        self.review_path.write_bytes(encoded(self.review))
        self.assertTrue(validate(self.pack_path, self.review_path)["valid"])

    def test_cli_refuses_output_overwrite_and_preserves_input_bytes(self):
        self.run_validator()
        original = (self.pack_path.read_bytes(), self.review_path.read_bytes())
        output = self.root / "validation.json"
        command = [sys.executable, str(Path(__file__).with_name("validate_speech_reviews.py")),
                   "--pack", str(self.pack_path), "--review", str(self.review_path), "--output", str(output)]
        first = subprocess.run(command, capture_output=True)
        self.assertEqual(0, first.returncode, first.stderr)
        written = output.read_bytes()
        second = subprocess.run(command, capture_output=True)
        self.assertNotEqual(0, second.returncode)
        self.assertEqual(written, output.read_bytes())
        self.assertEqual(original, (self.pack_path.read_bytes(), self.review_path.read_bytes()))

    def test_aggregate_cli_writes_group_counts_and_keeps_empty_arm_explicit(self):
        identity = self.aggregate_fixture()
        for row in identity["samples"]:
            row["speechMode"] = "F"
        self.identity_path.write_bytes(encoded(identity))
        output = self.root / "aggregate.json"
        process = subprocess.run([sys.executable, str(Path(__file__).with_name("aggregate_speech_reviews.py")),
                                  "--final-pack", str(self.pack_path), "--final-identity", str(self.identity_path),
                                  "--batch", str(self.pack_path), str(self.identity_path), str(self.review_path),
                                  "--output", str(output)], capture_output=True)
        self.assertEqual(0, process.returncode, process.stderr)
        report = json.loads(output.read_bytes())
        self.assertEqual(2, report["groups"]["bySpeechMode"]["F"]["reviewedUtterances"])
        self.assertEqual(0, report["groups"]["bySpeechMode"]["S"]["reviewedUtterances"])


if __name__ == "__main__":
    unittest.main()
