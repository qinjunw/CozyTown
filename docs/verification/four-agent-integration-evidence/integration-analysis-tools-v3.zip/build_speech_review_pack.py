"""Build a speech-only review packet and a separate withheld identity mapping."""

import argparse
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from summarize_integration import Evidence, embedded


def finite(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def review_context(value):
    if isinstance(value, dict):
        excluded = {"worldRunId", "expression", "mode", "speechMode", "runMode", "providerEndpoint", "sourceRevision"}
        return {key: review_context(item) for key, item in value.items() if key not in excluded}
    if isinstance(value, list):
        return [review_context(item) for item in value]
    return value


def sample_id(experiment_id, outcome_index, world_id, row_index):
    if isinstance(experiment_id, str) and experiment_id and type(outcome_index) is int and outcome_index >= 0:
        basis = experiment_id + ":" + str(outcome_index)
    else:
        basis = "invalid-association:" + world_id + ":" + str(row_index)
    return "speech-" + hashlib.sha256(basis.encode("utf-8")).hexdigest()


def make_sample(row, row_index, speech, manifest, world):
    index = row.get("outcomeIndex")
    experiment = speech.get("experimentId")
    identifier = sample_id(experiment, index, world["worldId"], row_index)
    issues = []
    if not isinstance(experiment, str) or not experiment or experiment != manifest.get("experimentId"):
        issues.append("association.experiment_mismatch")
    for key in ("pairId", "scenarioId", "speechMode", "runMode"):
        if manifest.get(key) != world.get(key):
            issues.append("association.plan_binding_mismatch")
            break
    results = manifest.get("results")
    outcome = results[index] if isinstance(results, list) and type(index) is int and 0 <= index < len(results) else None
    if not isinstance(outcome, dict) or outcome.get("code") != "meeting.say":
        issues.append("association.accepted_speech_missing")
        outcome = {}
    request = embedded(outcome.get("requestJson"))
    if request is None:
        issues.append("association.request_missing")
        request = {}
    for key in ("worldRunId", "decisionId", "npcId"):
        if not isinstance(row.get(key), str) or not row[key] or row[key] != outcome.get(key) or row[key] != request.get(key):
            issues.append("association." + key + "_mismatch")
    verified = not issues
    execution = embedded(outcome.get("executionObservationJson"))
    if verified and execution is not None and execution.get("observerId") != row.get("npcId"):
        issues.append("association.execution_observer_mismatch")
        verified = False
    context = None if not verified else review_context({
        "persona": request.get("persona"), "social": request.get("social"),
        "observation": request.get("observation") if request.get("hasObservation") is True else None,
        "selfAssessment": request.get("selfAssessment") if request.get("hasSelfAssessment") is True else None,
        "executionObservation": execution})
    committed = (verified and row.get("source") == "committed_transcript"
                 and isinstance(row.get("text"), str) and bool(row["text"].strip())
                 and finite(row.get("gameMinutes")) and not row.get("missingReason"))
    missing_reason = None if committed else (row.get("missingReason") or
        ("speech.association_invalid" if not verified else "speech.committed_text_missing"))
    sample = {"sampleId": identifier, "question": None, "targetFactIds": [],
        "association": "verified" if verified else "invalid", "associationIssues": issues,
        "context": context, "committedTranscript": {
            "text": row.get("text") if committed else None,
            "gameMinutes": row.get("gameMinutes") if verified and finite(row.get("gameMinutes")) else None,
            "source": "committed_transcript" if committed else None, "missingReason": missing_reason}}
    identity = {key: world.get(key) for key in ("worldId", "ordinal", "pairId", "repetition", "scenarioId", "speechMode", "runMode")}
    identity.update({"sampleId": identifier, "experimentId": experiment, "outcomeIndex": index,
        "speechRowIndex": row_index, "worldRunId": row.get("worldRunId"), "decisionId": row.get("decisionId"),
        "npcId": row.get("npcId"), "associationIssues": issues})
    return sample, identity


def build(study):
    evidence = Evidence(study)
    plan = evidence.load("plan.json")
    status = evidence.load("status.json") or {}
    if not isinstance(plan, dict) or not isinstance(plan.get("worlds"), list):
        raise ValueError("A registered study plan with its complete world denominator is required.")
    samples, identities, world_counts = [], [], []
    known_accepted, accepted_without_rows = 0, 0
    available_manifest_count = 0
    for world in plan["worlds"]:
        ordinal, world_id = world.get("ordinal"), world.get("worldId")
        if type(ordinal) is not int or not isinstance(world_id, str) or not world_id.isalnum():
            raise ValueError("Registered world identities must match the coordinator directory convention.")
        directory = f"{ordinal:02}-{world_id}"
        speech_path, manifest_path = directory + "/speech.json", directory + "/package/manifest.json"
        speech, manifest = evidence.load(speech_path), evidence.load(manifest_path)
        rows = speech.get("rows") if isinstance(speech, dict) else None
        results = manifest.get("results") if isinstance(manifest, dict) else None
        accepted = [index for index, result in enumerate(results) if isinstance(result, dict) and result.get("code") == "meeting.say"] if isinstance(results, list) else None
        if accepted is not None:
            available_manifest_count += 1
            known_accepted += len(accepted)
            indices = {row.get("outcomeIndex") for row in rows or [] if isinstance(row, dict)}
            accepted_without_rows += sum(index not in indices for index in accepted)
        state = next((item.get("status") for item in status.get("worlds", []) if item.get("worldId") == world_id), "unknown")
        world_counts.append({"worldId": world_id, "ordinal": ordinal, "status": state,
            "speechRows": len(rows) if isinstance(rows, list) else None,
            "declaredAcceptedSpeechOutcomes": speech.get("acceptedSpeechOutcomes") if isinstance(speech, dict) else None,
            "acceptedSpeechOutcomesInManifest": None if accepted is None else len(accepted)})
        for row_index, row in enumerate(rows or []):
            sample, identity = make_sample(row if isinstance(row, dict) else {}, row_index,
                speech, manifest if isinstance(manifest, dict) else {}, world)
            samples.append(sample)
            identities.append(identity | {"speechPath": speech_path, "manifestPath": manifest_path})
    samples.sort(key=lambda sample: sample["sampleId"])
    generated = datetime.now(timezone.utc).isoformat()
    counts = {"plannedWorlds": len(plan["worlds"]),
        "worldsWithSpeechRowsField": sum(world["speechRows"] is not None for world in world_counts),
        "sourceSpeechRows": len(samples), "sampleRows": len(samples),
        "uniqueSampleIds": len({sample["sampleId"] for sample in samples}),
        "verifiedAssociations": sum(sample["association"] == "verified" for sample in samples),
        "invalidAssociations": sum(sample["association"] != "verified" for sample in samples),
        "committedTranscriptRows": sum(sample["committedTranscript"]["text"] is not None for sample in samples),
        "missingTranscriptRows": sum(sample["committedTranscript"]["text"] is None for sample in samples),
        "availableManifestOutcomeCollections": available_manifest_count,
        "acceptedSpeechOutcomesInAvailableManifests": known_accepted if available_manifest_count else None,
        "acceptedOutcomesWithoutSpeechRows": accepted_without_rows if available_manifest_count else None,
        "sourceReadWarnings": len(evidence.warnings)}
    pack_id = hashlib.sha256((plan.get("studyId", "") + ":" + json.dumps(evidence.files, sort_keys=True)).encode("utf-8")).hexdigest()
    blind = {"schemaVersion": 1, "packId": pack_id, "generatedAtUtc": generated,
        "evidenceUse": "Fixed-client workflow verification only; these statements are not live-model evidence." if plan.get("stage") == "fixed"
            else "Unscored retained study evidence; this packet contains no reviewer verdicts.",
        "reviewInstructions": [
            "Each reviewer receives only this packet and independently records judgments by sampleId.",
            "All retained speech rows are included, including missing or invalid associations. The denominator is not a count of successful worlds.",
            "Association verification checks retained identifiers and an accepted meeting.say result; it does not certify factual accuracy.",
            "Context comes only from the matched request and execution observation; transcript text comes only from committed speech evidence.",
            "Missing transcript text is not reconstructed from candidate replies. Questions and target facts are intentionally unassigned.",
            "Expression-arm labels are withheld, but structured-fact sentence patterns may reveal the S arm; full blinding is not guaranteed."],
        "denominator": counts, "samples": samples}
    identity = {"schemaVersion": 1, "packId": pack_id, "generatedAtUtc": generated,
        "distribution": "Withhold this mapping from both independent reviewers.",
        "study": {key: plan.get(key) for key in ("studyId", "stage", "sourceRevision", "evaluationPlanReference", "expressionContractVersion")},
        "worldStatusCounts": dict(Counter(world["status"] for world in world_counts)),
        "worldDenominator": world_counts, "denominator": counts,
        "samples": identities, "sourceFiles": evidence.files, "sourceReadWarnings": evidence.warnings}
    return blind, identity


def main():
    parser = argparse.ArgumentParser(description="Write a speech review packet and a separate withheld identity map.")
    parser.add_argument("--study", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--identity-output", required=True, type=Path)
    args = parser.parse_args()
    study, output, identity_output = args.study.resolve(), args.output.resolve(), args.identity_output.resolve()
    if output == identity_output or any(path.exists() or path.is_relative_to(study) for path in (output, identity_output)):
        parser.error("Choose two distinct new files outside the source study directory.")
    blind, identity = build(study)
    content = json.dumps(blind, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
    identity["blindPackSha256"] = hashlib.sha256(content.encode("utf-8")).hexdigest()
    for path in (output, identity_output):
        path.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(content)
    with identity_output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(identity, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
    print(json.dumps({"packId": blind["packId"], "denominator": blind["denominator"]}))


if __name__ == "__main__":
    main()
