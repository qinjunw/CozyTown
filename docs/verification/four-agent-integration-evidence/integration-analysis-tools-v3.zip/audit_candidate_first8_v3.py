"""Check completed-world metrics through isolated derived fixtures, without providers."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import summarize_candidate_latency as metrics
from summarize_integration import read_bytes
from test_candidate_metric_audit import summarize_fixture


ROOT = Path(__file__).parent
STUDY = ROOT / "integration-coordinated-live-20260920-a"
loaded = {}


def load(name, lines=False):
    raw = read_bytes(STUDY / name)
    loaded[name] = hashlib.sha256(raw).hexdigest()
    text = raw.decode("utf-8-sig")
    return [json.loads(line) for line in text.splitlines() if line.strip()] if lines else json.loads(text)


plan, status = load("plan.json"), load("status.json")
ledger = load("ledger.jsonl", True)
old = json.loads((ROOT / "integration-candidate-metric-audit-data.json").read_text(encoding="utf-8"))
rows, all_attempts, handling, protocol, parsed, continuations = [], [], Counter(), Counter(), Counter(), Counter()
for world in plan["worlds"][:8]:
    world_id = world["worldId"]
    status_row = next(row for row in status["worlds"] if row["worldId"] == world_id)
    assert status_row["status"] == "completed"
    name = f'{world["ordinal"]:02}-{world_id}'
    manifest = load(name + "/package/manifest.json")
    proxy = load(name + "/proxy.jsonl", True)
    events = [row for row in ledger if row.get("event") == "provider_started" and row.get("worldId") == world_id]
    calls, outcomes = manifest["trace"]["calls"], manifest["results"]
    trace_ids = {json.loads(call["requestJson"])["decisionId"] for call in calls}
    assert trace_ids == {row["decisionId"] for row in outcomes} == {row["decisionId"] for row in events}
    assert all(isinstance(identity, str) and identity.strip() for identity in trace_ids)
    assert len(events) == status_row["attemptedProviderCalls"] == len(proxy) == len(calls)
    # Only the fixture's external world key changes; request identity and retained records stay intact.
    result = summarize_fixture(calls, outcomes, "live", proxy,
        [{**event, "worldId": "fixtureworld"} for event in events],
        coordinator_attempts=status_row["attemptedProviderCalls"])
    observed = result["worlds"][0]
    counts = observed["metrics"]
    previous = next(row for row in old["worlds"] if row["worldId"] == world_id)
    assert counts["initiatedDecisionN"] == previous["decisionN"]
    assert counts["firstHostHandlingCounts"] == previous["firstHandling"]
    assert counts["finalHostAcceptedN"] == previous["finalAccepted"]
    assert counts["providerOnlyDecisionN"] == counts["outcomeOnlyDecisionN"] == counts["unidentifiedEvidenceRecordN"] == 0
    assert counts["decisionDenominatorComplete"] and observed["providerEvidenceCoverage"]["complete"]
    assert observed["allProviderAttemptMetrics"]["attemptN"] == len(events)
    assert observed["usage"]["totalTokens"]["unknownN"] == 0
    assert observed["usage"]["totalTokens"]["total"] is not None
    attempts = observed["providerAttemptDetails"]
    all_attempts.extend(attempts)
    handling.update(counts["firstHostHandlingCounts"])
    protocol.update(attempt["protocolValidation"] for attempt in attempts)
    parsed.update(attempt["jsonParse"] for attempt in attempts)
    continuations.update(attempt["continuationKind"] for attempt in attempts)
    rows.append({"ordinal": world["ordinal"], "worldId": world_id,
        "metrics": counts, "providerEvidenceCoverage": observed["providerEvidenceCoverage"],
        "allProviderAttemptMetrics": observed["allProviderAttemptMetrics"], "usage": observed["usage"]})

assert len(all_attempts) == 124
assert sum(row["metrics"]["initiatedDecisionN"] for row in rows) == 123
assert handling == Counter(accepted_terminal=80, rejected=42, no_response=1)
assert sum(row["metrics"]["finalHostAcceptedN"] for row in rows) == 81
assert parsed == Counter(json_object=124)
assert protocol == Counter(passed=121, rejected=3)
assert continuations == Counter(initial=123, candidate_correction=1)
for name, digest in loaded.items():
    if name not in ("status.json", "ledger.jsonl"):
        assert hashlib.sha256(read_bytes(STUDY / name)).hexdigest() == digest

result = {"scope": "Verification of completed worlds 1 through 8 only, using isolated derived one-world fixtures; not a final study summary. The fixture coordinator is finished and its external world key is replaced with fixtureworld; original study files are read only.",
    "generatedAtUtc": datetime.now(timezone.utc).isoformat(), "sourceRevision": plan["sourceRevision"],
    "studyStateAtRead": status["state"], "scriptSha256": hashlib.sha256(Path(metrics.__file__).read_bytes()).hexdigest(),
    "verifiedWorldN": len(rows), "decisionN": 123, "attemptN": 124, "firstHostHandlingCounts": dict(handling),
    "finalHostAcceptedN": 81, "allJsonParseCounts": dict(parsed), "allProtocolValidationCounts": dict(protocol),
    "continuationCounts": dict(continuations), "worlds": rows, "inputSha256": loaded}
output = ROOT / "integration-candidate-first8-v3-audit.json"
with output.open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(result, stream, ensure_ascii=False, allow_nan=False, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in result.items() if key not in ("scope", "worlds", "inputSha256")}, ensure_ascii=False))
