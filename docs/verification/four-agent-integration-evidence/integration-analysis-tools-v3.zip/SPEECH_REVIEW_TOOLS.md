# 离线台词评阅校验与聚合

这些脚本读取已经导出的盲包、独立评阅和裁决文件。脚本检查结构与来源，并复算既有 verdict 的数量；语义判断仍来自评阅与裁决。脚本不读取 study 目录，不调用 Unity、代理或模型。

## 单份评阅校验

在工具目录执行：

```powershell
python validate_speech_reviews.py --pack <batch-blind.json> --review <review.json> --output <new-validation.json>
```

`--output` 可省略，此时 JSON 写至 stdout。指定输出必须是新文件。

检查项：

- schema 1、packId 和盲包原始字节 SHA256；兼容 `inputSHA256` 与 `inputSha256`。
- sampleId 覆盖，无缺评、额外样本或重复；claimId 在同一报告内唯一。
- `text` 或 `committedText` 与提交后台词一致。已有 gameMinutes、inputPointer、inputSampleIndex 也要对应来源。
- 每条 claim 的 quote 等于 Python Unicode 字符切片 `text[start:end]`，右端不包含在内。缺失原文时，只允许显式 `insufficient_review_evidence` 单元使用 null quote/start/end。
- 递归检查 evidenceRefs，包括 readings、interpretations 和各维度中的引用。JSON pointer 必须能解析，且限定当前样本的 context；引用声明的 factId 及事实元数据与目标事实核对。
- 四项维度及问答覆盖具有状态。未登记 question/targetFactIds 时，问答覆盖必须为 `N/A`。

输出 schema 1 包含 `valid`、`errors`、`coverage`、`provenance`、`statisticsTrusted` 和 `statistics`。校验失败仍列出可复算数量，但 `statisticsTrusted=false`，不能作为已校验结果使用。

## 最终聚合

先由已有 `build_speech_review_pack.py` 从停止后的 study 导出完整来源包。聚合器只读取该导出包及评阅文件：

```powershell
python aggregate_speech_reviews.py --final-pack <complete-blind.json> --final-identity <complete-identity.json> --batch <batch-01-blind.json> <batch-01-identity.json> <batch-01-adjudicated.json> --batch <batch-02-blind.json> <batch-02-identity.json> <batch-02-adjudicated.json> --output <new-aggregate.json>
```

每一批使用一个 `--batch`。裁决文件必须显式标明 adjudicatorId，并保留两份独立评阅的文件名与 SHA256。评阅来源文件必须与裁决文件同目录，源快照文件必须与 batch identity 同目录；引用仅接受文件名。

聚合前检查：

1. 每份裁决和它引用的两份独立评阅通过单份校验；独立评阅文件 SHA256 与裁决元数据一致。
2. batch blind 和 identity 的样本对应，identity 中的 blind SHA256 与原始文件相符。
3. 增量批次引用的完整 source blind/identity SHA256、sourcePackId 和 previousPacks 与保留文件及显式输入相符。
4. 各批次中的样本内容、身份映射及 plan/speech/manifest 来源哈希与最终完整来源一致。
5. 所有批次样本的并集与最终来源 exact match，无重复、缺失或额外样本。最终包不能是增量包，也不能含 running 或未知世界状态；已中止批次的 not_started 世界保留在分母中。

输出保留 `worldDenominator`、`worldStatusCounts`、`sourceDenominator`、`finalProvenance`、`batches` 和 `sourceChain`。只有全部检查通过才生成总 `statistics` 和 `groups`；否则两者为 null。分组为 `bySpeechMode`、`byNpc`、`byScenario` 和三项组合的 `strata`。

来源哈希链核对的是导出文件及其中记录的原证据哈希。该工具不重新访问原 study，也不把 SHA256 当作外部数字签名。最终来源保留的缺失 transcript、缺少 speech row 和 sourceReadWarnings 仍需在实验报告中说明；样本覆盖通过不代表全部世界成功。

## 计数定义

`factualAssertions` 的 N 包含 supported、contradicted、unsupported、source_time_misuse、unauthorized、ambiguous；排除 not_factual 和 insufficient_review_evidence。未知 verdict 会使校验失败。

明确问题包括 contradicted、unsupported、source_time_misuse、unauthorized。歧义单列 ambiguous。保守并集为最终裁决的明确问题与 ambiguous 的并集，断言层面无重叠，台词层面按样本去重；不是把两名评阅者的分歧再次合并。

每组的 `assertions` 使用事实断言 N，`utterances` 使用该组已评阅台词 N，均输出 `{n,N,rate}`，N=0 时 rate=null。`noFactualUtterances` 排除原文缺失或有 insufficient_review_evidence 的样本。缺证单列 `reviewEvidenceMissingUnits` 和 `utterances.reviewEvidenceMissing`。

`dimensions` 只统计原始状态标签。semantic_topic_reuse 等标签不会自动转为“冗余问题”。未登记的问题不生成问答成功率。

两个工具的退出码均为：0 通过；1 内容校验失败；2 输入读取、解析或输出创建失败。输入与已有输出不覆盖。

## 本地验证

```powershell
python -m unittest test_speech_review_tools -v
```

测试使用临时 JSON，覆盖 Unicode（含非 BMP 字符）偏移、事实引用、A/B 字段差异、缺评/重复、缺证分母、来源哈希变化、增量链路、仍运行的最终包，以及 CLI 不覆盖输出和不改输入。
