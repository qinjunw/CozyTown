"""Regression checks for the ignored integration analysis, without Unity or providers."""
import json
from pathlib import Path
import tempfile
import unittest

import summarize_candidate_latency as metrics


def call(kind="reply", step=1, operation="wait", correction="", details=False):
    request = {"npcId": "npc.audit", "decisionId": "decision-a", "worldRunId": "world-a",
        "step": step, "candidateErrorCode": correction, "hasLocationDetails": details}
    trace = {"callOrdinal": step - 1, "requestJson": json.dumps(request),
        "responseJson": json.dumps({"operation": operation}) if kind == "reply" else "",
        "completionKind": kind, "hasCompletedRealSeconds": True,
        "completedRealSeconds": 1.25, "deliveryRealSeconds": 1.5,
        "dispatchRealSeconds": 0.5, "deliveryTick": 2,
        "cancellationTick": 1 if kind == "canceled" else -1}
    return trace, request


def outcome(code, calls=1, step=1):
    return {"decisionId": "decision-a", "npcId": "npc.audit", "code": code,
        "calls": calls, "requestJson": json.dumps({"step": step}),
        "startedRealSeconds": 0.5, "finishedRealSeconds": 1.5}


def summarize_fixture(calls, outcomes, stage="fixed", proxy_rows=(), events=(),
                      ledger_text_tail="", coordinator_attempts=None):
    with tempfile.TemporaryDirectory(prefix="candidate-metric-fixture-", dir=Path(__file__).parent) as name:
        root = Path(name)
        world = {"ordinal": 1, "worldId": "fixtureworld", "speechMode": "F"}
        directory = root / "01-fixtureworld" / "package"
        directory.mkdir(parents=True)
        (root / "plan.json").write_text(json.dumps({"stage": stage, "worlds": [world]}))
        coordinator_attempts = len(events) if coordinator_attempts is None else coordinator_attempts
        (root / "status.json").write_text(json.dumps({"state": "finished", "attemptedProviderCalls": coordinator_attempts,
            "worlds": [{"worldId": "fixtureworld", "status": "completed", "attemptedProviderCalls": coordinator_attempts}]}))
        (root / "ledger.jsonl").write_text("".join(json.dumps(event) + "\n" for event in events) + ledger_text_tail)
        (directory.parent / "proxy.jsonl").write_text("".join(json.dumps(row) + "\n" for row in proxy_rows))
        (directory / "manifest.json").write_text(json.dumps({"trace": {"calls": calls}, "results": outcomes}))
        return metrics.summarize(root)


def provider_event(request, number):
    return {**{key: request[key] for key in ("npcId", "decisionId", "step")},
        "event": "provider_started", "worldId": "fixtureworld", "providerCall": number,
        "worldProviderCall": number}


def proxy_record(request, status="passed", raw='{"operation":"wait"}', truncated=False):
    return {**{key: request[key] for key in ("npcId", "decisionId", "step")},
        "status": status, "rawCandidate": raw, "rawCandidateTruncated": truncated}


class CandidateMetricAuditTests(unittest.TestCase):
    def test_cancelled_task_does_not_receive_the_late_provider_candidate(self):
        result = metrics.host_handling(call("canceled"), None,
            [outcome("agent.decision_stale")], "live",
            {"status": "passed", "rawCandidate": '{"schemaVersion":1,"operation":"wait"}'})
        self.assertEqual(result[0], "no_response")

    def test_delivered_candidate_with_stale_observation_is_rejected(self):
        result = metrics.host_handling(call(), None,
            [outcome("agent.observation_stale")], "live", {"status": "passed"})
        self.assertEqual(result[0], "rejected")

    def test_delivered_candidate_validation_failure_is_rejected(self):
        result = metrics.host_handling(call("candidate_failure"), None,
            [outcome("agent.response_invalid")], "live", {"status": "provider.candidate_invalid"})
        self.assertEqual(result[0], "rejected")

    def test_successful_correction_keeps_the_first_candidate_rejected(self):
        first = call("candidate_failure", operation="invite")
        followup = call(step=2, operation="invite", correction="candidate.plan_id_required")
        result = metrics.host_handling(first, followup,
            [outcome("meeting.invited", calls=2, step=2)], "live", {})
        self.assertEqual(result[0], "rejected")
        self.assertEqual(metrics.continuation_kind(first, followup), "candidate_correction")

    def test_inspection_continuation_is_disclosure(self):
        first = call(operation="inspect_location")
        followup = call(step=2, operation="visit", details=True)
        result = metrics.host_handling(first, followup,
            [outcome("agent.activity_accepted", calls=2, step=2)], "live", {})
        self.assertEqual(result[0], "accepted_disclosure")
        self.assertEqual(metrics.continuation_kind(first, followup), "progressive_disclosure")

    def test_cancelled_decision_without_outcome_remains_in_denominator_and_latency(self):
        result = summarize_fixture([call("canceled")[0]], [])
        measured = result["metrics"]
        self.assertEqual(measured["initiatedDecisionN"], 1)
        self.assertEqual(measured["firstHostHandlingCounts"], {"no_response": 1})
        self.assertEqual(measured["finalHostAcceptanceUnknownN"], 1)
        self.assertEqual(measured["finalHostAcceptedN"], 0)
        self.assertEqual(measured["traceCompletionKindCounts"], {"canceled": 1})
        self.assertEqual(measured["latency"]["traceCompletionToDelivery"]["knownN"], 1)
        self.assertEqual(measured["latency"]["traceCompletionToDelivery"]["mean"], 0.25)
        self.assertEqual(measured["latency"]["decisionStartToFinish"]["unknownN"], 1)

    def test_outcome_without_dispatch_counts_as_initiated_without_candidate(self):
        result = summarize_fixture([], [outcome("agent.observation_unavailable", calls=0)])
        measured = result["metrics"]
        self.assertEqual(measured["initiatedDecisionN"], 1)
        self.assertEqual(measured["outcomeOnlyDecisionN"], 1)
        self.assertEqual(measured["firstHostHandlingCounts"], {"no_response": 1})
        row = result["worlds"][0]["decisions"][0]
        self.assertEqual(row["decisionId"], "decision-a")
        self.assertEqual(row["outcomes"][0]["calls"], 0)
        self.assertIsNone(row["firstDispatchRealSeconds"])
        self.assertEqual(row["calls"], [])
        self.assertEqual(measured["latency"]["traceCompletionToDelivery"]["applicableN"], 0)

    def test_outcome_claiming_a_call_without_trace_keeps_candidate_unknown(self):
        terminal = outcome("agent.response_invalid")
        terminal.pop("startedRealSeconds")
        terminal.pop("finishedRealSeconds")
        result = summarize_fixture([], [terminal])
        measured = result["metrics"]
        self.assertEqual(measured["initiatedDecisionN"], 1)
        self.assertEqual(measured["outcomeOnlyDecisionN"], 1)
        self.assertEqual(measured["firstHostHandlingCounts"], {"unknown": 1})
        self.assertEqual(measured["latency"]["decisionStartToFinish"]["unknownN"], 1)
        self.assertEqual(result["worlds"][0]["decisions"][0]["retainedCallN"], 0)

    def test_trace_and_outcome_with_one_id_count_as_one_decision(self):
        result = summarize_fixture([call()[0]], [outcome("agent.decision_wait")])
        measured = result["metrics"]
        self.assertEqual(measured["initiatedDecisionN"], 1)
        self.assertEqual(measured["outcomeOnlyDecisionN"], 0)
        self.assertEqual(measured["firstHostAcceptedN"], 1)
        self.assertEqual(measured["finalHostAcceptedN"], 1)

    def test_records_without_valid_ids_are_never_merged(self):
        first = call("canceled")[0]
        request = json.loads(first["requestJson"])
        request["decisionId"] = " "
        first["requestJson"] = json.dumps(request)
        last = outcome("agent.observation_unavailable", calls=0)
        last["decisionId"] = None
        result = summarize_fixture([first, dict(first)], [last, dict(last)])
        self.assertIsNone(result["metrics"]["initiatedDecisionN"])
        self.assertEqual(result["metrics"]["decisionEvidenceGroupN"], 4)
        self.assertEqual(result["metrics"]["identifiedDecisionN"], 0)
        self.assertEqual(result["metrics"]["unidentifiedEvidenceRecordN"], 4)
        self.assertFalse(result["metrics"]["decisionDenominatorComplete"])
        self.assertIsNone(result["metrics"]["firstHostAcceptedOverAllInitiated"])
        self.assertIsNone(result["metrics"]["finalHostAcceptedOverAllInitiated"])
        self.assertEqual(result["metrics"]["outcomeOnlyDecisionN"], 2)
        records = result["worlds"][0]["decisions"]
        self.assertTrue(all(row["decisionId"] is None for row in records))
        self.assertEqual(len({tuple(row["decisionRecordId"]) for row in records}), 4)

    def test_all_provider_attempts_keep_initial_and_correction_separate(self):
        first = call("candidate_failure")
        corrected = call(step=2, correction="candidate.plan_id_required")
        events = [provider_event(first[1], 1), provider_event(corrected[1], 2)]
        proxies = [proxy_record(first[1], "provider.candidate_invalid"), proxy_record(corrected[1])]
        result = summarize_fixture([first[0], corrected[0]],
            [outcome("agent.decision_wait", calls=2, step=2)], "live", proxies, events)
        all_attempts = result["allProviderAttemptMetrics"]
        self.assertEqual(all_attempts["attemptN"], 2)
        self.assertEqual(all_attempts["jsonParseCounts"], {"json_object": 2})
        self.assertEqual(all_attempts["protocolValidationCounts"], {"rejected": 1, "passed": 1})
        self.assertEqual(all_attempts["byContinuation"]["initial"]["attemptN"], 1)
        self.assertEqual(all_attempts["byContinuation"]["candidate_correction"]["attemptN"], 1)
        self.assertEqual(result["worlds"][0]["allProviderAttemptMetrics"], all_attempts)
        self.assertEqual(len(result["worlds"][0]["providerAttemptDetails"]), 2)

    def test_all_attempts_classify_inspection_as_disclosure(self):
        first = call(operation="inspect_location")
        following = call(step=2, operation="visit", details=True)
        events = [provider_event(first[1], 1), provider_event(following[1], 2)]
        rows = metrics.provider_attempt_details(events, [], [first[0], following[0]], "live")
        self.assertEqual([row["continuationKind"] for row in rows], ["initial", "progressive_disclosure"])
        lone_step = metrics.provider_attempt_details([events[1]], [], [following[0]], "live")
        self.assertEqual(lone_step[0]["continuationKind"], "resumed_or_unknown")

    def test_all_attempts_preserve_missing_truncated_and_invalid_records(self):
        events, proxies, traces = [], [], []
        for index in range(5):
            trace, request = call()
            request["decisionId"] = "decision-" + str(index)
            trace["requestJson"] = json.dumps(request)
            trace["callOrdinal"] = index
            traces.append(trace)
            events.append(provider_event(request, index + 1))
            if index == 1:
                proxies.append(proxy_record(request, "provider.failure", raw=None))
            elif index == 2:
                proxies.append(proxy_record(request, "provider.candidate_invalid", raw='{"cut', truncated=True))
            elif index == 3:
                proxies.append(proxy_record(request, "provider.candidate_invalid", raw='not-json'))
            elif index == 4:
                proxies.append(proxy_record(request, "provider.candidate_invalid", raw='[]'))
        rows = metrics.provider_attempt_details(events, proxies, traces, "live")
        measured = metrics.provider_attempt_metrics(rows, "live", True)
        self.assertEqual(measured["attemptN"], 5)
        self.assertEqual(measured["retainedRawCandidateN"], 3)
        self.assertEqual(measured["jsonParseCounts"], {"unknown_no_proxy_record": 1,
            "no_raw_candidate": 1, "unknown_truncated_candidate": 1, "invalid_json": 1, "json_non_object": 1})
        self.assertEqual(measured["byContinuation"]["initial"]["attemptN"], 5)
        self.assertEqual(rows[0]["proxyMatch"], "missing")
        self.assertEqual([row["providerCall"] for row in rows], [1, 2, 3, 4, 5])

    def test_provider_attempts_mark_fixed_not_applicable_and_missing_ledger_unknown(self):
        fixed = metrics.provider_attempt_metrics([], "fixed", True)
        self.assertFalse(fixed["applicable"])
        self.assertEqual(fixed["attemptN"], 0)
        missing = metrics.provider_attempt_metrics([], "live", False)
        self.assertIsNone(missing["attemptN"])
        self.assertIsNone(missing["byContinuation"]["initial"]["attemptN"])

    def test_provider_only_decision_remains_in_denominator_with_unknown_host_result(self):
        trace, request = call()
        provider_only = {**request, "decisionId": "decision-b"}
        events = [provider_event(request, 1), provider_event(provider_only, 2)]
        proxies = [proxy_record(request), proxy_record(provider_only)]
        result = summarize_fixture([trace], [outcome("agent.decision_wait")], "live", proxies, events)
        measured = result["metrics"]
        self.assertEqual(measured["initiatedDecisionN"], 2)
        self.assertEqual(measured["identifiedDecisionN"], 2)
        self.assertTrue(measured["decisionDenominatorComplete"])
        self.assertEqual(measured["providerOnlyDecisionN"], 1)
        self.assertEqual(measured["missingHostTraceDecisionN"], 1)
        self.assertEqual(measured["missingHostOutcomeDecisionN"], 1)
        self.assertEqual(measured["firstHostAcceptedOverAllInitiated"], 0.5)
        self.assertEqual(measured["finalHostAcceptedOverAllInitiated"], 0.5)
        row = next(row for row in result["worlds"][0]["decisions"] if row["decisionId"] == "decision-b")
        self.assertEqual(row["firstHostHandling"], "unknown")
        self.assertIsNone(row["finalHostAccepted"])
        self.assertIsNone(row["firstDispatchRealSeconds"])
        self.assertIsNone(row["decisionStartToFinishSeconds"])
        self.assertEqual(row["providerEvidence"][0]["providerAttemptIndex"], 1)
        detail = result["worlds"][0]["providerAttemptDetails"][1]
        self.assertEqual(detail["protocolValidation"], "passed")
        self.assertEqual(detail["traceMatch"], "missing")

    def test_two_provider_attempts_with_one_decision_id_count_once_without_trace(self):
        _, request = call()
        events = [provider_event(request, 1), provider_event({**request, "step": 2}, 2)]
        result = summarize_fixture([], [], "live", [], events)
        self.assertEqual(result["metrics"]["initiatedDecisionN"], 1)
        self.assertEqual(result["metrics"]["providerOnlyDecisionN"], 1)
        self.assertEqual(result["allProviderAttemptMetrics"]["attemptN"], 2)
        self.assertEqual(len(result["worlds"][0]["decisions"][0]["providerEvidence"]), 2)

    def test_provider_event_missing_identity_keeps_count_uncertain_and_rates_null(self):
        trace, request = call()
        missing = {**request, "decisionId": None}
        result = summarize_fixture([trace], [outcome("agent.decision_wait")], "live", [],
            [provider_event(request, 1), provider_event(missing, 2)])
        measured = result["metrics"]
        self.assertIsNone(measured["initiatedDecisionN"])
        self.assertEqual(measured["identifiedDecisionN"], 1)
        self.assertEqual(measured["identifiedFinalHostAcceptedN"], 1)
        self.assertEqual(measured["unidentifiedEvidenceRecordN"], 1)
        self.assertEqual(measured["decisionEvidenceGroupN"], 2)
        self.assertFalse(measured["decisionDenominatorComplete"])
        self.assertIsNone(measured["firstHostAcceptedOverAllInitiated"])
        self.assertIsNone(measured["finalHostAcceptedOverAllInitiated"])
        self.assertEqual(result["worlds"][0]["decisions"][1]["decisionRecordId"], ["provider", 1])

    def test_malformed_ledger_preserves_coordinator_gap_and_unknown_cost_and_latency(self):
        trace, request = call()
        proxy = {**proxy_record(request), "elapsedMilliseconds": 10,
            "promptTokens": 10, "completionTokens": 2, "totalTokens": 12}
        result = summarize_fixture([trace], [outcome("agent.decision_wait")], "live", [proxy],
            [provider_event(request, 1)], ledger_text_tail='{"event":', coordinator_attempts=2)
        self.assertIsNone(result["allProviderAttemptMetrics"]["attemptN"])
        self.assertEqual(result["allProviderAttemptMetrics"]["visibleAttemptN"], 1)
        self.assertEqual(result["providerEvidenceCoverage"]["unmatchedCoordinatorAttemptN"], 1)
        self.assertEqual(result["providerEvidenceCoverage"]["ledgerParseWarningN"], 1)
        self.assertIsNone(result["metrics"]["initiatedDecisionN"])
        self.assertEqual(result["metrics"]["identifiedDecisionN"], 1)
        self.assertEqual(result["metrics"]["decisionEvidenceGroupN"], 1)
        self.assertIsNone(result["metrics"]["finalHostAcceptedOverAllInitiated"])
        for metrics in (result["metrics"], result["worlds"][0]["metrics"]):
            latency = metrics["latency"]["proxyRecordedElapsed"]
            self.assertEqual(latency["applicableN"], 2)
            self.assertEqual(latency["knownN"], 1)
            self.assertEqual(latency["unknownN"], 1)
            self.assertFalse(latency["denominatorComplete"])
        tokens = result["worlds"][0]["usage"]["promptTokens"]
        self.assertIsNone(tokens["total"])
        self.assertEqual(tokens["knownPartialTotal"], 10)
        self.assertEqual(tokens["unknownN"], 1)
        self.assertFalse(tokens["denominatorComplete"])

    def test_nonobject_ledger_record_marks_coverage_incomplete_without_counting_a_decision(self):
        trace, request = call()
        result = summarize_fixture([trace], [outcome("agent.decision_wait")], "live", [],
            [provider_event(request, 1)], ledger_text_tail='[]\n')
        self.assertFalse(result["providerEvidenceCoverage"]["complete"])
        self.assertEqual(result["providerEvidenceCoverage"]["ledgerParseWarningN"], 1)
        self.assertEqual(result["providerEvidenceCoverage"]["visibleProviderAdmissionN"], 1)
        self.assertIsNone(result["metrics"]["initiatedDecisionN"])
        self.assertEqual(result["metrics"]["identifiedDecisionN"], 1)

    def test_coordinator_gap_without_parser_warning_still_marks_totals_incomplete(self):
        result = summarize_fixture([], [], "live", [], [], coordinator_attempts=2)
        self.assertEqual(result["providerEvidenceCoverage"]["ledgerParseWarningN"], 0)
        self.assertEqual(result["providerEvidenceCoverage"]["unmatchedCoordinatorAttemptN"], 2)
        self.assertIsNone(result["allProviderAttemptMetrics"]["attemptN"])
        self.assertEqual(result["metrics"]["identifiedDecisionN"], 0)
        self.assertIsNone(result["metrics"]["initiatedDecisionN"])
        self.assertEqual(result["metrics"]["latency"]["proxyRecordedElapsed"]["unknownN"], 2)


if __name__ == "__main__":
    unittest.main()
