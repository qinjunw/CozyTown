"""Assign previously unassigned speech rows from terminal worlds to a review batch."""

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

from build_speech_review_pack import build
from summarize_integration import parse, read_bytes


TERMINAL = {"completed", "host_failure", "incomplete", "initialization_failed"}


def encode(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


def digest(value):
    return hashlib.sha256(value).hexdigest()


def previous_assignments(paths):
    assigned, chain = set(), []
    for path in paths:
        raw = read_bytes(path)
        packet = parse(raw.decode("utf-8-sig"))
        if not isinstance(packet, dict) or packet.get("schemaVersion") != 1 or not isinstance(packet.get("samples"), list):
            raise ValueError("Previous packs must contain a schema 1 sample collection.")
        identifiers = []
        for sample in packet["samples"]:
            identifier = sample.get("sampleId") if isinstance(sample, dict) else None
            if not isinstance(identifier, str) or not identifier:
                raise ValueError("Every previously assigned row requires its stable sampleId.")
            identifiers.append(identifier)
        assigned.update(identifiers)
        chain.append({"fileName": path.name, "sha256": digest(raw), "packId": packet.get("packId"),
            "sampleRows": len(identifiers), "uniqueSampleIds": len(set(identifiers))})
    return assigned, chain


def make_batch(study, previous_paths):
    source_blind, source_identity = build(study)
    source_blind_bytes = encode(source_blind)
    source_identity["blindPackSha256"] = digest(source_blind_bytes)
    source_identity_bytes = encode(source_identity)
    assigned, previous_chain = previous_assignments(previous_paths)
    identities = defaultdict(list)
    for row in source_identity["samples"]:
        identities[row["sampleId"]].append(row)
    states = {row["worldId"]: row["status"] for row in source_identity["worldDenominator"]}
    stability, eligibility = {}, {}
    for rows in identities.values():
        for row in rows:
            world_id = row["worldId"]
            if world_id in eligibility:
                continue
            issues = []
            if states.get(world_id) not in TERMINAL:
                issues.append("world_not_terminal")
            for field in ("speechPath", "manifestPath"):
                relative = row[field]
                expected = source_identity["sourceFiles"].get(relative)
                check = {"path": relative, "sourceSha256": expected.get("sha256") if expected else None,
                    "secondReadSha256": None, "stable": False}
                if expected is None:
                    issues.append(field + "_missing")
                else:
                    try:
                        check["secondReadSha256"] = digest(read_bytes(study / relative))
                        check["stable"] = check["secondReadSha256"] == expected["sha256"]
                        if not check["stable"]:
                            issues.append(field + "_changed")
                    except OSError:
                        issues.append(field + "_unreadable")
                stability[relative] = check
            eligibility[world_id] = issues
    selected, deferred, previous_rows = [], [], 0
    for sample in source_blind["samples"]:
        identifier = sample["sampleId"]
        if identifier in assigned:
            previous_rows += 1
            continue
        linked = identities.get(identifier, [])
        issues = sorted({issue for row in linked for issue in eligibility.get(row["worldId"], ["world_unknown"])})
        if not linked:
            issues.append("identity_mapping_missing")
        if issues:
            deferred.append({"sampleId": identifier, "reasons": issues})
        else:
            selected.append(sample)
    selected.sort(key=lambda sample: sample["sampleId"])
    selected_ids = {sample["sampleId"] for sample in selected}
    source_ids = {sample["sampleId"] for sample in source_blind["samples"]}
    counts = {"plannedWorlds": source_blind["denominator"]["plannedWorlds"],
        "allSourceRows": len(source_blind["samples"]), "previouslyAssignedRows": previous_rows,
        "deferredRows": len(deferred), "sampleRows": len(selected), "uniqueSampleIds": len(selected_ids),
        "verifiedAssociations": sum(sample["association"] == "verified" for sample in selected),
        "invalidAssociations": sum(sample["association"] != "verified" for sample in selected),
        "committedTranscriptRows": sum(sample["committedTranscript"]["text"] is not None for sample in selected),
        "missingTranscriptRows": sum(sample["committedTranscript"]["text"] is None for sample in selected)}
    pack_id = digest(encode({"sourcePackId": source_blind["packId"], "previousIds": sorted(assigned),
        "selectedIds": sorted(selected_ids)}))
    blind = dict(source_blind)
    blind.update({"packId": pack_id, "sourcePackId": source_blind["packId"], "isIncrementalBatch": True,
        "coverage": "This packet contains newly assigned rows only. Earlier assignments and deferred rows remain in the source denominator; this batch is not the whole study.",
        "sourceDenominator": dict(source_blind["denominator"]), "denominator": counts, "samples": selected})
    blind_bytes = encode(blind)
    identity = dict(source_identity)
    identity.update({"packId": pack_id, "sourcePackId": source_blind["packId"], "isIncrementalBatch": True,
        "blindPackSha256": digest(blind_bytes), "sourceDenominator": dict(source_blind["denominator"]),
        "denominator": counts, "samples": [row for row in source_identity["samples"] if row["sampleId"] in selected_ids],
        "sourceBlindSha256": digest(source_blind_bytes), "sourceIdentitySha256": digest(source_identity_bytes),
        "previousPacks": previous_chain, "previousSampleIdsNotInCurrentSource": sorted(assigned - source_ids),
        "deferredSamples": deferred, "stabilityChecks": list(stability.values()),
        "selectionRule": "Retain every source row, regardless of text, missing evidence or review quality. Assign only terminal-world rows with stable speech and manifest files whose sampleId was not previously assigned."})
    return blind_bytes, identity, source_blind_bytes, source_identity_bytes


def main():
    parser = argparse.ArgumentParser(description="Write an incremental blind packet, withheld mapping and complete current source packets.")
    parser.add_argument("--study", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--identity-output", required=True, type=Path)
    parser.add_argument("--previous-pack", action="append", default=[], type=Path,
        help="An earlier blind assignment packet; repeat for every prior batch. Reviewer verdict files are not inputs.")
    parser.add_argument("--source-stem", type=Path,
        help="Stem for <stem>.blind-source.json and <stem>.identity-source.json; defaults to the output stem.")
    args = parser.parse_args()
    study, output, identity_output = args.study.resolve(), args.output.resolve(), args.identity_output.resolve()
    stem = args.source_stem.resolve() if args.source_stem else output.with_suffix("")
    source_output, source_identity_output = Path(str(stem) + ".blind-source.json"), Path(str(stem) + ".identity-source.json")
    destinations = (output, identity_output, source_output, source_identity_output)
    if len(set(destinations)) != 4 or any(path.exists() or path.is_relative_to(study) for path in destinations):
        parser.error("Choose four distinct new output files outside the source study directory.")
    try:
        blind_bytes, identity, source_blind_bytes, source_identity_bytes = make_batch(study,
            [path.resolve() for path in args.previous_pack])
    except (ValueError, OSError) as error:
        parser.error(str(error))
    identity["sourcePacketFiles"] = {"blind": source_output.name, "identity": source_identity_output.name}
    for path, content in zip(destinations, (blind_bytes, encode(identity), source_blind_bytes, source_identity_bytes)):
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(content)
    print(json.dumps({"packId": identity["packId"], "isIncrementalBatch": True, "denominator": identity["denominator"]}))


if __name__ == "__main__":
    main()
