"""Measure retained decisions and latency without treating missing outcomes as successes."""

import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from summarize_integration import Evidence, embedded, parse


ACCEPTED_CODES = frozenset({"agent.decision_wait", "agent.activity_accepted", "meeting.invited",
    "meeting.accept_invite", "meeting.decline_invite", "meeting.say", "meeting.end_conversation",
    "meeting.deliver", "meeting.cancel_exchange"})


def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)


def difference(end, start):
    return end - start if numeric(end) and numeric(start) else None


def distribution(values, unit):
    known = sorted(value for value in values if numeric(value) and value >= 0)
    def quantile(fraction):
        if not known:
            return None
        index = (len(known) - 1) * fraction
        low = math.floor(index)
        return known[low] + (known[min(low + 1, len(known) - 1)] - known[low]) * (index - low)
    return {"unit": unit, "applicableN": len(values), "knownN": len(known), "unknownN": len(values) - len(known),
        "negativeSampleN": sum(numeric(value) and value < 0 for value in values),
        "min": known[0] if known else None, "max": known[-1] if known else None,
        "mean": sum(known) / len(known) if known else None,
        "p50": quantile(0.5), "p90": quantile(0.9), "p95": quantile(0.95)}


def signature(value):
    return value.get("npcId"), value.get("decisionId"), value.get("step")


def decision_key(value, source, index):
    identifier = value.get("decisionId")
    return ("id", identifier) if isinstance(identifier, str) and identifier.strip() else (source, index)


def raw_parse_status(record, stage):
    if stage == "fixed":
        return "not_applicable_typed_fixed_client"
    if record is None:
        return "unknown_no_proxy_record"
    if record.get("rawCandidateTruncated"):
        return "unknown_truncated_candidate"
    raw = record.get("rawCandidate")
    if not isinstance(raw, str):
        return "no_raw_candidate"
    try:
        candidate = parse(raw)
    except (TypeError, ValueError):
        return "invalid_json"
    return "json_object" if isinstance(candidate, dict) else "json_non_object"


def protocol_status(record, stage):
    if stage == "fixed":
        return "not_applicable_typed_fixed_client"
    if record is None:
        return "unknown_no_proxy_record"
    if record.get("status") == "passed":
        return "passed"
    if record.get("status") == "provider.candidate_invalid":
        return "rejected"
    return "not_established"


def host_handling(first, next_call, outcomes, stage, proxy):
    call, request = first
    if request.get("step") != 1:
        return "unknown", "The first retained request resumes after step 1."
    if next_call is not None:
        next_request = next_call[1]
        if next_request.get("candidateErrorCode"):
            return "rejected", "The next request explicitly carries a candidate correction code."
        response = embedded(call.get("responseJson")) or {}
        if (response.get("operation") == "inspect_location" and next_request.get("step") == 2
                and next_request.get("hasLocationDetails") is True):
            return "accepted_disclosure", "The host dispatched step 2 with inspected location details."
    if len(outcomes) == 1:
        outcome = outcomes[0]
        final_request = embedded(outcome.get("requestJson")) or {}
        if outcome.get("calls") == 1 and final_request.get("step") == 1:
            if outcome.get("code") in ACCEPTED_CODES:
                return "accepted_terminal", "The first-call terminal outcome is in the explicit acceptance set."
            if call.get("completionKind") in ("reply", "candidate_failure", "response_invalid"):
                return "rejected", "The retained terminal outcome does not establish host execution acceptance."
    if call.get("completionKind") not in ("reply", "candidate_failure", "response_invalid"):
        return "no_response", "No candidate was delivered in the retained trace."
    return "unknown", "The retained evidence does not establish how the host handled the first candidate."


def continuation_kind(previous, current):
    call, request = current
    if request.get("step") == 1:
        return "initial"
    if request.get("candidateErrorCode"):
        return "candidate_correction"
    if previous is not None:
        previous_response = embedded(previous[0].get("responseJson")) or {}
        if (previous_response.get("operation") == "inspect_location" and request.get("hasLocationDetails") is True
                and numeric(request.get("step")) and request.get("step") == previous[1].get("step", -2) + 1):
            return "progressive_disclosure"
    return "resumed_or_unknown_continuation"


ATTEMPT_GROUPS = ("initial", "candidate_correction", "progressive_disclosure", "resumed_or_unknown")


def provider_coverage(visible_n, coordinator_n, ledger_available, parse_warning_n):
    coordinator_n = coordinator_n if type(coordinator_n) is int and coordinator_n >= 0 else None
    difference_n = coordinator_n - visible_n if coordinator_n is not None else None
    issues = []
    if not ledger_available:
        issues.append("Provider ledger is unavailable.")
    if parse_warning_n:
        issues.append("Provider ledger contains unreadable or invalid records.")
    if difference_n is not None and difference_n != 0:
        issues.append("Visible provider admissions do not match the coordinator attempt count.")
    return {"complete": not issues, "ledgerAvailable": ledger_available,
        "ledgerParseWarningN": parse_warning_n, "visibleProviderAdmissionN": visible_n,
        "coordinatorAttemptN": coordinator_n, "coordinatorMinusVisibleN": difference_n,
        "unmatchedCoordinatorAttemptN": max(0, difference_n) if difference_n is not None else None,
        "issues": issues}


def provider_attempt_metrics(attempts, stage, ledger_available, coverage=None):
    complete = coverage["complete"] if coverage is not None else ledger_available
    def counts(rows):
        return {"attemptN": len(rows) if complete else None, "visibleAttemptN": len(rows),
            "retainedRawCandidateN": sum(row["hasRawCandidate"] for row in rows),
            "jsonParseCounts": dict(Counter(row["jsonParse"] for row in rows)),
            "protocolValidationCounts": dict(Counter(row["protocolValidation"] for row in rows)),
            "proxyStatusCounts": dict(Counter(row["proxyStatus"] or "<missing-proxy-record>" for row in rows))}
    return {"applicable": stage != "fixed", "ledgerAvailable": ledger_available, "ledgerComplete": complete,
        "coverage": coverage,
        "denominatorSource": "durable provider_started events",
        "notApplicableReason": "Typed fixed clients make no provider attempts." if stage == "fixed" else None,
        **counts(attempts),
        "byContinuation": {kind: counts([row for row in attempts if row["continuationKind"] == kind])
            for kind in ATTEMPT_GROUPS}}


def provider_attempt_details(provider_events, proxy_rows, calls, stage):
    proxies, events, traces, decisions = (defaultdict(list) for _ in range(4))
    for index, row in enumerate(proxy_rows):
        proxies[signature(row)].append((index, row))
    for event in provider_events:
        events[signature(event)].append(event)
    for index, call in enumerate(calls):
        request = embedded(call.get("requestJson")) or {}
        decisions[decision_key(request, "trace", index)].append((call, request, index))
    for retained in decisions.values():
        retained.sort(key=lambda item: item[0].get("callOrdinal", item[2]))
        previous = None
        for call, request, index in retained:
            kind = continuation_kind(previous, (call, request))
            if kind == "resumed_or_unknown_continuation":
                kind = "resumed_or_unknown"
            traces[signature(request)].append((index, call, request, kind))
            previous = call, request
    attempts = []
    for index, event in enumerate(provider_events):
        key = signature(event)
        unique_event = len(events[key]) == 1
        proxy_match = proxies[key]
        trace_match = traces[key]
        proxy = proxy_match[0][1] if unique_event and len(proxy_match) == 1 else None
        trace = trace_match[0] if unique_event and len(trace_match) == 1 else None
        attempts.append({"providerAttemptIndex": index, "worldId": event.get("worldId"),
            "providerCall": event.get("providerCall"), "worldProviderCall": event.get("worldProviderCall"),
            "recordedAtUtc": event.get("recordedAtUtc"),
            "npcId": event.get("npcId"), "decisionId": event.get("decisionId"), "step": event.get("step"),
            "continuationKind": trace[3] if trace else "resumed_or_unknown",
            "traceMatch": "unique" if trace else "missing" if not trace_match else "ambiguous",
            "traceCallOrdinal": trace[1].get("callOrdinal") if trace else None,
            "proxyMatch": "unique" if proxy is not None else "missing" if not proxy_match else "ambiguous",
            "proxyRowIndex": proxy_match[0][0] if proxy is not None else None,
            "hasRawCandidate": isinstance((proxy or {}).get("rawCandidate"), str),
            "rawCandidateTruncated": (proxy or {}).get("rawCandidateTruncated"),
            "jsonParse": raw_parse_status(proxy, stage), "protocolValidation": protocol_status(proxy, stage),
            "proxyStatus": (proxy or {}).get("status"),
            "proxyCandidateErrorCode": (proxy or {}).get("candidateErrorCode")})
    return attempts


def aggregate(decisions, outcome_codes, proxy_values, trace_values, decision_values, denominator_issues=()):
    handling = Counter(decision["firstHostHandling"] for decision in decisions)
    accepted_first = handling["accepted_terminal"] + handling["accepted_disclosure"]
    accepted_final = sum(decision["finalHostAccepted"] is True for decision in decisions)
    identified = [decision for decision in decisions if decision.get("decisionId") is not None]
    issues = list(denominator_issues)
    if len(identified) != len(decisions):
        issues.append("Unidentified evidence records may overlap known or other unidentified decisions.")
    complete = not issues
    return {"initiatedDecisionN": len(decisions) if complete else None,
        "decisionEvidenceGroupN": len(decisions), "identifiedDecisionN": len(identified),
        "unidentifiedEvidenceRecordN": len(decisions) - len(identified),
        "decisionDenominatorComplete": complete, "decisionDenominatorIssues": issues,
        "identifiedFirstHostAcceptedN": sum(row["firstHostHandling"] in ("accepted_terminal", "accepted_disclosure") for row in identified),
        "identifiedFinalHostAcceptedN": sum(row["finalHostAccepted"] is True for row in identified),
        "firstStep1ObservedN": sum(decision["firstObservedStep"] == 1 for decision in decisions),
        "outcomeOnlyDecisionN": sum(decision.get("evidenceKind") == "outcome_only" for decision in decisions),
        "providerOnlyDecisionN": sum(decision.get("evidenceKind") == "provider_only" for decision in decisions),
        "missingHostTraceDecisionN": sum(decision.get("hostTraceEvidenceMissing", False) for decision in decisions),
        "missingHostOutcomeDecisionN": sum(not decision["hasRetainedOutcome"] for decision in decisions),
        "firstHostHandlingCounts": dict(handling), "firstHostAcceptedN": accepted_first,
        "firstHostAcceptedOverAllInitiated": accepted_first / len(decisions) if decisions and complete else None,
        "finalHostAcceptedN": accepted_final,
        "finalHostNotAcceptedN": sum(decision["finalHostAccepted"] is False for decision in decisions),
        "finalHostAcceptanceUnknownN": sum(decision["finalHostAccepted"] is None for decision in decisions),
        "finalHostAcceptedOverAllInitiated": accepted_final / len(decisions) if decisions and complete else None,
        "firstProtocolValidationCounts": dict(Counter(decision["firstCandidate"]["proxyValidation"] for decision in decisions)),
        "firstCandidateParseCounts": dict(Counter(decision["firstCandidate"]["jsonParse"] for decision in decisions)),
        "outcomeCodeCounts": dict(outcome_codes),
        "traceCompletionKindCounts": dict(Counter(call.get("traceCompletionKind") or "<not-completed>"
            for decision in decisions for call in decision["calls"])),
        "latency": {"proxyRecordedElapsed": distribution(proxy_values, "milliseconds"),
                    "traceCompletionToDelivery": distribution(trace_values, "seconds"),
                    "decisionStartToFinish": distribution(decision_values, "seconds"),
                    "budgetWaiting": {"knownN": 0, "duration": None, "reason": "No budget-wait begin/end events are recorded; timeline samples are not durations."}}}


def summarize(study):
    evidence = Evidence(study)
    plan, status = evidence.load("plan.json"), evidence.load("status.json")
    if not isinstance(plan, dict) or not isinstance(plan.get("worlds"), list) or not isinstance(status, dict):
        raise ValueError("A registered study plan and its coordinator status are required.")
    if status.get("state") not in ("finished", "aborted"):
        raise ValueError("Generate formal candidate metrics only after the coordinator has stopped.")
    ledger = evidence.load("ledger.jsonl", lines=True)
    ledger_warning_n = sum(row.get("path") == "ledger.jsonl" for row in evidence.warnings)
    if ledger is not None:
        ledger_warning_n += sum(not isinstance(row, dict) for row in ledger)
        ledger = [row for row in ledger if isinstance(row, dict)]
    worlds, all_decisions, all_codes, all_attempts = [], [], Counter(), []
    all_proxy, all_trace, all_duration = [], [], []
    for world in plan["worlds"]:
        ordinal, world_id = world.get("ordinal"), world.get("worldId")
        if type(ordinal) is not int or not isinstance(world_id, str) or not world_id.isalnum():
            raise ValueError("Registered world identifiers do not match the coordinator directory convention.")
        directory = f"{ordinal:02}-{world_id}"
        manifest = evidence.load(directory + "/package/manifest.json") or {}
        proxy_rows = evidence.load(directory + "/proxy.jsonl", lines=True)
        status_row = next((row for row in status.get("worlds", []) if row.get("worldId") == world_id), {})
        calls = (manifest.get("trace") or {}).get("calls", [])
        outcomes = manifest.get("results", [])
        provider_events = [row for row in ledger or [] if row.get("worldId") == world_id and row.get("event") == "provider_started"]
        coverage = provider_coverage(len(provider_events), status_row.get("attemptedProviderCalls"), ledger is not None, ledger_warning_n)
        attempt_details = provider_attempt_details(provider_events, proxy_rows or [], calls, plan.get("stage"))
        all_attempts.extend(attempt_details)
        proxies_by_key, events_by_key = defaultdict(list), defaultdict(list)
        for row in proxy_rows or []:
            proxies_by_key[signature(row)].append(row)
        for row in provider_events:
            events_by_key[signature(row)].append(row)
        matched_proxy = {key: rows[0] for key, rows in proxies_by_key.items() if len(rows) == 1 and len(events_by_key[key]) == 1}
        proxy_values = [(matched_proxy.get(signature(event)) or {}).get("elapsedMilliseconds") for event in provider_events]
        proxy_values.extend([None] * (coverage["unmatchedCoordinatorAttemptN"] or 0))
        groups, outcome_groups, provider_groups, trace_values = {}, defaultdict(list), defaultdict(list), []
        for index, call in enumerate(calls):
            request = embedded(call.get("requestJson")) or {}
            groups.setdefault(decision_key(request, "trace", index), []).append((call, request))
            trace_values.append(difference(call.get("deliveryRealSeconds"), call.get("completedRealSeconds"))
                if call.get("hasCompletedRealSeconds") is True and call.get("deliveryTick", -1) >= 0 else None)
        for index, outcome in enumerate(outcomes):
            outcome_groups[decision_key(outcome, "outcome", index)].append(outcome)
        for index, event in enumerate(provider_events):
            provider_groups[decision_key(event, "provider", index)].append((index, event))
        dispatched_keys = set(groups)
        for key in list(outcome_groups) + list(provider_groups):
            groups.setdefault(key, [])
        decisions, decision_values = [], []
        for group_key, retained in groups.items():
            retained.sort(key=lambda pair: pair[0].get("callOrdinal", -1))
            decision_outcomes = outcome_groups.get(group_key, [])
            decision_events = provider_groups.get(group_key, [])
            final = decision_outcomes[0] if len(decision_outcomes) == 1 else None
            first, first_request = retained[0] if retained else ({}, {})
            first_proxy_candidates = proxies_by_key.get(signature(first_request), []) if retained else []
            first_proxy = first_proxy_candidates[0] if len(first_proxy_candidates) == 1 else None
            if retained:
                handling, handling_reason = host_handling(retained[0], retained[1] if len(retained) > 1 else None,
                    decision_outcomes, plan.get("stage"), first_proxy)
            elif final is not None and type(final.get("calls")) is int and final["calls"] == 0 and not decision_events:
                handling, handling_reason = "no_response", "The retained outcome records zero client calls; no candidate was dispatched."
            else:
                handling, handling_reason = "unknown", "Retained outcome or provider admission evidence has no matching host dispatch trace; host candidate delivery is not established."
            followups, previous = [], None
            for call, request in retained:
                followups.append({"callOrdinal": call.get("callOrdinal"), "step": request.get("step"),
                    "kind": continuation_kind(previous, (call, request)), "candidateErrorCode": request.get("candidateErrorCode") or None,
                    "traceCompletionKind": call.get("completionKind") or None, "deliveryTick": call.get("deliveryTick"),
                    "cancellationTick": call.get("cancellationTick")})
                previous = call, request
            outcome_rows = [{key: row.get(key) for key in ("code", "calls", "candidateErrors", "startedRealSeconds", "finishedRealSeconds")}
                            for row in decision_outcomes]
            duration = difference(final.get("finishedRealSeconds"), final.get("startedRealSeconds")) if final else None
            decision_values.append(duration)
            first_is_step1 = first_request.get("step") == 1
            identity = first_request if retained else decision_outcomes[0] if decision_outcomes else decision_events[0][1]
            decisions.append({"decisionId": group_key[1] if group_key[0] == "id" else None,
                "decisionRecordId": list(group_key),
                "evidenceKind": "dispatched" if retained else "outcome_only" if decision_outcomes else "provider_only",
                "evidenceSources": {"trace": bool(retained), "outcome": bool(decision_outcomes), "providerLedger": bool(decision_events)},
                "hostTraceEvidenceMissing": not retained and (bool(decision_events)
                    or any(type(row.get("calls")) is int and row["calls"] > 0 for row in decision_outcomes)),
                "providerEvidence": [{"providerAttemptIndex": index,
                    **{key: event.get(key) for key in ("worldId", "providerCall", "worldProviderCall", "recordedAtUtc", "step")}}
                    for index, event in decision_events],
                "npcId": identity.get("npcId"), "worldRunId": identity.get("worldRunId"),
                "firstObservedStep": first_request.get("step"), "firstDispatchGameMinutes": first_request.get("gameTotalMinutes"),
                "firstDispatchRealSeconds": first.get("dispatchRealSeconds"), "retainedCallN": len(retained),
                "hasRetainedOutcome": bool(decision_outcomes), "outcomes": outcome_rows,
                "firstCandidate": {"jsonParse": raw_parse_status(first_proxy, plan.get("stage")) if first_is_step1 else "unknown_step1_not_retained",
                    "proxyValidation": protocol_status(first_proxy, plan.get("stage")) if first_is_step1 else "unknown_step1_not_retained",
                    "proxyStatus": (first_proxy or {}).get("status"), "proxyCandidateErrorCode": (first_proxy or {}).get("candidateErrorCode"),
                    "traceCompletionKind": first.get("completionKind") or None, "traceCandidateErrorCode": first.get("candidateErrorCode") or None},
                "firstHostHandling": handling, "firstHostHandlingReason": handling_reason,
                "finalHostAccepted": final.get("code") in ACCEPTED_CODES if final else None,
                "decisionStartToFinishSeconds": duration,
                "invalidatingLoadInputTicks": [entry.get("tick") for entry in manifest.get("inputs", [])
                    if retained and entry.get("kind") == "load" and entry.get("worldBefore") == first_request.get("worldRunId")
                    and entry.get("worldAfter") != entry.get("worldBefore")],
                "calls": followups})
        codes = Counter(outcome.get("code") or "<missing-code>" for outcome in outcomes)
        metrics = aggregate(decisions, codes, proxy_values, trace_values, decision_values, coverage["issues"])
        metrics["latency"]["proxyRecordedElapsed"].update({"denominatorComplete": coverage["complete"],
            "visibleProviderAdmissionN": len(provider_events), "coordinatorAttemptN": coverage["coordinatorAttemptN"],
            "unmatchedCoordinatorAttemptN": coverage["unmatchedCoordinatorAttemptN"]})
        if not coverage["complete"] and coverage["coordinatorAttemptN"] is None:
            metrics["latency"]["proxyRecordedElapsed"].update(applicableN=None, unknownN=None)
        actual_proxy_rows = list(matched_proxy.values())
        usage = {}
        attempt_n = len(provider_events) if coverage["complete"] else max(len(provider_events), coverage["coordinatorAttemptN"]) if coverage["coordinatorAttemptN"] is not None else None
        for field in ("promptTokens", "completionTokens", "totalTokens"):
            known = [row[field] for row in actual_proxy_rows if type(row.get(field)) is int and row[field] >= 0]
            usage[field] = {"applicableN": attempt_n, "denominatorComplete": coverage["complete"], "knownN": len(known),
                "unknownN": attempt_n - len(known) if attempt_n is not None else None,
                "total": sum(known) if coverage["complete"] and attempt_n and len(known) == attempt_n else None,
                "knownPartialTotal": sum(known) if known else None}
        worlds.append({key: world.get(key) for key in ("worldId", "ordinal", "pairId", "scenarioId", "speechMode", "repetition")} | {
            "status": status_row.get("status", "unknown"), "hasManifest": bool(manifest),
            "providerAttemptsCoordinator": status_row.get("attemptedProviderCalls"),
            "providerAttemptsLedger": len(provider_events) if ledger is not None else None,
            "proxyServiceRecordN": None if proxy_rows is None else len(proxy_rows), "actualAttemptMeasurementN": len(actual_proxy_rows),
            "allProxyStatusCounts": dict(Counter(row.get("status") or "<missing-status>" for row in proxy_rows or [])),
            "actualAttemptProxyStatusCounts": dict(Counter(row.get("status") or "<missing-status>" for row in actual_proxy_rows)),
            "proxyRecordsWithoutUniqueAttemptMatchN": len(proxy_rows or []) - len(actual_proxy_rows),
            "requestedModelsObserved": sorted({row["requestedModel"] for row in actual_proxy_rows if row.get("requestedModel")}) or None,
            "returnedModelsObserved": sorted({row["returnedModel"] for row in actual_proxy_rows if row.get("returnedModel")}) or None,
            "usage": usage, "cost": None, "metrics": metrics,
            "providerEvidenceCoverage": coverage,
            "allProviderAttemptMetrics": provider_attempt_metrics(attempt_details, plan.get("stage"), ledger is not None, coverage),
            "providerAttemptDetails": attempt_details,
            "outcomesWithoutRetainedDispatch": [{key: row.get(key) for key in ("decisionId", "npcId", "code", "calls", "candidateErrors")}
                for index, row in enumerate(outcomes) if decision_key(row, "outcome", index) not in dispatched_keys], "decisions": decisions})
        all_decisions.extend(decisions)
        all_codes.update(codes)
        all_proxy.extend(proxy_values)
        all_trace.extend(trace_values)
        all_duration.extend(decision_values)
    total_coverage = provider_coverage(len(all_attempts), status.get("attemptedProviderCalls"), ledger is not None, ledger_warning_n)
    total_issues = sorted({issue for world in worlds for issue in world["providerEvidenceCoverage"]["issues"]} | set(total_coverage["issues"]))
    total_coverage["issues"], total_coverage["complete"] = total_issues, not total_issues
    if total_coverage["coordinatorAttemptN"] is not None:
        all_proxy.extend([None] * max(0, total_coverage["coordinatorAttemptN"] - len(all_proxy)))
    total_metrics = aggregate(all_decisions, all_codes, all_proxy, all_trace, all_duration, total_issues)
    total_metrics["latency"]["proxyRecordedElapsed"].update({"denominatorComplete": total_coverage["complete"],
        "visibleProviderAdmissionN": len(all_attempts), "coordinatorAttemptN": total_coverage["coordinatorAttemptN"],
        "unmatchedCoordinatorAttemptN": total_coverage["unmatchedCoordinatorAttemptN"]})
    if not total_coverage["complete"] and total_coverage["coordinatorAttemptN"] is None:
        total_metrics["latency"]["proxyRecordedElapsed"].update(applicableN=None, unknownN=None)
    return {"schemaVersion": 1, "generatedAtUtc": datetime.now(timezone.utc).isoformat(),
        "study": {key: plan.get(key) for key in ("studyId", "stage", "sourceRevision", "evaluationPlanReference")}
            | {"state": status.get("state"), "plannedWorldN": len(plan["worlds"]),
               "worldStatusCounts": dict(Counter(world["status"] for world in worlds))},
        "acceptanceContract": {"acceptedOutcomeCodes": sorted(ACCEPTED_CODES),
            "source": "Assets/CozyTown/Runtime/NpcAgents/NpcDecisionScheduler.cs:735-799",
            "meaning": "Successful host execution, including legal wait, decline and cancellation; this does not establish a successful meeting or resource exchange."},
        "definitions": {"denominator": "The per-world union of retained dispatch, outcome and durable provider_started decisionIds, including canceled, loaded-away, unfinished, no-outcome, outcome-only and provider-only decisions. A nonempty string ID joins records within its world; every record without such an ID gets a separate source/index marker. If identities are missing, initiatedDecisionN and total acceptance ratios are null because evidence groups may overlap; decisionEvidenceGroupN, unidentifiedEvidenceRecordN and identifiedDecisionN remain explicit. Denominator completeness describes retained evidence, not unrecorded execution.",
            "providerOnly": "A durable admission proves an attempted decision even without host trace/outcome. It remains in the denominator with unknown host handling, final result and decision latency. providerEvidence indexes the world's providerAttemptDetails; a proxy candidate does not prove host delivery. outcomeOnlyDecisionN means an outcome without trace and may also have provider evidence.",
            "firstCandidate": "Step 1 only. A restored first retained step greater than 1 remains unknown. Proxy JSON parsing is separate from validation and host handling.",
            "firstHostHandling": "accepted_terminal, accepted_disclosure, rejected, no_response or unknown. Disclosure requires the next step and inspected location details.",
            "observedAcceptanceProportions": "Accepted / all initiated decisions; unknowns remain in the denominator. These are observed acceptance proportions, not an estimate that unknown decisions failed.",
            "continuations": "A nonempty request candidateErrorCode marks correction; inspect_location followed by location details marks disclosure. Other continuations remain separate.",
            "proxyRecordedElapsed": "ProxyService elapsedMilliseconds spans provider transport and proxy candidate handling; it is not the full Unity-to-proxy HTTP latency.",
            "traceCompletionToDelivery": "deliveryRealSeconds minus completedRealSeconds only when the completion clock and delivery are recorded. This is trace task completion to host consumption and includes replies, failures and cancellation notifications, not only model responses. traceCompletionKindCounts retains their categories; negative samples remain invalid, not clamped.",
            "decisionStartToFinish": "Terminal outcome finishedRealSeconds minus startedRealSeconds; no outcome or duplicate outcomes remain unknown.",
            "quantiles": "Linear interpolation at (knownN - 1) * q using finite nonnegative samples.",
            "usage": "Only proxy rows uniquely matched to durable provider admissions contribute; unknown totals and cost remain null.",
            "allProviderAttempts": "Every durable provider_started event remains in the denominator, including missing or ambiguous proxy matches, missing raw candidates, truncation and parse failures. Grouping uses the uniquely matched trace and its continuation evidence; step greater than 1 alone never establishes correction. Retained raw-candidate counts do not establish that every provider response reached the host.",
            "incompleteLedger": "Visible admissions are a retained lower bound. Unreadable ledger records or coordinator count mismatches make the complete attempt/decision denominators and total acceptance ratios unknown. Coordinator-minus-visible differences are retained without inventing decision identities. Proxy latency and usage include that reported shortfall as unknown samples; token totals remain null and knownPartialTotal stays separate. If no coordinator total is available, their full applicable/unknown counts are also null.",
            "fixed": "Typed fixed clients do not establish provider protocol parsing or model performance."},
        "metrics": total_metrics, "providerEvidenceCoverage": total_coverage,
        "allProviderAttemptMetrics": provider_attempt_metrics(all_attempts, plan.get("stage"), ledger is not None, total_coverage),
        "worlds": worlds, "evidenceFiles": evidence.files, "warnings": evidence.warnings}


def main():
    parser = argparse.ArgumentParser(description="Summarize candidate handling and latency after a study stops.")
    parser.add_argument("--study", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    study, output = args.study.resolve(), args.output.resolve()
    if output.exists() or output.is_relative_to(study):
        parser.error("Choose a new output file outside the source study directory.")
    try:
        result = summarize(study)
    except ValueError as error:
        parser.error(str(error))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
    print(json.dumps({"studyId": result["study"]["studyId"], "initiatedDecisionN": result["metrics"]["initiatedDecisionN"],
        "firstHostHandlingCounts": result["metrics"]["firstHostHandlingCounts"], "warnings": len(result["warnings"])}))


if __name__ == "__main__":
    main()
