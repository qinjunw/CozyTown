"""Validate review provenance, exact quotations and evidence references offline."""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

from summarize_integration import parse, read_bytes


CLEAR = {"contradicted", "unsupported", "source_time_misuse", "unauthorized"}
FACTUAL = CLEAR | {"supported", "ambiguous"}
VERDICTS = FACTUAL | {"not_factual", "insufficient_review_evidence"}
DIMENSIONS = ("relevance", "refusal", "repetition", "persona", "qaCoverage")


def load(path):
    raw = read_bytes(Path(path))
    value = parse(raw.decode("utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError("Input must be a JSON object: " + Path(path).name)
    return value, hashlib.sha256(raw).hexdigest()


def fraction(n, denominator):
    return {"n": n, "N": denominator, "rate": n / denominator if denominator else None}


def dimension_status(sample, dimension):
    value = sample.get(dimension)
    if isinstance(value, dict):
        return value.get("status")
    if dimension == "qaCoverage" and isinstance(sample.get("relevance"), dict):
        return sample["relevance"].get("questionCoverage")
    return None


def statistics(samples):
    """Count final supplied verdicts; dimension labels remain descriptive categories."""
    verdicts = Counter()
    dimensions = {name: Counter() for name in DIMENSIONS}
    utterances = Counter()
    for sample in samples:
        claims = sample.get("claims", [])
        values = [claim.get("verdict") for claim in claims if isinstance(claim, dict)]
        verdicts.update(value for value in values if isinstance(value, str))
        factual = sum(value in FACTUAL for value in values)
        missing = "insufficient_review_evidence" in values
        text = sample.get("committedText", sample.get("text"))
        utterances["clearIssues"] += bool(set(values) & CLEAR)
        utterances["ambiguous"] += "ambiguous" in values
        utterances["conservativeIssues"] += bool(set(values) & (CLEAR | {"ambiguous"}))
        utterances["withFactualAssertions"] += factual > 0
        utterances["reviewEvidenceMissing"] += missing or text is None
        utterances["noFactual"] += factual == 0 and not missing and text is not None
        for name in DIMENSIONS:
            status = dimension_status(sample, name)
            dimensions[name][status if isinstance(status, str) and status else "unknown"] += 1
    factual_n = sum(verdicts[value] for value in FACTUAL)
    clear_n = sum(verdicts[value] for value in CLEAR)
    return {"reviewedUtterances": len(samples), "allReviewUnits": sum(verdicts.values()),
        "factualAssertions": factual_n, "verdictCounts": dict(sorted(verdicts.items())),
        "assertions": {"clearIssues": fraction(clear_n, factual_n),
            "ambiguous": fraction(verdicts["ambiguous"], factual_n),
            "conservativeIssues": fraction(clear_n + verdicts["ambiguous"], factual_n)},
        "utterances": {key: fraction(utterances[key], len(samples)) for key in
            ("clearIssues", "ambiguous", "conservativeIssues", "withFactualAssertions", "reviewEvidenceMissing")},
        "noFactualUtterances": utterances["noFactual"],
        "reviewEvidenceMissingUnits": verdicts["insufficient_review_evidence"],
        "dimensions": {name: dict(sorted(values.items())) for name, values in dimensions.items()}}


def sample_index(document, errors, prefix):
    values = document.get("samples")
    if not isinstance(values, list):
        errors.append(prefix + ": samples must be an array")
        return {}, []
    result, duplicates = {}, []
    for index, sample in enumerate(values):
        identifier = sample.get("sampleId") if isinstance(sample, dict) else None
        if not isinstance(identifier, str) or not identifier.strip():
            errors.append(prefix + ": sample " + str(index) + " requires sampleId")
        elif identifier in result:
            duplicates.append(identifier)
            errors.append(prefix + ": duplicate sampleId " + identifier)
        else:
            result[identifier] = (index, sample)
    return result, duplicates


def resolve_pointer(document, pointer):
    if not isinstance(pointer, str) or not pointer.startswith("/") or re.search(r"~(?![01])", pointer):
        raise ValueError("invalid JSON pointer")
    value, ancestors = document, [document]
    for token in pointer[1:].split("/"):
        token = token.replace("~1", "/").replace("~0", "~")
        if isinstance(value, list):
            if not re.fullmatch(r"0|[1-9][0-9]*", token) or int(token) >= len(value):
                raise ValueError("array index does not resolve")
            value = value[int(token)]
        elif isinstance(value, dict) and token in value:
            value = value[token]
        else:
            raise ValueError("pointer does not resolve")
        ancestors.append(value)
    return value, ancestors


def check_references(value, pack, index, errors, label):
    if isinstance(value, list):
        for item in value:
            check_references(item, pack, index, errors, label)
    elif isinstance(value, dict):
        for key, child in value.items():
            if key != "evidenceRefs":
                check_references(child, pack, index, errors, label)
                continue
            if not isinstance(child, list):
                errors.append(label + ": evidenceRefs must be an array")
                continue
            for reference in child:
                if not isinstance(reference, dict):
                    errors.append(label + ": evidenceRef must be an object")
                    continue
                pointer = reference.get("pointer")
                prefix = "/samples/" + str(index) + "/context"
                if not isinstance(pointer, str) or not (pointer == prefix or pointer.startswith(prefix + "/")):
                    errors.append(label + ": evidence pointer must address this sample's context")
                    continue
                try:
                    _, ancestors = resolve_pointer(pack, pointer)
                except ValueError as error:
                    errors.append(label + ": " + pointer + ": " + str(error))
                    continue
                fact = next((item for item in reversed(ancestors)
                             if isinstance(item, dict) and "factId" in item), None)
                for field in ("factId", "canExpress", "knowledge", "source",
                              "observedAtGameTotalMinutes", "speakerId"):
                    if field in reference and (fact is None or field not in fact or reference[field] != fact[field]):
                        errors.append(label + ": evidence " + field + " differs from referenced fact")


def validate(pack_path, review_path):
    pack, pack_sha = load(pack_path)
    review, review_sha = load(review_path)
    errors = []
    for label, document in (("pack", pack), ("review", review)):
        if type(document.get("schemaVersion")) is not int or document["schemaVersion"] != 1:
            errors.append(label + ": schemaVersion must be 1")
    if not isinstance(pack.get("packId"), str) or not pack["packId"] or review.get("packId") != pack["packId"]:
        errors.append("review packId does not match blind pack")
    hashes = [review[field] for field in ("inputSha256", "inputSHA256") if field in review]
    if not hashes or any(value != pack_sha for value in hashes):
        errors.append("review input SHA256 does not match exact blind pack bytes")
    if "completed" in review and review["completed"] is not True:
        errors.append("review completed flag is not true")
    expected, pack_duplicates = sample_index(pack, errors, "pack")
    reviewed, review_duplicates = sample_index(review, errors, "review")
    missing, extra = sorted(expected.keys() - reviewed.keys()), sorted(reviewed.keys() - expected.keys())
    if missing:
        errors.append("review is missing " + str(len(missing)) + " pack samples")
    if extra:
        errors.append("review contains " + str(len(extra)) + " samples outside the pack")
    claim_ids = set()
    included = []
    for identifier, (_, sample) in reviewed.items():
        if identifier not in expected:
            continue
        index, source = expected[identifier]
        label = identifier
        text = source.get("committedTranscript", {}).get("text")
        text_fields = [sample[field] for field in ("text", "committedText") if field in sample]
        if not text_fields or any(value != text for value in text_fields):
            errors.append(label + ": committed text differs from source")
        if "gameMinutes" in sample and sample["gameMinutes"] != source.get("committedTranscript", {}).get("gameMinutes"):
            errors.append(label + ": gameMinutes differs from source")
        if "inputSampleIndex" in sample and (type(sample["inputSampleIndex"]) is not int or sample["inputSampleIndex"] != index):
            errors.append(label + ": inputSampleIndex differs from source")
        if "inputPointer" in sample and sample["inputPointer"] != "/samples/" + str(index):
            errors.append(label + ": inputPointer differs from source")
        if "reviewComplete" in sample and sample["reviewComplete"] is not True:
            errors.append(label + ": reviewComplete is not true")
        claims = sample.get("claims")
        if not isinstance(claims, list) or not claims:
            errors.append(label + ": claims must be a nonempty array, including explicit missing-evidence units")
            claims = []
        for claim in claims:
            if not isinstance(claim, dict):
                errors.append(label + ": claim must be an object")
                continue
            claim_id, verdict = claim.get("claimId"), claim.get("verdict")
            if not isinstance(claim_id, str) or not claim_id or claim_id in claim_ids:
                errors.append(label + ": claimId must be nonempty and unique across the review")
            else:
                claim_ids.add(claim_id)
            if not isinstance(verdict, str) or verdict not in VERDICTS:
                errors.append(label + ": unknown verdict")
            if "includedInFactualDenominator" in claim and (type(claim["includedInFactualDenominator"]) is not bool
                    or claim["includedInFactualDenominator"] != (verdict in FACTUAL if isinstance(verdict, str) else False)):
                errors.append(label + ": includedInFactualDenominator differs from verdict rule")
            start, end, quote = claim.get("start"), claim.get("end"), claim.get("quote")
            absent = text is None and verdict == "insufficient_review_evidence" and start is None and end is None and quote is None
            if not absent and not (isinstance(text, str) and isinstance(quote, str) and quote
                    and type(start) is int and type(end) is int and 0 <= start < end <= len(text)
                    and text[start:end] == quote):
                errors.append(label + ": claim quotation must match Unicode code-point [start:end] offsets")
        for dimension in DIMENSIONS:
            status = dimension_status(sample, dimension)
            if not isinstance(status, str) or not status.strip():
                errors.append(label + ": " + dimension + " requires a status")
        if source.get("question") is None and not source.get("targetFactIds") and dimension_status(sample, "qaCoverage") != "N/A":
            errors.append(label + ": qaCoverage must be N/A without a registered question or target facts")
        check_references(sample, pack, index, errors, label)
        included.append(dict(sample, claims=[claim for claim in claims if isinstance(claim, dict)
                                            and isinstance(claim.get("verdict"), str)]))
    coverage = {"expectedSamples": len(expected), "reviewedExpectedSamples": len(included),
        "missingSampleIds": missing, "extraSampleIds": extra,
        "duplicatePackSampleIds": pack_duplicates, "duplicateReviewSampleIds": review_duplicates}
    return {"schemaVersion": 1, "generatedAtUtc": datetime.now(timezone.utc).isoformat(),
        "valid": not errors, "errors": errors, "coverage": coverage,
        "provenance": {"packId": pack.get("packId"), "packSha256": pack_sha,
            "reviewSha256": review_sha},
        "countingRule": "Counts preserve supplied verdicts. Factual N excludes not_factual and insufficient_review_evidence. Conservative issues are clear issue verdicts union ambiguous. Dimensions are distributions, not automatic issue labels.",
        "statisticsTrusted": not errors, "statistics": statistics(included)}


def write_report(report, output=None):
    content = json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
    if output is not None:
        path = Path(output)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
    else:
        print(content, end="")


def main():
    parser = argparse.ArgumentParser(description="Validate exact speech-review coverage, quotes and context references without changing verdicts.")
    parser.add_argument("--pack", required=True, type=Path)
    parser.add_argument("--review", required=True, type=Path)
    parser.add_argument("--output", type=Path, help="New JSON report file; defaults to stdout. Existing files are never overwritten.")
    args = parser.parse_args()
    try:
        report = validate(args.pack, args.review)
        write_report(report, args.output)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    return 0 if report["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
