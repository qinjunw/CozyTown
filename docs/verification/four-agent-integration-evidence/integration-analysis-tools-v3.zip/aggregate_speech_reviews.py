"""Aggregate final supplied speech adjudications after verifying batch provenance."""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from validate_speech_reviews import load, sample_index, statistics, validate, write_report


TERMINAL = {"completed", "host_failure", "incomplete", "initialization_failed"}


def check_identity(pack, pack_sha, identity, errors, label):
    if identity.get("schemaVersion") != 1:
        errors.append(label + ": identity schemaVersion must be 1")
    if identity.get("packId") != pack.get("packId") or identity.get("blindPackSha256") != pack_sha:
        errors.append(label + ": identity packId/SHA differs from exact blind bytes")
    samples, _ = sample_index(pack, errors, label + " blind")
    mappings, _ = sample_index(identity, errors, label + " identity")
    if samples.keys() != mappings.keys():
        errors.append(label + ": blind and identity sample sets differ")
    for _, row in mappings.values():
        if row.get("speechMode") not in ("F", "S") or any(not isinstance(row.get(field), str) or not row[field]
                for field in ("npcId", "scenarioId", "worldId", "speechPath", "manifestPath")):
            errors.append(label + ": identity grouping or evidence fields are missing")
    return {key: value[1] for key, value in samples.items()}, {key: value[1] for key, value in mappings.items()}


def related_file(directory, filename):
    if not isinstance(filename, str) or not filename or filename in (".", "..") or "/" in filename or "\\" in filename or ":" in filename:
        raise ValueError("Provenance filenames must be sibling basenames.")
    path = directory / filename
    if path.resolve().parent != directory.resolve():
        raise ValueError("Provenance file resolves outside its packet directory.")
    return path


def check_source_chain(pack_path, identity_path, pack, identity, provided_packs, errors):
    label = identity_path.name
    if pack.get("isIncrementalBatch") is not True and identity.get("isIncrementalBatch") is not True:
        return {"batchPackId": pack.get("packId"), "kind": "direct_complete_source_packet",
                "sourceFilesComparedToFinal": True}
    result = {"batchPackId": pack.get("packId"), "kind": "incremental_source_packet"}
    try:
        if pack.get("isIncrementalBatch") is not True or identity.get("isIncrementalBatch") is not True:
            raise ValueError("Blind and identity incremental flags differ.")
        names = identity.get("sourcePacketFiles")
        if not isinstance(names, dict):
            raise ValueError("Incremental identity requires both retained source packet filenames.")
        source_pack_path = related_file(identity_path.parent, names.get("blind"))
        source_identity_path = related_file(identity_path.parent, names.get("identity"))
        source, source_sha = load(source_pack_path)
        source_identity, source_identity_sha = load(source_identity_path)
        if identity.get("sourceBlindSha256") != source_sha or identity.get("sourceIdentitySha256") != source_identity_sha:
            raise ValueError("Source packet SHA differs from exact retained bytes.")
        if pack.get("sourcePackId") != source.get("packId") or identity.get("sourcePackId") != source.get("packId"):
            raise ValueError("Incremental sourcePackId differs from retained source packet.")
        if source.get("isIncrementalBatch") is True or source_identity.get("isIncrementalBatch") is True:
            raise ValueError("Incremental provenance must reference complete source packets.")
        source_samples, source_mappings = check_identity(source, source_sha, source_identity, errors, label + " source")
        if any(identity.get(field) != source_identity.get(field)
               for field in ("study", "sourceFiles", "worldDenominator")):
            raise ValueError("Incremental identity differs from its retained source metadata.")
        for sample in pack.get("samples", []):
            if source_samples.get(sample.get("sampleId")) != sample:
                raise ValueError("Incremental sample differs from retained source content.")
        for mapping in identity.get("samples", []):
            if source_mappings.get(mapping.get("sampleId")) != mapping:
                raise ValueError("Incremental mapping differs from retained source identity.")
        previous = identity.get("previousPacks")
        if not isinstance(previous, list):
            raise ValueError("Incremental identity requires previousPacks, including an empty array for its first batch.")
        previous_names = set()
        for item in previous:
            if not isinstance(item, dict):
                raise ValueError("Previous packet provenance must be an object.")
            name = item.get("fileName")
            if not isinstance(name, str) or name == pack_path.name or name in previous_names:
                raise ValueError("Previous packet provenance is duplicated or self-referencing.")
            previous_names.add(name)
            if provided_packs.get(name) != (item.get("sha256"), item.get("packId")):
                raise ValueError("Previous packet SHA/packId is not among the explicit batch inputs.")
        result.update({"sourcePackId": source.get("packId"), "sourceBlindFile": source_pack_path.name,
            "sourceBlindSha256": source_sha, "sourceIdentityFile": source_identity_path.name,
            "sourceIdentitySha256": source_identity_sha, "previousPacks": previous})
    except (OSError, ValueError) as error:
        errors.append(label + ": " + str(error))
    return result


def group_statistics(samples, identities):
    groups = {"bySpeechMode": defaultdict(list), "byNpc": defaultdict(list), "byScenario": defaultdict(list)}
    groups["bySpeechMode"].update({"F": [], "S": []})
    strata = defaultdict(list)
    for sample in samples:
        mapping = identities[sample["sampleId"]]
        for group, field in (("bySpeechMode", "speechMode"), ("byNpc", "npcId"), ("byScenario", "scenarioId")):
            groups[group][mapping[field]].append(sample)
        strata[(mapping["speechMode"], mapping["npcId"], mapping["scenarioId"])].append(sample)
    return {**{name: {key: statistics(rows) for key, rows in sorted(values.items())} for name, values in groups.items()},
        "strata": [{"speechMode": key[0], "npcId": key[1], "scenarioId": key[2], "statistics": statistics(rows)}
                   for key, rows in sorted(strata.items())]}


def aggregate(final_pack_path, final_identity_path, batches):
    pack, pack_sha = load(final_pack_path)
    identity, identity_sha = load(final_identity_path)
    errors, batch_reports, source_chain = [], [], []
    final_samples, identities = check_identity(pack, pack_sha, identity, errors, "final")
    if pack.get("isIncrementalBatch") is True or identity.get("isIncrementalBatch") is True:
        errors.append("final input must be a complete source packet, not an incremental batch")
    worlds = identity.get("worldDenominator")
    if not isinstance(worlds, list):
        errors.append("final identity requires the complete registered world denominator")
        worlds = []
    states = {}
    for world in worlds:
        if not isinstance(world, dict) or not isinstance(world.get("worldId"), str) or world["worldId"] in states:
            errors.append("final world denominator contains an invalid or duplicate world")
            continue
        states[world["worldId"]] = world.get("status")
        if world.get("status") not in TERMINAL | {"not_started"}:
            errors.append("final world denominator still contains nonterminal/unknown state: " + world["worldId"])
    if identity.get("denominator", {}).get("plannedWorlds") != len(worlds):
        errors.append("final planned world count differs from retained world denominator")
    for row in identities.values():
        if states.get(row.get("worldId")) not in TERMINAL:
            errors.append("final sample belongs to a world without terminal evidence: " + row["sampleId"])
    samples, assigned = [], Counter()
    provided_packs = {}
    loaded_batches = []
    for batch_pack_path, batch_identity_path, review_path in batches:
        batch_pack_path, batch_identity_path, review_path = map(Path, (batch_pack_path, batch_identity_path, review_path))
        batch_pack, batch_sha = load(batch_pack_path)
        batch_identity, batch_identity_sha = load(batch_identity_path)
        review, review_sha = load(review_path)
        known = provided_packs.get(batch_pack_path.name)
        if known is not None and known != (batch_sha, batch_pack.get("packId")):
            errors.append("batch basenames must identify a unique packet")
        provided_packs[batch_pack_path.name] = (batch_sha, batch_pack.get("packId"))
        loaded_batches.append((batch_pack_path, batch_identity_path, review_path, batch_pack,
                               batch_sha, batch_identity, batch_identity_sha, review, review_sha))
    for batch_pack_path, batch_identity_path, review_path, batch_pack, batch_sha, batch_identity, batch_identity_sha, review, review_sha in loaded_batches:
        label = review_path.name
        check = validate(batch_pack_path, review_path)
        errors.extend(label + ": " + error for error in check["errors"])
        if not isinstance(review.get("adjudicatorId"), str) or not review["adjudicatorId"].strip():
            errors.append(label + ": an explicit final adjudicatorId is required")
        batch_samples, batch_mappings = check_identity(batch_pack, batch_sha, batch_identity, errors, label)
        source_chain.append(check_source_chain(batch_pack_path, batch_identity_path, batch_pack, batch_identity, provided_packs, errors))
        if batch_identity.get("study") != identity.get("study"):
            errors.append(label + ": batch and final study metadata differ")
        batch_files, final_files = batch_identity.get("sourceFiles", {}), identity.get("sourceFiles", {})
        if not batch_files.get("plan.json") or batch_files.get("plan.json") != final_files.get("plan.json"):
            errors.append(label + ": registered plan source hashes differ or are missing")
        for identifier, sample in batch_samples.items():
            assigned[identifier] += 1
            if final_samples.get(identifier) != sample:
                errors.append(label + ": batch sample differs from final source: " + identifier)
            mapping = batch_mappings.get(identifier)
            if mapping is None or identities.get(identifier) != mapping:
                errors.append(label + ": batch mapping differs from final source: " + identifier)
                continue
            for field in ("speechPath", "manifestPath"):
                relative = mapping.get(field)
                if not batch_files.get(relative) or batch_files.get(relative) != final_files.get(relative):
                    errors.append(label + ": retained " + field + " source hashes differ or are missing")
        reviewer_chain = []
        reviewers = review.get("reviewers")
        if not isinstance(reviewers, dict) or len(reviewers) != 2:
            errors.append(label + ": exactly two independent reviewer provenance entries are required")
            reviewers = {}
        reviewer_files = set()
        for reviewer_label, metadata in reviewers.items():
            try:
                if not isinstance(metadata, dict):
                    raise ValueError("Reviewer provenance must be an object.")
                path = related_file(review_path.parent, metadata.get("file"))
                if path in reviewer_files:
                    raise ValueError("The two reviewer sources must be distinct files.")
                reviewer_files.add(path)
                _, sha = load(path)
                if metadata.get("sha256") != sha:
                    raise ValueError("Independent reviewer SHA differs from retained file.")
                reviewer_check = validate(batch_pack_path, path)
                errors.extend(label + "/reviewer " + reviewer_label + ": " + error for error in reviewer_check["errors"])
                reviewer_chain.append({"reviewer": reviewer_label, "file": path.name, "sha256": sha})
            except (OSError, ValueError) as error:
                errors.append(label + ": " + str(error))
        batch_reports.append({"packId": batch_pack.get("packId"), "packFile": batch_pack_path.name,
            "packSha256": batch_sha, "identityFile": batch_identity_path.name, "identitySha256": batch_identity_sha,
            "adjudicationFile": review_path.name, "adjudicationSha256": review_sha,
            "reviewers": reviewer_chain, "coverage": check["coverage"], "statistics": check["statistics"]})
        samples.extend(row for row in review.get("samples", []) if isinstance(row, dict))
    missing = sorted(final_samples.keys() - assigned.keys())
    extra = sorted(assigned.keys() - final_samples.keys())
    duplicates = sorted(identifier for identifier, count in assigned.items() if count > 1)
    if missing or extra or duplicates:
        errors.append("adjudicated batch sample union must equal final sample set exactly, without duplicates")
    return {"schemaVersion": 1, "generatedAtUtc": datetime.now(timezone.utc).isoformat(),
        "valid": not errors, "errors": errors, "study": identity.get("study"),
        "coverage": {"finalSampleRows": len(final_samples), "assignedSampleRows": sum(assigned.values()),
            "uniqueAssignedSamples": len(assigned), "missingSampleIds": missing,
            "extraSampleIds": extra, "duplicateSampleIds": duplicates},
        "worldDenominator": worlds, "worldStatusCounts": dict(Counter(states.values())),
        "sourceDenominator": identity.get("denominator"),
        "finalProvenance": {"packId": pack.get("packId"), "packSha256": pack_sha, "identitySha256": identity_sha,
            "sourceFiles": identity.get("sourceFiles")}, "batches": batch_reports, "sourceChain": source_chain,
        "countingRule": "Supplied final adjudications only. Conservative issues are clear verdicts union ambiguous. Missing evidence is separate from no-factual speech. Dimension labels are distributions, not automatic problem classifications.",
        "statistics": statistics(samples) if not errors else None,
        "groups": group_statistics(samples, identities) if not errors else None}


def main():
    parser = argparse.ArgumentParser(description="Verify complete speech-review union and provenance, then aggregate supplied final verdicts.")
    parser.add_argument("--final-pack", required=True, type=Path)
    parser.add_argument("--final-identity", required=True, type=Path)
    parser.add_argument("--batch", required=True, action="append", nargs=3, type=Path,
                        metavar=("BLIND", "IDENTITY", "ADJUDICATED"), help="Repeat once per adjudicated batch.")
    parser.add_argument("--output", required=True, type=Path, help="New aggregate JSON path; existing files are never overwritten.")
    args = parser.parse_args()
    try:
        report = aggregate(args.final_pack, args.final_identity, args.batch)
        write_report(report, args.output)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    return 0 if report["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
