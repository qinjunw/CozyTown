"""Summarize registered experiment evidence without writing inside the study."""

import argparse
import hashlib
import json
import math
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


NPCS = ("npc.shopkeeper_mina", "npc.farmer_eli", "npc.fisher_ren", "npc.cook_sora")


def read_bytes(path):
    if os.name != "nt":
        return path.read_bytes()
    import ctypes
    import msvcrt
    from ctypes import wintypes
    create = ctypes.WinDLL("kernel32", use_last_error=True).CreateFileW
    create.argtypes = (wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                       wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE)
    create.restype = wintypes.HANDLE
    handle = create(str(path), 0x80000000, 7, None, 3, 0x80, None)
    if handle == wintypes.HANDLE(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    with os.fdopen(msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY), "rb") as stream:
        return stream.read()


def parse(value):
    return json.loads(value, parse_constant=lambda item: (_ for _ in ()).throw(ValueError(item)))


def embedded(value):
    if not isinstance(value, str) or not value:
        return None
    try:
        result = parse(value)
        return result if isinstance(result, dict) else None
    except (ValueError, TypeError):
        return None


def day_of(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        return "unknown"
    return "D" + str(math.floor(value / 1440) + 1)


class Evidence:
    def __init__(self, root):
        self.root, self.files, self.warnings = root, {}, []

    def load(self, relative, lines=False):
        path = self.root / relative
        try:
            raw = read_bytes(path)
        except FileNotFoundError:
            return None
        except OSError as error:
            self.warnings.append({"path": relative, "error": type(error).__name__})
            return None
        self.files[relative] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        try:
            text = raw.decode("utf-8-sig")
            if not lines:
                return parse(text)
            result = []
            for number, line in enumerate(text.splitlines(), 1):
                if not line.strip():
                    continue
                try:
                    result.append(parse(line))
                except ValueError:
                    self.warnings.append({"path": relative, "line": number, "error": "invalid_json_line"})
            return result
        except (ValueError, UnicodeError):
            self.warnings.append({"path": relative, "error": "invalid_json_or_encoding"})
            return None


def utc_evidence(result, ledger, timeline):
    provider = [row for row in ledger if row.get("event") == "provider_started"]
    return {
        "result": {key: result.get(key) for key in ("startedAtUtc", "cleanupStartedAtUtc", "finishedAtUtc")},
        "ledger": [{key: row.get(key) for key in ("event", "recordedAtUtc", "reason", "status")}
                   for row in ledger if row.get("event") != "provider_started"],
        "firstTimelineAtUtc": timeline[0].get("recordedAtUtc") if timeline else None,
        "lastTimelineAtUtc": timeline[-1].get("recordedAtUtc") if timeline else None,
        "firstProviderAdmissionAtUtc": provider[0].get("recordedAtUtc") if provider else None,
        "lastProviderAdmissionAtUtc": provider[-1].get("recordedAtUtc") if provider else None,
    }


def point(row):
    return {key: row.get(key) for key in ("tick", "worldRunId", "gameMinutes", "realSeconds", "recordedAtUtc")}


def npc_summary(npc_id, calls, outcomes, timeline, attempts):
    def new_day():
        context_n = None if calls is None else 0
        sample_n = None if timeline is None else 0
        return {"dispatches": context_n, "outcomes": None if outcomes is None else 0, "outcomeCodes": {},
            "providerAttemptsMatchedToTrace": None if attempts is None else 0,
            "firstDispatch": None, "lastDispatch": None,
            "firstRetainedRequestContexts": {"dispatchedDecisionN": context_n,
                "step1N": context_n, "resumedOrUnknownFirstStepN": context_n,
                "decisionsWithTriggerKind": None if calls is None else {},
                "triggerArrayKnownN": context_n, "triggerArrayUnknownN": context_n,
                "unknownTriggerEntriesN": context_n,
                "persona": {"stringKnownN": context_n, "unknownN": context_n, "nonemptyN": context_n,
                    "stringValues": None if calls is None else []},
                "socialMemories": {"arrayKnownN": context_n, "unknownN": context_n,
                    "nonemptyN": context_n, "maxCount": None},
                "sources": None if calls is None else []},
            "timelineStateObservations": {"rowN": sample_n, "residentRecordN": sample_n,
                "firstSample": None, "lastSample": None,
                **{flag: {"trueN": sample_n, "falseN": sample_n, "unknownN": sample_n}
                    for flag in ("hasPending", "hasWaitingTurn", "hasCurrent")}}}
    days = {key: new_day() for key in ("D1", "D2")}
    def bucket(day):
        if day not in days:
            days[day] = new_day()
        return days[day]
    for call, request in calls or []:
        if request.get("npcId") != npc_id:
            continue
        values = bucket(day_of(request.get("gameTotalMinutes")))
        values["dispatches"] += 1
        at = {"callOrdinal": call.get("callOrdinal"), "tick": call.get("dispatchTick"),
              "gameMinutes": request.get("gameTotalMinutes"), "realSeconds": call.get("dispatchRealSeconds")}
        values["firstDispatch"] = values["firstDispatch"] or at
        values["lastDispatch"] = at
        if attempts is not None:
            values["providerAttemptsMatchedToTrace"] += sum(
                attempt.get("decisionId") == request.get("decisionId") and attempt.get("step") == request.get("step")
                and attempt.get("npcId") == npc_id for attempt in attempts)
    seen_decisions = set()
    retained = sorted(enumerate(calls or []), key=lambda entry:
        entry[1][0].get("callOrdinal") if type(entry[1][0].get("callOrdinal")) is int else entry[0])
    for trace_index, (call, request) in retained:
        if request.get("npcId") != npc_id:
            continue
        identifier = request.get("decisionId")
        key = ("id", identifier) if isinstance(identifier, str) and identifier.strip() else ("trace", trace_index)
        if key in seen_decisions:
            continue
        seen_decisions.add(key)
        context = bucket(day_of(request.get("gameTotalMinutes")))["firstRetainedRequestContexts"]
        context["dispatchedDecisionN"] += 1
        context["step1N" if request.get("step") == 1 else "resumedOrUnknownFirstStepN"] += 1
        triggers = request.get("triggers")
        if isinstance(triggers, list):
            context["triggerArrayKnownN"] += 1
            kinds = set()
            for trigger in triggers:
                kind = trigger.get("kind") if isinstance(trigger, dict) else None
                if isinstance(kind, str) and kind.strip():
                    kinds.add(kind)
                else:
                    context["unknownTriggerEntriesN"] += 1
            for kind in sorted(kinds):
                context["decisionsWithTriggerKind"][kind] = context["decisionsWithTriggerKind"].get(kind, 0) + 1
        else:
            context["triggerArrayUnknownN"] += 1
        persona = request.get("persona")
        if isinstance(persona, str):
            context["persona"]["stringKnownN"] += 1
            context["persona"]["nonemptyN"] += bool(persona.strip())
            if persona not in context["persona"]["stringValues"]:
                context["persona"]["stringValues"].append(persona)
        else:
            context["persona"]["unknownN"] += 1
        social = request.get("social")
        memories = social.get("memories") if isinstance(social, dict) else None
        if isinstance(memories, list):
            context["socialMemories"]["arrayKnownN"] += 1
            context["socialMemories"]["nonemptyN"] += bool(memories)
            context["socialMemories"]["maxCount"] = max(context["socialMemories"]["maxCount"] or 0, len(memories))
        else:
            context["socialMemories"]["unknownN"] += 1
        context["sources"].append({"traceCallIndex": trace_index, "callOrdinal": call.get("callOrdinal"),
            "decisionId": identifier, "worldRunId": request.get("worldRunId"), "step": request.get("step")})
    for outcome, request in outcomes or []:
        if outcome.get("npcId") != npc_id:
            continue
        values = bucket(day_of(request.get("gameTotalMinutes")))
        values["outcomes"] += 1
        code = outcome.get("code") or "unknown"
        values["outcomeCodes"][code] = values["outcomeCodes"].get(code, 0) + 1
    samples, previous, phases, releases, body_states = [], None, [], [], Counter()
    for row_index, row in enumerate(timeline or []):
        resident = next((item for item in row.get("residents") or []
            if isinstance(item, dict) and item.get("npcId") == npc_id), None)
        observations = bucket(day_of(row.get("gameMinutes")))["timelineStateObservations"]
        observations["rowN"] += 1
        observations["residentRecordN"] += resident is not None
        at = point(row) | {"timelineRecordIndex": row_index}
        observations["firstSample"] = observations["firstSample"] or at
        observations["lastSample"] = at
        for flag in ("hasPending", "hasWaitingTurn", "hasCurrent"):
            value = (resident or {}).get(flag)
            observations[flag]["trueN" if value is True else "falseN" if value is False else "unknownN"] += 1
        if resident is None:
            continue
        samples.append((row, resident))
        body_states[resident.get("bodyStatus") or "unknown"] += 1
        phase = resident.get("meetingState") or None
        if previous is None or phase != (previous[1].get("meetingState") or None) or row.get("worldRunId") != previous[0].get("worldRunId"):
            phases.append(point(row) | {"meetingState": phase})
        if previous is not None and previous[1].get("hasActivity") is True and resident.get("hasActivity") is False:
            releases.append(point(row) | {"previousActivity": previous[1].get("activity"),
                "sameWorldRun": row.get("worldRunId") == previous[0].get("worldRunId")})
        previous = (row, resident)
    return {"npcId": npc_id, "days": days, "timelineSamples": len(samples) if timeline is not None else None,
            "meetingPhaseSamples": phases, "activityReleaseSamples": releases,
            "bodyStatusSampleCounts": dict(body_states),
            "lastObservedState": None if not samples else point(samples[-1][0]) | samples[-1][1]}


def model_summary(world, manifest, proxy, attempts):
    configuration = embedded(world.get("clientConfigurationJson")) or {}
    calls = (manifest.get("trace") or {}).get("calls", [])
    rows = proxy if proxy is not None else []
    requested = sorted({row.get("requestedModel") for row in rows + calls if row.get("requestedModel")})
    returned = sorted({row.get("returnedModel") for row in rows + calls if row.get("returnedModel")})
    usage = {}
    for field in ("promptTokens", "completionTokens", "totalTokens"):
        known = [row[field] for row in rows if type(row.get(field)) is int and row[field] >= 0]
        usage[field] = sum(known) if attempts is not None and attempts > 0 and len(known) == attempts == len(rows) else None
        usage["known" + field[0].upper() + field[1:]] = sum(known) if known else None
        usage[field + "KnownRecords"] = len(known)
    return {"declaredRequestedModel": configuration.get("model"), "observedRequestedModels": requested or None,
            "observedReturnedModels": returned or None, "providerMeasurementRecords": None if proxy is None else len(proxy),
            "usage": usage, "cost": None}


def speech_summary(speech, results):
    rows = speech.get("rows") if isinstance(speech, dict) else None
    accepted = [index for index, result in enumerate(results) if result.get("code") == "meeting.say"] if results is not None else None
    committed = [row for row in rows or [] if row.get("source") == "committed_transcript" and row.get("text")]
    usable_indices = {row.get("outcomeIndex") for row in committed}
    return {"acceptedOutcomes": len(accepted) if accepted is not None else (speech or {}).get("acceptedSpeechOutcomes"),
            "declaredAcceptedOutcomes": (speech or {}).get("acceptedSpeechOutcomes"),
            "evidenceRows": None if rows is None else len(rows), "committedTextRows": None if rows is None else len(committed),
            "missingAcceptedOutcomeIndices": None if accepted is None else [index for index in accepted if index not in usable_indices],
            "rowsWithMissingReasons": [{key: row.get(key) for key in ("outcomeIndex", "npcId", "missingReason")}
                                       for row in rows or [] if row.get("missingReason")],
            "uniqueEvidenceOutcomeIndices": None if rows is None else len({row.get("outcomeIndex") for row in rows})}


def summarize(study):
    evidence = Evidence(study)
    plan, status = evidence.load("plan.json"), evidence.load("status.json")
    if not isinstance(plan, dict) or not isinstance(plan.get("worlds"), list):
        raise ValueError("A registered plan with its complete world denominator is required.")
    status = status if isinstance(status, dict) else {}
    ledger = evidence.load("ledger.jsonl", lines=True)
    worlds, pairs = [], {}
    for world in plan["worlds"]:
        ordinal, world_id = world.get("ordinal"), world.get("worldId")
        if type(ordinal) is not int or not isinstance(world_id, str) or not world_id.isalnum():
            raise ValueError("Registered worlds require integer ordinals and alphanumeric identities.")
        directory = f"{ordinal:02}-{world_id}"
        row = next((item for item in status.get("worlds", []) if item.get("worldId") == world_id), {})
        result = evidence.load(directory + "/result.json") or row.get("result") or {}
        manifest = evidence.load(directory + "/package/manifest.json") or {}
        timeline = evidence.load(directory + "/timeline.jsonl", lines=True)
        speech = evidence.load(directory + "/speech.json")
        proxy = evidence.load(directory + "/proxy.jsonl", lines=True)
        events = [event for event in ledger or [] if event.get("worldId") == world_id]
        provider_events = [event for event in events if event.get("event") == "provider_started"] if ledger is not None else None
        raw_calls = (manifest.get("trace") or {}).get("calls")
        raw_results = manifest.get("results")
        calls = None if raw_calls is None else [(call, embedded(call.get("requestJson")) or {}) for call in raw_calls]
        outcomes = None if raw_results is None else [(outcome, embedded(outcome.get("requestJson")) or {}) for outcome in raw_results]
        summary = {key: world.get(key) for key in ("worldId", "ordinal", "repetition", "pairId", "armOrder", "scenarioId", "speechMode", "stage")}
        summary.update({"directory": directory, "status": row.get("status", "unknown"),
            "coordinatorReason": row.get("reason"), "resultStatus": result.get("status"), "resultReason": result.get("reason"),
            "hostViolations": result.get("hostViolations"), "replayPassed": result.get("replayPassed"),
            "manifestCompleted": manifest.get("completed"), "initialized": result.get("initialized"),
            "providerAttempts": row.get("attemptedProviderCalls"),
            "providerAttemptLedgerRows": None if provider_events is None else len(provider_events),
            "hostCalls": result.get("hostRequests", timeline[-1].get("requests") if timeline else None),
            "traceCalls": None if calls is None else len(calls), "outcomes": None if outcomes is None else len(outcomes),
            "completedGameMinutes": result.get("completedGameMinutes"), "realSeconds": result.get("realSeconds"),
            "initialProxyStatus": row.get("initialProxyStatus"), "proxyCleanup": row.get("proxyCleanup"),
            "timelineSamples": len(timeline) if timeline is not None else None,
            "maxObservedInFlight": max((sample.get("inFlight", 0) for sample in timeline or []), default=None),
            "maxObservedWaitingResidents": max((sample.get("waitingResidents", 0) for sample in timeline or []), default=None),
            "npcs": [npc_summary(npc, calls, outcomes, timeline, provider_events) for npc in NPCS],
            "speech": speech_summary(speech, raw_results),
            "model": model_summary(world, manifest, proxy, row.get("attemptedProviderCalls")),
            "utcEvidence": utc_evidence(result, events, timeline)})
        worlds.append(summary)
        pair = pairs.setdefault(world.get("pairId"), {"pairId": world.get("pairId"), "scenarioId": world.get("scenarioId"),
            "repetition": world.get("repetition"), "worldIds": [], "status": "not_compared", "reportPath": None, "report": None})
        pair["worldIds"].append(world_id)
        report_path = directory + "/pair-context.json"
        report = evidence.load(report_path)
        if isinstance(report, dict):
            pair.update(status="recorded", reportPath=report_path, report=report)
    return {"schemaVersion": 1, "generatedAtUtc": datetime.now(timezone.utc).isoformat(), "evidenceDirectoryName": study.name,
        "study": {key: plan.get(key) for key in ("studyId", "stage", "sourceRevision", "evaluationPlanReference", "createdAtUtc",
            "expressionContractVersion", "scriptVersion", "maxProviderCalls", "proxyCleanupTimeoutSeconds", "sourceSha256", "systemPromptSha256")}
            | {"state": status.get("state"), "providerAttempts": status.get("attemptedProviderCalls")},
        "counts": {"plannedWorlds": len(plan["worlds"]), "worldStatuses": dict(Counter(world["status"] for world in worlds)),
            "plannedPairs": len(pairs), "recordedPairComparisons": sum(pair["status"] == "recorded" for pair in pairs.values())},
        "definitions": {"dispatchDay": "Day of trace request gameTotalMinutes.",
            "outcomeDay": "Day of outcome request context; this is not the completion wall-clock day.",
            "timeline": "Meeting phases, activity releases and body states are sampled observations; transitions may span a load or skipped game time.",
            "firstRetainedRequestContexts": "Per NPC, retain the smallest callOrdinal request per nonempty decisionId across the whole world, then assign its request-context game day. Corrections and disclosure continuations do not count again. Missing IDs remain separate trace records; first retained steps above 1 are reported explicitly. This describes dispatched contexts, not unobserved decisions or event totals.",
            "decisionsWithTriggerKind": "Number of retained dispatched decisions containing each trigger kind, at most once per decision/kind. Multiple labels can occur in one decision; this is not the number of original world events.",
            "personaAndMemories": "Exact persona string values and nonempty coverage, plus known/nonempty/max social.memories array sizes, on first retained contexts. Empty strings and arrays are known empty; absent or wrong-type fields are unknown. These fields establish context inclusion, not whether the model used it or acted consistently with it.",
            "timelineStateObservations": "Per game day, count observed true/false/unknown hasPending, hasWaitingTurn and hasCurrent values. Missing NPC rows count unknown. Sources use zero-based parsed timelineRecordIndex, not physical JSONL line numbers; traceCallIndex refers to manifest.trace.calls. Samples can repeat around loads and are neither unique waiting events nor exact budget-wait durations.",
            "null": "Unavailable or not established by retained evidence; unknown model tokens and cost are not zero.",
            "pairComparison": "Copies the Unity pair-context report. Missing report means not compared; a null divergence alone does not establish comparison.",
            "generatedAtUtc": "Summary generation time; source event times are retained separately.",
            "evidenceSnapshot": "Files are read once with shared access. If a study is running, this report is a partial observation, not an atomic completed snapshot."},
        "worlds": worlds, "pairs": list(pairs.values()), "evidenceFiles": evidence.files, "warnings": evidence.warnings}


def main():
    parser = argparse.ArgumentParser(description="Read registered world evidence and write a portable summary outside the study.")
    parser.add_argument("--study", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    study, output = args.study.resolve(), args.output.resolve()
    if output.is_relative_to(study):
        parser.error("The summary output must be outside the source study directory.")
    if output.exists():
        parser.error("Choose a new output file to preserve earlier summaries.")
    result = summarize(study)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
    print(json.dumps({"studyId": result["study"]["studyId"], "counts": result["counts"], "warnings": len(result["warnings"])}))


if __name__ == "__main__":
    main()
