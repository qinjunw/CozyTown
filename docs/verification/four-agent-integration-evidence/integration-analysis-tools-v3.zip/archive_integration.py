"""Archive a stopped integration study and retain hashes of its source evidence."""

import argparse
import hashlib
import json
import ntpath
import os
from pathlib import Path
import re
import sys
from datetime import datetime, timezone
import zipfile


CREDENTIAL_NAME = re.compile(r"credential|secret|api[_-]?key|private[_-]?key|my_test_api|cozytown[_-]?key", re.I)
LOCAL_PATH = re.compile(
    r'(?:^/|^~/|(?<![A-Za-z0-9])(?:[A-Za-z]:[\\/]|\\\\|/(?:Users|home|tmp|var|private|mnt|Volumes|workspace|workspaces|opt|root|data)/))'
    r'[^\x00-\x1f"<>|]*')
WORLD_FILES = ("options.json", "initial.json", "initialized.json", "progress.json",
               "result.json", "speech.json", "timeline.jsonl",
               "package/manifest.json", "package/initial.json", "package/final.json",
               "replay/manifest.json", "replay/initial.json", "replay/final.json")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


def parse(data, relative):
    try:
        text = data.decode("utf-8-sig")
        if relative.endswith(".jsonl"):
            return [json.loads(line) for line in text.splitlines() if line.strip()]
        return json.loads(text)
    except (UnicodeError, ValueError) as error:
        raise ValueError("Invalid JSON evidence: " + relative) from error


def inventory(study):
    found = []
    for directory, dirs, files in os.walk(study, followlinks=False):
        for name in dirs + files:
            entry = Path(directory) / name
            relative = entry.relative_to(study).as_posix()
            if entry.is_symlink() or (hasattr(entry, "is_junction") and entry.is_junction()):
                raise ValueError("Study contains a link; no targets were read: " + relative)
            if CREDENTIAL_NAME.search(name) or name == ".env" or name.startswith(".env."):
                raise ValueError("Study contains a credential-like name; no contents were read: " + relative)
        for name in files:
            if Path(name).suffix.lower() in (".json", ".jsonl"):
                found.append((Path(directory) / name).relative_to(study).as_posix())
    return sorted(found)


class Paths:
    def __init__(self, study):
        self.root = self.normalized(str(study)).rstrip("/")

    @staticmethod
    def normalized(value):
        return ntpath.normpath(value).replace("\\", "/")

    def inside(self, value):
        value = self.normalized(value)
        if value.casefold() == self.root.casefold():
            return ""
        if value.casefold().startswith(self.root.casefold() + "/"):
            return value[len(self.root) + 1:]
        return None

    def visit(self, value, location, authoritative, findings, pointer_locations=()):
        if isinstance(value, dict):
            return {key: self.visit(item, location + "/" + key.replace("~", "~0").replace("/", "~1"),
                                    authoritative, findings, pointer_locations) for key, item in value.items()}
        if isinstance(value, list):
            return [self.visit(item, location + "/" + str(index), authoritative, findings, pointer_locations)
                    for index, item in enumerate(value)]
        if not isinstance(value, str):
            return value
        if location in pointer_locations and (not value or value.startswith("/")) and not re.search(r"~(?![01])|[\x00-\x1f]", value):
            return value
        # A trace or configuration can contain JSON encoded in a JSON string.
        if value.lstrip().startswith(("{", "[")):
            try:
                embedded = json.loads(value)
            except ValueError:
                pass
            else:
                before = len(findings)
                changed = self.visit(embedded, location + "/<encoded-json>", authoritative, findings, pointer_locations)
                if not authoritative and len(findings) != before:
                    return json.dumps(changed, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
                return value

        def replace(match):
            original = match.group(0)
            relative = self.inside(original)
            replacement = ("<study-root>" + ("/" + relative if relative else "")) if relative is not None else "<external-path:" + sha(original.encode("utf-8"))[:16] + ">"
            findings.append({"location": location, "pathSha256": sha(original.encode("utf-8")),
                             "strategy": "preserved_authoritative" if authoritative else
                                         "study_root_relative" if relative is not None else "external_path_marker",
                             "publicValue": None if authoritative else replacement})
            return original if authoritative else replacement

        return LOCAL_PATH.sub(replace, value)


def pair_coverage(plan, documents, paths):
    groups = {}
    for world in plan.get("worlds", []):
        groups.setdefault(world.get("pairId"), []).append(world)
    pairs, required = [], set()
    for pair_id, worlds in groups.items():
        worlds = sorted(worlds, key=lambda world: world.get("ordinal", 0))
        item = {"pairId": pair_id, "worldIds": [world.get("worldId") for world in worlds], "issues": []}
        if not pair_id or len(worlds) != 2 or {world.get("speechMode") for world in worlds} != {"F", "S"}:
            item["issues"].append("Plan must contain exactly one F arm and one S arm for this pair.")
        else:
            order = [world["speechMode"] for world in worlds]
            if any(world.get("armOrder") != order for world in worlds):
                item["issues"].append("Plan armOrder does not match the recorded world ordinals.")
            if len({(world.get("scenarioId"), world.get("repetition")) for world in worlds}) != 1:
                item["issues"].append("Paired worlds differ in scenario or repetition.")
            first, second = (paths.inside(world.get("outputDirectory", "")) for world in worlds)
            item["report"] = None if second is None else second + "/pair-context.json"
            if item["report"] is not None:
                required.add(item["report"])
            report = documents.get(item["report"])
            if report is None:
                item["issues"].append("The second arm has no pair-context.json report.")
            else:
                ids = {world["speechMode"]: world.get("worldId") for world in worlds}
                if (report.get("schemaVersion") != 1 or report.get("pairId") != pair_id
                        or report.get("freeTextWorldId") != ids["F"]
                        or report.get("structuredFactsWorldId") != ids["S"]
                        or report.get("comparedRecordedPrefix") is not True):
                    item["issues"].append("Pair report schema, arm identities or comparison declaration does not match the plan.")
            if first is not None and first + "/pair-context.json" in documents:
                item["issues"].append("The first arm unexpectedly contains a pair report.")
        item["covered"] = not item["issues"]
        pairs.append(item)
    return pairs, required


def completeness(documents, paths):
    plan, status = documents.get("plan.json", {}), documents.get("status.json", {})
    pairs, required_pair_reports = pair_coverage(plan, documents, paths)
    result = {"studyState": status.get("state"), "stage": plan.get("stage"),
              "sourceRevision": plan.get("sourceRevision"), "plannedWorlds": len(plan.get("worlds", [])),
              "missingStudyArtifacts": [name for name in ("plan.json", "status.json", "ledger.jsonl", "active-world.json") if name not in documents],
              "plannedPairs": len(pairs), "coveredPairs": sum(pair["covered"] for pair in pairs), "pairs": pairs,
              "completedWorlds": 0, "replayPassedWorlds": 0, "worlds": []}
    states = {world.get("worldId"): world for world in status.get("worlds", [])}
    for world in plan.get("worlds", []):
        directory = paths.inside(world.get("outputDirectory", ""))
        state = states.get(world.get("worldId"), {})
        item = {"ordinal": world.get("ordinal"), "worldId": world.get("worldId"),
                "status": state.get("status", "unknown"), "directory": directory,
                "missingWorldDirectory": directory is None or not any(name.startswith(directory + "/") for name in documents)}
        if item["missingWorldDirectory"]:
            item["missingArtifacts"] = ["<world-directory>"]
        else:
            item["missingArtifacts"] = [name for name in WORLD_FILES if directory + "/" + name not in documents]
            if directory + "/pair-context.json" in required_pair_reports and directory + "/pair-context.json" not in documents:
                item["missingArtifacts"].append("pair-context.json")
            if plan.get("stage") == "live" and directory + "/proxy.jsonl" not in documents:
                item["missingArtifacts"].append("proxy.jsonl")
            for subtree in ("package", "replay"):
                manifest = documents.get(directory + "/" + subtree + "/manifest.json", {})
                for label in manifest.get("checkpointLabels", []):
                    checkpoint = subtree + "/checkpoint-" + label + ".json"
                    if directory + "/" + checkpoint not in documents:
                        item["missingArtifacts"].append(checkpoint)
            outcome = documents.get(directory + "/result.json", {})
            result["completedWorlds"] += outcome.get("status") == "completed"
            result["replayPassedWorlds"] += outcome.get("replayPassed") is True
        result["worlds"].append(item)
    result["completeForPlannedStudy"] = (result["studyState"] == "finished" and result["plannedWorlds"] > 0
        and result["completedWorlds"] == result["plannedWorlds"]
        and result["replayPassedWorlds"] == result["plannedWorlds"]
        and result["plannedPairs"] > 0 and result["coveredPairs"] == result["plannedPairs"]
        and not result["missingStudyArtifacts"]
        and not any(world["missingArtifacts"] for world in result["worlds"]))
    return result


def archive(study, output):
    if study.is_symlink() or (hasattr(study, "is_junction") and study.is_junction()):
        raise ValueError("The study root must be a directory rather than a link.")
    study, output = study.resolve(strict=True), output.absolute()
    if not study.is_dir() or output.suffix.lower() != ".zip":
        raise ValueError("Choose a study directory and a new .zip output file.")
    adjacent = output.with_suffix(".manifest.json")
    if output.exists() or adjacent.exists():
        raise ValueError("Archive or adjacent manifest already exists; choose a new output name.")
    if output.is_relative_to(study) or adjacent.is_relative_to(study):
        raise ValueError("Write outputs outside the study so evidence inventory cannot include an earlier archive.")
    names = inventory(study)
    if "plan.json" not in names or "status.json" not in names:
        raise ValueError("A coordinated study must contain plan.json and status.json.")
    source = {name: (study / name).read_bytes() for name in names}
    documents = {name: parse(data, name) for name, data in source.items()}
    if documents["status.json"].get("state") not in ("aborted", "finished"):
        raise ValueError("Archive only a stopped study whose status is aborted or finished.")
    paths, records, public = Paths(study), [], {}
    for name in names:
        authoritative = any(part in ("package", "replay") for part in Path(name).parts[:-1])
        findings = []
        pointers = ("/firstDivergence/path",) if not authoritative and Path(name).name == "pair-context.json" else ()
        converted = paths.visit(documents[name], "", authoritative, findings, pointers)
        data = source[name]
        if findings and not authoritative:
            data = (("\n".join(json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
                                    for row in converted) + "\n").encode("utf-8")
                    if name.endswith(".jsonl") else dump(converted))
        public[name] = data
        records.append({"file": name, "authoritative": authoritative,
                        "originalSha256": sha(source[name]), "publicSha256": sha(data),
                        "originalBytes": len(source[name]), "publicBytes": len(data), "pathFindings": findings})
    blocked = sum(len(row["pathFindings"]) for row in records if row["authoritative"])
    external = sum(finding["strategy"] == "external_path_marker" for row in records for finding in row["pathFindings"])
    manifest = {"schemaVersion": 1, "createdAtUtc": datetime.now(timezone.utc).isoformat(),
        "studyId": documents["plan.json"].get("studyId"), "archive": output.name,
        "scriptSha256": sha(Path(__file__).read_bytes()), "sourceRoot": "<study-root>",
        "pathPolicy": {"authoritative": "package/ and replay/ JSON/JSONL bytes are unchanged; machine paths are reported, never rewritten.",
                       "envelope": "Study-local absolute filesystem paths become <study-root>/relative paths; external paths become SHA256 markers. Unchanged files retain their bytes.",
                       "scope": "All JSON/JSONL below the study root; links and credential-like names are rejected before reading. No referenced paths are opened.",
                       "scanner": "Decoded JSON string values and embedded JSON; Windows drive/UNC, leading Unix absolute/home-relative paths, and common Unix roots embedded in text. URI endpoints and other relative paths are unchanged.",
                       "jsonPointers": "The schema-defined firstDivergence.path in pair-context.json is retained as a JSON Pointer; other path fields remain subject to filesystem-path scanning.",
                       "missingArtifacts": "Expected coordinated-study artifacts are reported even when an aborted world never produced them. Each plan pair requires one identity-matched report from its second arm; the first arm produces none."},
        "publicationReady": blocked == 0 and external == 0,
        "authoritativeMachinePathFindings": blocked, "externalEnvelopePathFindings": external,
        "fileCount": len(names), "originalBytes": sum(map(len, source.values())),
        "publicBytes": sum(map(len, public.values())),
        "completeness": completeness(documents, paths), "files": records}
    # Check evidence again before publishing; no archive may silently mix a changing study.
    if inventory(study) != names or any((study / name).read_bytes() != source[name] for name in names):
        raise ValueError("Study evidence changed during collection; retry after all writers stop.")
    output.parent.mkdir(parents=True, exist_ok=True)
    with adjacent.open("xb") as manifest_file:
        with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
            for name in names:
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                bundle.writestr(info, public[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        archive_bytes = output.read_bytes()
        manifest["archiveBytes"], manifest["archiveSha256"] = len(archive_bytes), sha(archive_bytes)
        manifest_file.write(dump(manifest))
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", required=True, type=Path, help="Stopped study containing plan.json and status.json.")
    parser.add_argument("--output", required=True, type=Path, help="New ZIP path; an adjacent .manifest.json is also created.")
    options = parser.parse_args()
    try:
        manifest = archive(options.study, options.output)
    except (OSError, ValueError) as error:
        print("Archive failed: " + str(error), file=sys.stderr)
        return 1
    print(json.dumps({key: manifest[key] for key in ("archive", "archiveBytes", "archiveSha256", "fileCount",
        "publicationReady", "authoritativeMachinePathFindings", "externalEnvelopePathFindings")}, indent=2))
    print(json.dumps(manifest["completeness"], indent=2))
    return 0 if manifest["publicationReady"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
