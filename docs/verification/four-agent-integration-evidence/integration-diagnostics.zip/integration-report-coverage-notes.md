# 四人集成报告：证据覆盖审计备注

- 审计对象：任务 [验证四人跨日与读档恢复](https://github.com/qinjunw/CozyTown/issues/55)，冻结计划 `docs/verification/four-agent-integration-plan-2026-09-20.md`。
- 检出版本：`19dff35147fbb7f8debc3aa0f98da44a29b5b52d`。固定通过批次代码版本：`7ac7240963f113b54f30229c1ef929e0bbceac5d`。
- 本次仅核对公开计划、任务要求、证据清单、XML、固定归档摘要及测试断言。没有启动测试、Unity 或模型调用，没有读取正在运行的 Live 台词、评阅文件或私有凭据。本文件是报告准备资料，不是 Live 验收结论。

## 已核对的证据及来源约束

`docs/verification/four-agent-integration-evidence/tests/manifest.json` 中 15 份公开 XML 的 SHA-256 全部与磁盘内容一致。32 条 H01–H07 映射的每个 `selectedCases` 均能在所属 XML 按完整测试名找到唯一用例，结果全部为 `Passed`。32 条映射实际对应 **30 个唯一测试方法、60 个唯一参数化用例**；若保留跨 H 编号重复引用，则为 62 条用例映射。H03 重复引用矩阵方法，H07 重复引用阶段读档方法，不能重复计算成独立测试。

| 证据代号 | XML 或记录 | 可复用计数 | 源码归属 |
| --- | --- | --- | --- |
| P | `tests/xml/integration-full-play-fixed-b.xml` | 299 总计，294 通过，5 跳过，0 失败 | 清单登记 `7ac7240963f113b54f30229c1ef929e0bbceac5d`；运行身份由中央 Unity 执行者提供 |
| E | `tests/xml/integration-full-edit.xml` | 1106 总计，1105 通过，1 跳过，0 失败 | 清单 `sourceRevision=null`；历史工作树精确版本没有独立记录 |
| PR | `tests/xml/integration-physics-red.xml` | 1 失败 | `9737054...` 加未提交回归测试、尚无修复；不能写成某个完整已提交 SHA 的运行 |
| PG | `tests/xml/integration-physics-green.xml` | 12 通过 | 同一基础加未提交修复与回归；登记为实现等同 `7ac7240...`，不是该提交的直接运行 |
| FB | fixed-b 归档和清单 | 16/16 完成且严格 Replay；8/8 配对；224 固定客户端请求；40 已提交台词，0 缺证 | 批次计划登记 `7ac7240963f113b54f30229c1ef929e0bbceac5d` |
| FA | fixed-a 归档和清单 | 0/16 完成且严格 Replay；1 宿主失败、15 未开始；16 固定请求；4 已提交台词，0 缺证 | 批次计划登记 `9737054c9a0d7c84237439fe13ae36f704c0a43f` |

表中 `tests/` 相对证据目录。独立 `git diff 7ac7240... 19dff35... -- Assets Tools Packages ProjectSettings` 无差异，可以把 P/FB 称作同一代码与配置的固定验证；仍应保留各自实际运行 SHA。这个比较不能替 E 补出未知的历史检出版本。

两个 ZIP 的字节数与 SHA-256 均已重算，和归档清单一致：FA 为 105181 字节、`6ebaa5cb384a239fecf8bc1f95c71e513cca56c78b87c22131e8659235d31c81`；FB 为 2521052 字节、`d4162a141e440abf713c8163a942db7727284d3ec0d2047cb33b3257ded52542`。本次没有重新执行 ZIP 中的 Replay，也没有把归档清单本身当成新的运行。

Python 86 项通过来自固定证据 README 和任务进度，公开 XML 不含其执行结果。本次没有核对 Python 原始日志；最终报告应关联独立日志、摘要及源码身份，而非将其合并到 Unity XML 总数。

## H01–H07 的适用范围与 Live 待填项

### H01：四种资源初态与四人互动

固定内容测试核对四人唯一身份、种子 12345、第 1 天 12:00、两组覆盖四人的会面计划及资源条款。八个参数化用例覆盖四资源场景 × F/S；矩阵方法在实际开发场景运行八个世界、跨日并分别严格 Replay。FB 的协调入口另执行预登记 16 世界；它不是矩阵方法的 16 个参数化用例。

Live 报告须填原计划 16 世界的初始化状态、零调用握手、资源初态、8 个配对初态比较、两组会面实际结果。固定 `available` 完成交易不证明 Live 也交易；`buyer_poor`/`need_satisfied` 无资源会面是场景允许的结果。

### H02：8 次/分钟压力、2 个物理并发与恢复

四人压力测试在 F/S 各运行一次，明确观察共享窗口用尽、有等待居民、全部四人收到请求、最高在途 2、会面到期后释放活动和目标、窗口补充后继续派发，并核对每个 60 秒窗口不超过 8 次。其移动与到场为替身，本测试不能证明实际身体已经走回日程地点。单请求不合作超时与对话预算恢复分别补充槽位保留和排队恢复。

全部 H02 当前选定证据属于 E，源码 SHA 未知。需补冻结候选的 EditMode 运行，保留旧证据。本次 Live 的正常预算是 16 次/分钟，不能写成重复了 H02 的 8 次/分钟压力。Live 需按人列触发、派发、等待、结果和第二天获得处理的情况；有限两天结果不证明任意长期负载无饥饿。

### H03：跨午夜、晨间结算与第二天处理

实际场景测试明确核对第 2 天 00:00 时前日结算状态、05:00 的农田/牲畜结算日、晨间重复读档、16:00 时四人都有第二天结果、活动已释放、目标与日程一致且身体 `Arrived`。固定第二天邀约因移动造成 `agent.observation_stale` 是已验证的预期拒绝，保留第一天会面结果，不是第二天成功会面。

Live 需填每世界达到的游戏时刻、实际 901 次正常推进与连续双读档、午夜/晨间结算、四人第二天派发/拒绝/活动状态、终态身体目标和到达状态。不得用 `completed` 或 `replayPassed` 单独替代全部 NPC 结果。矩阵 `VerifyHost` 检查预算、守恒和四具唯一身体；逐人目标、活动和到达主要由 timeline/快照记录供报告核对。

### H04：七个会面阶段、重复/早档恢复

实际场景阶段测试覆盖 `idle`、`invited`、`scheduled`、`travelling`、`before_delivery`、`after_delivery`、`talking` 各保存并连续读取两次，核对世界、资产、人物/玩家身体、会面等恢复值和两次恢复的 JSON 一致性。之后回退交付前档，断言没有未来台词/交付经历、资产回到交付前，再执行新分支交付一次；回退 idle 后经历和会面清空、已用请求不退款。

阶段测试 `AssertSavedWorld` 不把 `completeWorld/decisions` 与原档逐字段比较；决策剩余期限、冷却、消费次数和物理槽位由 H05 及决策快照测试验证。因此不要只引用阶段测试便声称所有进程状态逐字节回滚。身份重建和实际请求账本本来也有不同的恢复合同。

Live 预登记只有 `origin`、`post_day1` 和两次读取后续跨日；要列实际自然到达的会面阶段，未到阶段写 `not_reached`。交付前后、闲置早档回退等额外状态由固定测试承担，不为剧情覆盖修改真实回复。

### H05：旧请求、期限/冷却、物理槽位和重配

异步集成测试在两个请求未完成时保存，核对剩余总期限 11 秒、剩余冷却 29 秒、已用一次调用、下一步 2；连续两次读档保留调用数与旧物理槽位，取消旧令牌，迟到邀约不写入新世界，再在新世界恢复决策，并新场景严格 Replay 且原客户端调用数不再增加。重配测试覆盖未完成/超时 Task 拒绝替换和完成后原滚动窗口仍生效。

其中 3 个细分决策快照方法只有 E 来源；补冻结候选 EditMode 后再明确它们的当前版本证据。Live 没有预登记人为重配或不合作请求故障；若实际没有迟到，不得报成真实迟到测试通过。Live 正常读档仍需核对账本单调不减、每世界物理并发与两次读取的世界代次，以及全部记录响应在独立 Replay 中一致。

### H06：迁移、无效输入、重建失败与发布恢复

P 中旧 schema 3 迁移测试核对初始玩家/人物日程、读档不改原文件版本、下一次保存变 schema 4 且记来源 3。最后身体准备失败保持原世界、时刻、位置和门禁；合法旧请求不会被未提交的失败恢复取消。发布失败分 core/presentation 两个参数化输入，报告已经提交的状态及现有恢复边界。E 的 10 种不完整新格式用例验证拒绝而非套旧格式默认值。

Live 矩阵不注入迁移和损坏输入；这些保持固定故障证据。不能声称 Live 16 世界覆盖了迁移矩阵。无效格式用例需要补当前 SHA 的 E 证据；任何实际宿主/初始化/导出/回放失败按原计划保留并停止后续付费世界。

### H07：活动窗口、一次纠正、事实权限和经历

选定测试验证超限时最多一次纠正且共用原预算/期限；迟到但合法的普通活动仍按已披露绝对窗口结束；暂停不推进活动期限。实际身体在和日程同目的地的情况下也需先证明 `ActiveActivity=null`，不能仅凭到达地点判断恢复。8 个事实选择用例覆盖不支持语义、私有值和缺失证据；参与者声明保留说话者与时间，不变成当前资产或第三人知识；H04 早档恢复补充未来经历回退。

H07 当前 7 条映射并不穷举任务 55 的普通活动输入。公开完整 XML 还有已通过的动态时限、会面后窗口、完整快照续接、实际观察位置/室内外、受控台词呈现等测试，见下节。Live 须报告实际期限拒绝/纠正/无响应/观察过期，人物上下文中的人设和本人经历以及按角色的可观察选择；不把宿主允许提交的 F 文本自动当作事实正确。

## 可补充引用的已有通过用例

以下名称均已从公开 XML 实际核对为 `Passed`。它们不属于上面 32 条既定映射，若加入最终表需标为补充证据，不悄悄改原映射计数。

| 方法 | 用例数 | 证据 | 补充覆盖 |
| --- | --- | --- | --- |
| `NpcActivityWindowDecisionTests.OrdinaryRequest_DisclosesTheCurrentFractionalAndAbsoluteWindow` | 3 | E | 不同日期和小数分钟的动态上限 |
| `NpcActivityWindowDecisionTests.InspectContinuation_WaitingForBudgetDisclosesTheRemainingWindowAtDispatch` | 1 | E | 等预算后的披露续步重新取剩余时限 |
| `NpcActivityWindowDecisionTests.Meeting_CrossesThePartnersScheduleAndReleasesIntoTheRemainingOrdinaryWindow` | 1 | E | 会面独立承诺结束后的普通窗口 |
| `NpcAgentWorldSnapshotTests.CaptureAndPrepare_RestoresActivityDeadlineAndEventsWithoutChangingLiveWorld` | 1 | E | 活动期限及待处理事件恢复 |
| `CompleteWorldSnapshotPlayModeTests.FixedInputsAfterRepeatedRestore_ProduceSameRequestsBodiesActivitiesAndResources` | 1 | P | 重复恢复后相同输入的请求、身体、活动和资产 |
| `NpcReconfigurationPlayModeTests.StartedSession_RejectsRelaxedLimitsWithoutReplacingTheClient` | 7 | P | 发起调用后七类预算限制不可放宽 |
| `NpcLocalObservationPlayModeTests.AdvancingWorldTime_ObservesCommittedPositionBeforeReachingTheDestination` | 1 | P | 观察使用身体当前位置 |
| `NpcLocalObservationPlayModeTests.LeavingHome_KeepsInteriorSpaceUntilTheBodyCrossesTheDoorway` | 1 | P | 出门前保留室内空间 |
| `NpcLocalObservationTests.ActualRegionAndDistance_DetermineNearbyObjects` | 1 | E | 区域与距离规则 |
| `NpcResourceScenarioPlayModeTests.StructuredSpeech_UsesSceneFactsForRenderedDialogueAndParticipantMemories` | 1 | P | S 经事实选择生成对话及参与者经历 |
| `NpcResourceScenarioPlayModeTests.UnknownSpeechFact_PreservesTheCandidateWithoutChangingDialogueMemoriesOrAssets` | 1 | P | 未知事实候选拒绝后状态不改变 |
| `AgentExperimentSessionPlayModeTests.WaitingBetweenInputs_PreservesPlayerPositionAcrossLoadsAndStrictReplay` | 1 | P | 物理帧等待、双读档与 origin 严格回放的回归 |

部分 C# 文件由 partial class 组成；XML 中的实际 fixture 为 `NpcResourceScenarioPlayModeTests`，不是文件名 `NpcResourceExpressionPlayModeTests`。最终报告按 XML fixture/方法名引用。

## Live 停止后报告仍须填的字段

| 任务要求 | 必须关联的最终记录 | 报告边界 |
| --- | --- | --- |
| 冻结与版本 | 首调用前登记、plan、实际 SHA、代码树相同证明、环境/干净检出/LFS、提示词与代理摘要、完整依赖及 Draft/未合并状态 | 请求型号与实际返回型号分列；没有依据时不推定别名对应同一版本 |
| 原始矩阵 | 16 预登记身份、F/S 各 8、场景/重复/组序、初始化/完成/中断/未开始、所有停止原因 | 保留原分母，固定替身和 Live 分开；不补跑替换失败 |
| 四人跨日 | 每世界/每人 D1/D2 触发、派发、等待、回退、行动和会面阶段，日程目标、活动释放、身体到达 | `meeting.accept_invite` 不是见面完成；`completed` 是实验脚本完成，不是全部会面完成 |
| 恢复与硬约束 | 双读档、结算、代次、资产、调用账本、物理槽位、严格 Replay、hostViolations 及具体来源 | 读早档的废弃未来资产不能与恢复分支相加；故障覆盖注明 fixed |
| 候选 | 全部逻辑决策数、首响应解析/宿主处理、一次纠正、披露续步、最终决策执行结果、无响应/取消 | 不将 `step>1` 全算纠正；保留没有 outcome 的决策；每逻辑决策成功至多一次 |
| 时间与成本 | 真实尝试、实际响应、宿主请求、Token 已知/未知、失败/纠正消耗、请求/宿主等待/整决策计时边界及分位数 | 缺字段记未知；预算等待不能从离散 progress 冒充精确时长；无价格依据不折货币 |
| 逐条表达 | accepted `meeting.say` 与全部采集行一一对应，missingReason、可评阅事实 N、明确问题/歧义、输出去重计数 | F/S 分列；主表与保守并集同一 N；角色缺证却作断言仍纳入 N；缺评阅记录才排除 |
| 评阅过程 | 两名代理的全量覆盖、独立原始结果、身份/版本未知、分歧和裁决、盲评限制、最终 ID 联集等于采样全集 | 此审计未读取台词与评阅，不代替独立判定或裁决 |
| 有效信息与人物 | 相关性、信息增量、合理未知/可答却拒答、逐字/语义重复、人物配置支持/冲突/证据不足 | 本批 question=null、targets=[]；固定问答目标覆盖率不适用 |
| 可复查交付 | 完整归档、包/Replay 字节保真清单、XML/日志/摘要哈希、失败过程、统计脚本版本 | 正式归档与最终统计在批次停止后生成；publicationReady 不等同于实验通过 |

## 验收缺口及处理顺序

1. **明确的源码归属缺口：** E 的测试已通过，但历史精确 SHA 未知，尤其 H02 全部依赖 E。中央执行者已确认在整个 Live 停止并清理后，在冻结候选补一次零真实调用的 EditMode；新旧结果并存，不改写旧清单。该补跑用于证据身份，不是当前发现了功能失败。
2. **尚待完成的验收：** 最终 Live 状态、16 世界/8 配对数据、独立 Replay、费用/候选/延迟、全量双评阅及裁决尚待主流程汇总。本文件不能据固定结果把 55 关单。
3. **映射表覆盖不等于逐项结论：** H07 动态上限、会面后普通活动、存档续接，H05 预算只能收紧，需引上述补充用例及各自源版本。源码里存在方法不能替代 XML 通过证据；本备注已区分两者。
4. **观测粒度限制：** timeline 提供逐 Tick 状态和部分触发，不必然记录每个进入/离开预算等待的精确事件。无法确定的连续时长应记未知。没有逐帧画面证据时，只声称台词来自已提交 transcript。
5. **有限样本限制：** 两个游戏日、每种资源场景两次 F/S 配对能验证本批行为与恢复，不能估计长期可靠率或证明任意互动组合；本批固定的两对互动覆盖四人，不是所有六种两两组合。

本次只提出证据归属和报告范围事项；未对已观察不到的 Live 结果做通过/失败判断。后继任务 96 的干净候选交付验收仍独立执行。

## 附：既有 32 条测试映射

<!-- 表格由已校验的 manifest 生成；E/P 的来源定义见前文。 -->

| 编号 | Fixture.方法 | 已通过参数化用例 | 所选证据 |
| --- | --- | --- | --- |
| H01 | `AgentExperimentContentTests.AvailableConfiguration_RegistersFourResidentsAndTwoIndependentMeetings` | 1 | E |
| H01 | `AgentExperimentContentTests.FixedClient_DrivesAllFourResidentsThroughSocialAndResourceMeetings` | 8 | E |
| H01 | `AgentIntegrationMatrixPlayModeTests.FixedScript_RunsBothArmsOfAllResourceCasesAcrossDaysAndReplaysEachWorld` | 1 | P |
| H02 | `AgentExperimentContentTests.FourResidents_SharingEightRequestsPerMinute_WaitExpireAndResumeWithoutLeakingActivities` | 2 | E |
| H02 | `NpcDecisionSchedulerTests.Timeout_KeepsTheActualRequestSlotUntilAnUncooperativeClientFinishes` | 1 | E |
| H02 | `NpcConversationBudgetTests.QueuedConversationTurn_ResumesAfterBudgetReturnsAndCompletesBeforeMeetingDeadline` | 1 | E |
| H03 | `AgentIntegrationSnapshotPlayModeTests.FourResidents_AfterMidnightAndMorningSettlementContinueOnTheSecondDay` | 1 | P |
| H03 | `AgentIntegrationMatrixPlayModeTests.FixedScript_RunsBothArmsOfAllResourceCasesAcrossDaysAndReplaysEachWorld` | 1 | P |
| H04 | `AgentIntegrationSnapshotPlayModeTests.FourResidents_RepeatedPhaseLoadsRestoreCommitmentsAndDiscardFutureExperience` | 1 | P |
| H04 | `CompleteWorldSnapshotPlayModeTests.SaveLoad_RestoresFourActualJourneysPlayerAndFractionalMinuteWithoutReplayingMovement` | 1 | P |
| H04 | `CompleteWorldSnapshotPlayModeTests.ResourceConversation_LoadRestoresAcceptedBodiesAndDeliveredPendingTurnWithoutRepeatingTradeOrFutureBubble` | 1 | P |
| H04 | `NpcMeetingBoardSnapshotTests.MeetingPhases_ResumeFromSavedCommitmentAndDiscardFutureHistory` | 4 | E |
| H05 | `AgentIntegrationSnapshotPlayModeTests.PendingCalls_AfterTimedSavesAndRepeatedLoadsRejectLateRepliesAndReplayTheCompletePackage` | 1 | P |
| H05 | `NpcDecisionSnapshotTests.FirstCallInFlight_RestoreConsumesItsAttemptAndRetainsTheOldPhysicalSlot` | 1 | E |
| H05 | `NpcDecisionSnapshotTests.EarlierSnapshot_RestoresLogicalCooldownWhilePreservingFutureActualCalls` | 1 | E |
| H05 | `NpcDecisionSnapshotTests.ResumedDecision_UsesOnlyItsSavedRemainingTotalTimeWithoutASecondCooldown` | 1 | E |
| H05 | `NpcBindingPlayModeTests.RepeatedSuccessfulLoad_RebuildsBodiesAndRejectsEachPreviousTimelineReply` | 1 | P |
| H05 | `NpcReconfigurationPlayModeTests.UnfinishedRequest_RejectsReplacementUntilTheTaskEnds` | 2 | P |
| H05 | `NpcReconfigurationPlayModeTests.CompletedRequest_ReconfigurationKeepsTheOriginalCallWindow` | 1 | P |
| H05 | `DaytimeClockPlayModeTests.ModalAndFocusPause_RequireBothReasonsToClearBeforeClockResumes` | 1 | P |
| H06 | `CompleteWorldSnapshotPlayModeTests.LegacySnapshot_RebuildsSchedulesAndInitialPlayerThenRecordsMigrationOnNextSave` | 1 | P |
| H06 | `CompleteWorldSnapshotPlayModeTests.LastBodyPreparationFailure_KeepsLiveWorldAndModalUntilValidLoadCommits` | 1 | P |
| H06 | `CompleteWorldSnapshotPlayModeTests.FailedLastBodyPreparation_DoesNotCancelStillLegalModelRequest` | 1 | P |
| H06 | `CompleteWorldSnapshotPlayModeTests.PublicationFailure_ReportsCommittedStateAndPreservesExistingRecoveryBoundary` | 2 | P |
| H06 | `CompleteSnapshotStorageTests.IncompleteNewFormat_IsRejectedWithoutApplyingLegacyDefaults` | 10 | E |
| H07 | `NpcActivityWindowDecisionTests.DirectClient_ExceedingDisclosedDurationUsesOnlyOneCorrection` | 2 | E |
| H07 | `NpcActivityWindowDecisionTests.DurationCorrection_SharesTheRateBudgetAndOriginalDecisionTimeout` | 1 | E |
| H07 | `NpcActivityWindowPlayModeTests.DelayedVisit_ReleasesAtTheDisclosedWindowEvenWhenTheScheduleHasTheSameDestination` | 1 | P |
| H07 | `NpcActivityWindowPlayModeTests.ModalPause_PreservesTheOrdinaryActivityAndItsAbsoluteDeadline` | 1 | P |
| H07 | `NpcFactSpeechTests.FactSelection_RejectsUnsupportedMeaningPrivateValuesAndMissingEvidence` | 8 | E |
| H07 | `NpcLocalObservationTests.HeardStatements_KeepSpeakerAndTimeWithoutBecomingCurrentAssetsOrThirdPartyKnowledge` | 1 | E |
| H07 | `AgentIntegrationSnapshotPlayModeTests.FourResidents_RepeatedPhaseLoadsRestoreCommitmentsAndDiscardFutureExperience` | 1 | P |
