$ErrorActionPreference = 'Stop'
$recordPath = Join-Path $PSScriptRoot 'integration-power-request.json'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class IntegrationPowerRequest {
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern uint SetThreadExecutionState(uint flags);
}
'@
$requestFlags = [uint32]2147483649
$clearFlags = [uint32]2147483648
$previousState = [IntegrationPowerRequest]::SetThreadExecutionState($requestFlags)
if ($previousState -eq 0) { throw 'SetThreadExecutionState did not register the temporary system request.' }
$record = [ordered]@{ schemaVersion = 1; helperPid = $PID; startedAtUtc = [DateTime]::UtcNow.ToString('O'); systemRequired = $true; displayRequired = $false; persistentSettingsChanged = $false; watchedPids = @(75152, 83724); maximumSeconds = 3600; previousState = $previousState; releasedAtUtc = $null }
[IO.File]::WriteAllText($recordPath, ($record | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
$watch = [Diagnostics.Stopwatch]::StartNew()
try {
    while ($watch.Elapsed.TotalSeconds -lt 3600) {
        $running = @(Get-Process -Id 75152,83724 -ErrorAction SilentlyContinue)
        if ($running.Count -eq 0) { break }
        Start-Sleep -Seconds 10
    }
}
finally {
    [void][IntegrationPowerRequest]::SetThreadExecutionState($clearFlags)
    $record.systemRequired = $false
    $record.releasedAtUtc = [DateTime]::UtcNow.ToString('O')
    [IO.File]::WriteAllText($recordPath, ($record | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
}
