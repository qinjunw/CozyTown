"""Audit retained host evidence without executing Unity or a provider."""
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent
STUDY = ROOT / "integration-coordinated-live-20260920-a"
SHA = "19dff35147fbb7f8debc3aa0f98da44a29b5b52d"
NPCS = ["npc.shopkeeper_mina", "npc.farmer_eli", "npc.fisher_ren", "npc.cook_sora"]
inputs = {}


def load(path, lines=False):
    raw = path.read_bytes()
    inputs[str(path).replace("\\", "/")] = hashlib.sha256(raw).hexdigest()
    value = raw.decode("utf-8-sig")
    return [json.loads(line) for line in value.splitlines() if line.strip()] if lines else json.loads(value)


def asset(snapshot):
    rows = [row for row in snapshot["characters"] if row["characterId"].startswith("npc.")]
    return {"coins": sum(row["wallet"]["balance"] for row in rows),
        "carp": sum(item["quantity"] for row in rows for item in row["backpack"]["items"] if item["itemId"] == "fish.carp"),
        "byNpc": {row["characterId"]: {"coins": row["wallet"]["balance"],
            "carp": sum(item["quantity"] for item in row["backpack"]["items"] if item["itemId"] == "fish.carp")}
            for row in rows}}


def day(minutes):
    return "D" + str(int(minutes // 1440) + 1)


def normalized_snapshot(snapshot):
    value = deepcopy(snapshot)
    complete = value["completeWorld"]
    meetings, activities = {}, {}
    def replace(objects, key, table, kind):
        for row in objects:
            identity = row[key]
            if identity.replace("-", "") == "0" * 32:
                continue
            if identity not in table:
                table[identity] = f"{kind}:{len(table)}"
            row[key] = table[identity]
    meeting = complete["meetings"]
    for rows, key in [(meeting["meetings"], "id"), (meeting["latestResults"], "id"),
                      (meeting["latestByResident"], "meetingId"),
                      ([item for row in meeting["memories"] for item in row["memories"]], "meetingId")]:
        replace(rows, key, meetings, "meeting")
    for key in ("current", "pending", "waitingTurn"):
        replace([row[key] for row in complete["decisions"]["residents"] if row[key] is not None], "meetingId", meetings, "meeting")
    replace([row["activity"] for row in complete["world"]["residents"] if row["activity"] is not None], "activityId", activities, "activity")
    for key in ("initiatorActivityId", "partnerActivityId"):
        replace(meeting["meetings"], key, activities, "activity")
    return value


plan, status = load(STUDY / "plan.json"), load(STUDY / "status.json")
summary = load(ROOT / "live-final-summary.json")
candidate = load(ROOT / "live-final-candidate-metrics.json")
ledger = load(STUDY / "ledger.jsonl", True)
assert status["state"] == summary["study"]["state"] == candidate["study"]["state"] == "finished"
assert plan["sourceRevision"] == summary["study"]["sourceRevision"] == candidate["study"]["sourceRevision"] == SHA
assert len(plan["worlds"]) == len(summary["worlds"]) == len(candidate["worlds"]) == 16
assert not summary["warnings"] and not candidate["warnings"]
admissions = [row for row in ledger if row.get("event") == "provider_started"]
assert len(admissions) == status["attemptedProviderCalls"] == candidate["allProviderAttemptMetrics"]["attemptN"] == 244
world_rows, npc_rows, initial_by_pair, pair_rows, initial_run_ids = [], [], defaultdict(list), [], []
all_decision_ids = set()
for world in plan["worlds"]:
    ordinal, world_id = world["ordinal"], world["worldId"]
    directory = STUDY / f"{ordinal:02}-{world_id}"
    sm = next(row for row in summary["worlds"] if row["worldId"] == world_id)
    cm = next(row for row in candidate["worlds"] if row["worldId"] == world_id)
    initialized, result, initial = [load(directory / name) for name in ("initialized.json", "result.json", "initial.json")]
    manifest = load(directory / "package/manifest.json")
    terminal = load(directory / "package/final.json")
    checkpoint = load(directory / "package/checkpoint-post_day1.json")
    origin = load(directory / "package/checkpoint-origin.json")
    timeline = load(directory / "timeline.jsonl", True)
    assert initialized["initialized"] is True and result["initialized"] is True and sm["initialized"] is True
    assert result["status"] == sm["status"] and result["hostViolations"] == sm["hostViolations"] == []
    assert result["telemetryError"] == ""
    assert manifest["sourceRevision"] == SHA and manifest["runMode"] == "live"
    assert initial["clock"] == {"day": 1, "minuteOfDay": 720}
    assert initial == load(directory / "package/initial.json") == origin
    assert initial["schemaVersion"] == initial["sourceSchemaVersion"] == 4
    complete = initial["completeWorld"]
    for residents in (complete["world"]["residents"], complete["decisions"]["residents"], complete["residents"]):
        assert sorted(row["npcId"] for row in residents) == sorted(NPCS)
    assert all(row["activity"] is None for row in complete["world"]["residents"])
    assert not complete["meetings"]["meetings"] and not complete["meetings"]["memories"]
    assert all(row["current"] is None and row["pending"] is None and row["waitingTurn"] is None
        and row["remainingCooldownSeconds"] == 0 for row in complete["decisions"]["residents"])
    assert timeline[0]["requests"] == timeline[0]["inFlight"] == 0
    initial_run_ids.append(timeline[0]["worldRunId"])
    initial_by_pair[world["pairId"]].append((world, initial))
    calls = manifest["trace"]["calls"]
    requests = [json.loads(call["requestJson"]) for call in calls]
    outcomes = manifest["results"]
    attempts = [row for row in admissions if row["worldId"] == world_id]
    assert len(attempts) == len(calls) == sm["providerAttempts"] == result["hostRequests"] == sm["hostCalls"]
    ids = {row["decisionId"] for row in requests}
    assert ids == {row["decisionId"] for row in attempts} == {row["decisionId"] for row in outcomes}
    assert len(ids) == cm["metrics"]["initiatedDecisionN"]
    all_decision_ids.update((world_id, identity) for identity in ids)
    for npc in NPCS:
        published = next(row for row in sm["npcs"] if row["npcId"] == npc)
        first = {}
        for index in sorted(range(len(calls)), key=lambda index: calls[index]["callOrdinal"]):
            request = requests[index]
            if request["npcId"] == npc:
                first.setdefault(request["decisionId"], (index, request))
        for current_day in ("D1", "D2"):
            observed = published["days"][current_day]
            local_requests = [row for row in requests if row["npcId"] == npc and day(row["gameTotalMinutes"]) == current_day]
            local_first = [(index, row) for index, row in first.values() if day(row["gameTotalMinutes"]) == current_day]
            local_outcomes = [row for row in outcomes if row["npcId"] == npc and day(json.loads(row["requestJson"])["gameTotalMinutes"]) == current_day]
            triggers = Counter(kind for _, row in local_first for kind in set(trigger["kind"] for trigger in row["triggers"]))
            contexts = observed["firstRetainedRequestContexts"]
            assert observed["dispatches"] == len(local_requests) > 0
            assert observed["outcomes"] == len(local_outcomes)
            assert observed["outcomeCodes"] == dict(Counter(row["code"] for row in local_outcomes))
            assert contexts["dispatchedDecisionN"] == len(local_first)
            assert contexts["decisionsWithTriggerKind"] == dict(triggers)
            personas = {row["persona"] for _, row in local_first}
            assert set(contexts["persona"]["stringValues"]) == personas
            assert contexts["persona"]["nonemptyN"] == len(local_first) and all(persona.strip() for persona in personas)
            memory_sizes = [len(row["social"]["memories"]) for _, row in local_first]
            assert contexts["socialMemories"]["arrayKnownN"] == len(local_first)
            assert contexts["socialMemories"]["nonemptyN"] == sum(size > 0 for size in memory_sizes)
            assert contexts["socialMemories"]["maxCount"] == max(memory_sizes)
            day_samples = [row for row in timeline if day(row["gameMinutes"]) == current_day]
            assert observed["timelineStateObservations"]["rowN"] == len(day_samples)
            states = [next(row for row in sample["residents"] if row["npcId"] == npc) for sample in day_samples]
            flags = {flag: Counter(row[flag] for row in states) for flag in ("hasPending", "hasWaitingTurn", "hasCurrent")}
            for flag, counts in flags.items():
                assert observed["timelineStateObservations"][flag] == {"trueN": counts[True], "falseN": counts[False], "unknownN": 0}
            npc_rows.append({"ordinal": ordinal, "worldId": world_id, "npcId": npc, "day": current_day,
                "dispatchN": len(local_requests), "decisionContextN": len(local_first), "outcomeCodes": observed["outcomeCodes"],
                "decisionsWithTriggerKind": dict(triggers), "personaKnownNonemptyN": len(local_first),
                "socialMemoriesKnownN": len(memory_sizes), "socialMemoriesNonemptyN": sum(size > 0 for size in memory_sizes),
                "socialMemoriesMaxN": max(memory_sizes), "timelineN": len(day_samples),
                "timelineTrueCounts": {flag: counts[True] for flag, counts in flags.items()},
                "firstContextCallOrdinals": [calls[index]["callOrdinal"] for index, _ in local_first]})
    commands = [row for row in manifest["inputs"] if row["kind"] != "advance"]
    loads = [row for row in commands if row["kind"] == "load"]
    sleeps = [row for row in commands if row["kind"] == "sleep"]
    assert len(loads) == 2 and all(row["label"] == "post_day1" and row["worldBefore"] != row["worldAfter"] for row in loads)
    assert loads[0]["worldAfter"] == loads[1]["worldBefore"]
    assert len({loads[0]["worldBefore"], loads[0]["worldAfter"], loads[1]["worldAfter"]}) == 3
    assert [row["sleepMinutes"] for row in sleeps] == [720, 60]
    assert checkpoint["clock"] == {"day": 1, "minuteOfDay": 960}
    assert any(sample["gameMinutes"] == 1740 for sample in timeline)
    assert terminal["clock"]["day"] == 2
    assert terminal["farm"]["lastProcessedDay"] == terminal["livestock"]["lastProcessedDay"] == 2
    assert all(row["lastRestockedDay"] == 2 for row in terminal["shops"])
    assets = [asset(snapshot) for snapshot in (initial, checkpoint, terminal)]
    assert len({(row["coins"], row["carp"]) for row in assets}) == 1
    assert all(a["requests"] <= b["requests"] for a, b in zip(timeline, timeline[1:]))
    assert max(row["inFlight"] for row in timeline) == sm["maxObservedInFlight"] <= 2
    dispatch_times = [call["dispatchRealSeconds"] for call in calls]
    rolling = max(sum(start >= at - 60 and start <= at for start in dispatch_times) for at in dispatch_times)
    assert rolling <= 16 and len(attempts) <= world["maxProviderCalls"] == 32
    assert world["maxRealSeconds"] == 600
    schedules = {row["npcId"]: row for row in complete["world"]["schedules"]}
    final_bodies = []
    for body in terminal["completeWorld"]["residents"]:
        npc, route = body["npcId"], body["route"]
        active = next(row for row in terminal["completeWorld"]["world"]["residents"] if row["npcId"] == npc)["activity"]
        assert active is None
        assert route["targetLocationId"] == schedules[npc]["afternoonWorkLocationId"] and route["status"] == 1
        assert route["position"] == route["waypoints"][-1]
        assert not body["noLegalPosition"]
        final_bodies.append({"npcId": npc, "target": route["targetLocationId"], "position": route["position"],
            "routeStatus": route["status"], "activeActivity": active})
    replay_count = 0
    if result["status"] == "completed":
        assert result["replayPassed"] and manifest["completed"] and terminal["clock"]["minuteOfDay"] == 960
        replay = load(directory / "replay/manifest.json")
        assert replay["runMode"] == "replay" and replay["completed"] and replay["derivedFromExperimentId"] == manifest["experimentId"]
        for name in ("initial.json", "checkpoint-origin.json", "checkpoint-post_day1.json", "final.json"):
            left, right = load(directory / "package" / name), load(directory / "replay" / name)
            assert normalized_snapshot(left) == normalized_snapshot(right), (ordinal, name)
            replay_count += 1
    else:
        assert ordinal == 12 and not result["replayPassed"] and not manifest["completed"]
        assert not (directory / "replay").exists()
        assert terminal["clock"]["minuteOfDay"] == 913
    releases = [row for npc in sm["npcs"] for row in npc["activityReleaseSamples"]]
    world_rows.append({"ordinal": ordinal, "worldId": world_id, "scenarioId": world["scenarioId"], "arm": world["speechMode"],
        "status": result["status"], "initialized": True, "attemptN": len(attempts), "decisionN": len(ids),
        "gameMinutes": result["completedGameMinutes"], "realSeconds": result["realSeconds"], "hostViolationN": 0,
        "loadInputs": loads, "sleepInputs": sleeps, "finalSettlementDays": {"farm": terminal["farm"]["lastProcessedDay"],
            "livestock": terminal["livestock"]["lastProcessedDay"], "shops": [row["lastRestockedDay"] for row in terminal["shops"]]},
        "assetsInitialCheckpointFinal": assets, "finalBodies": final_bodies, "timelineN": len(timeline),
        "timelineMaxInFlight": max(row["inFlight"] for row in timeline), "retainedDispatchRolling60SecondsMax": rolling,
        "activityReleaseSampleN": len(releases), "releaseSamplePriorActivityCounts": dict(Counter(row["previousActivity"] for row in releases)),
        "releaseSamplesSameGeneration": all(row["sameWorldRun"] for row in releases),
        "replayStatus": "passed" if replay_count else "not_run_incomplete", "replaySnapshotComparisons": replay_count})

assert len(set(initial_run_ids)) == 16 and len(all_decision_ids) == 243
assert len(initial_by_pair) == 8
for pair_id, arms in initial_by_pair.items():
    assert len(arms) == 2 and {world["speechMode"] for world, _ in arms} == {"F", "S"}
    left, right = deepcopy(arms[0][1]), deepcopy(arms[1][1])
    left["completeWorld"]["decisions"]["speechMode"] = right["completeWorld"]["decisions"]["speechMode"] = "paired"
    assert left == right
    pair = next(row for row in summary["pairs"] if row["pairId"] == pair_id)
    report = load(STUDY / pair["reportPath"])
    assert report == pair["report"] and report["comparedRecordedPrefix"]
    assert report["firstDivergence"] is not None
    pair_rows.append({"pairId": pair_id, "worldOrdinals": [world["ordinal"] for world, _ in arms],
        "scenarioId": arms[0][0]["scenarioId"], "repetition": arms[0][0]["repetition"],
        "initialSnapshotsEqualExceptSpeechMode": True, "firstContextDivergence": report["firstDivergence"]})

diagnostic = load(ROOT / "integration-generated-settings-diagnostic.json")
for name, key in [("integration-post-live-project-settings.asset", "postLiveSha256"),
                  ("integration-post-live-project-settings.patch", "patchSha256")]:
    raw = (ROOT / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == diagnostic[key]
    inputs[str(ROOT / name).replace("\\", "/")] = hashlib.sha256(raw).hexdigest()
committed = subprocess.check_output(["git", "show", SHA + ":ProjectSettings/ProjectSettings.asset"])
assert hashlib.sha256(committed).hexdigest() == diagnostic["committedSha256"]
live_preflight = load(ROOT / "integration-live-preflight-20260920-a.json")
edit_preflight = load(ROOT / "integration-frozen-edit-preflight.json")
assert live_preflight["sourceRevision"] == edit_preflight["sourceRevision"] == SHA
assert live_preflight["trackedWorktreeClean"] and edit_preflight["cleanCheckout"]
assert edit_preflight["liveProcessesAbsent"] and edit_preflight["providerCallsEnabled"] is False

output = {"scope": "Independent final host evidence audit; no speech adjudication, Unity execution or model requests.",
    "generatedAtUtc": datetime.now(timezone.utc).isoformat(), "sourceRevision": SHA,
    "worlds": world_rows, "pairs": pair_rows, "npcDayRows": npc_rows,
    "summary": {"plannedWorldN": 16, "initializedWorldN": 16, "independentInitialRuntimeIds": 16,
        "completedWorldN": 15, "incompleteWorldN": 1, "pairInitialComparisons": 8,
        "pairPrefixDivergences": 8, "providerAttempts": 244, "logicalDecisions": 243,
        "npcWorldDayCellsWithDispatch": len(npc_rows), "loadInputN": sum(len(row["loadInputs"]) for row in world_rows),
        "replayedWorldN": 15, "replaySnapshotComparisons": sum(row["replaySnapshotComparisons"] for row in world_rows),
        "finalBodiesAtAfternoonScheduleTarget": sum(len(row["finalBodies"]) for row in world_rows)},
    "inputSha256": inputs}
with (ROOT / "final-live-host-coverage-audit.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(output, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps(output["summary"]))
