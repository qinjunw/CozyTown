# 角色触发与上下文覆盖：离线统计补充

本次仅修改 ignored `summarize_integration.py` 的角色描述统计和缺失 timeline 的传递方式；未修改运行源码、原 study、盲评包或评阅输入。新增字段按每 NPC、每个游戏日提供，原有派发/结果/阶段与活动释放字段保留。

| 新增字段 | 判定口径与来源 |
| --- | --- |
| `firstRetainedRequestContexts.dispatchedDecisionN` | 同一 NPC、同一世界按非空 decisionId 去重，取最小 callOrdinal 的已保留请求；纠正/披露不重复计入。缺 ID 的每条 trace 独立保留。按该请求的 gameTotalMinutes 分到 D1/D2，而非按现实日期 |
| `decisionsWithTriggerKind` | 含某个 trigger kind 的已派发决策数。同一决策中的重复标签最多计一次，不是原始世界事件数量；一个决策可有多个标签，标签之和可大于决策数 |
| `persona` | 记录该批首上下文的精确字符串集合、已知/未知数和非空数；空字符串是已知空，缺失或类型错误为未知 |
| `socialMemories` | 对首上下文的 social.memories 数组记录已知/未知、非空数及最大条数。该字段不代表角色总记忆，也不声称模型实际使用了经历 |
| `sources` | 保留 traceCallIndex、callOrdinal、decisionId、worldRunId、step；traceCallIndex 指向所属 manifest.trace.calls，可复核源请求 |
| `timelineStateObservations` | 按 timeline 游戏日记录 hasPending、hasWaitingTurn、hasCurrent 的 true/false/unknown 次数，记录总行数、角色行数和首末样本位置；缺角色行或非布尔值为 unknown |

`step1N` 和 `resumedOrUnknownFirstStepN` 区分首次保留步骤是否为 1，避免把恢复后只剩 step 2 的请求当作完整首候选。即使同一 decisionId 的后续调用跨入第二天，上下文仍只在首次保留请求所属日计一次。

timeline 的位置采用从 0 开始的已解析记录序号，不是物理 JSONL 行号。读档前后可能在相同游戏时刻多次取样，这些都是实际保留的观察。hasPending 可能涉及冷却、并发或其他可执行条件；这些计数既不是唯一等待事件数，也不是精确预算等待时长。

未取得 trace/timeline 的世界在新增计数字段使用 null；已保留空列表则为已知 0。主汇总现在不再把缺失 timeline 提前转为空列表，世界和 NPC 的 timelineSamples 也保留 null。

## 核对结果

`audit_npc_context_summary.py` 对 fixed-b 全部 16 世界与 Live 已结束的前 8 世界进行独立计数，并逐 NPC/游戏日比较触发、人设、经历、来源索引及状态观察。读取后再次核对输入哈希稳定；结果保存为 `integration-npc-context-audit-data.json`。Live 部分仍只是固定的前八世界子集，不是整个 16 世界最终报告。

| 数据集 | 已核对世界 | 去重首上下文 | persona 已知且非空 | social.memories 已知 | social.memories 非空 |
| --- | ---: | ---: | ---: | ---: | ---: |
| fixed-b | 16 | 224 | 224/224 | 224/224 | 112/224 |
| Live 前 8 世界 | 8 | 123 | 123/123 | 123/123 | 65/123 |

各角色均有 D1/D2 的已派发上下文。具体 trigger 分布、人设原文、经历计数及状态采样次数保留在审计 JSON，不用非空率代替人物行为评价。Live 前八世界 124 次请求含一次纠正，去重后 123 个首上下文；该纠正没有重复增加触发标签。

fixed-b 的完整汇总入口也已运行，输出 `fixed-b-context-coverage-summary.json`，16/16 世界 completed、8/8 配对报告，warnings=0。原固定证据和旧摘要没有覆盖。

## 回归及工具版本

- `test_npc_context_summary.py`：8/8 通过，覆盖纠正不重复、重建后新身份跨日、空值/缺值、缺 timeline、缺角色行、缺 decisionId、恢复首步以及未开始世界的完整汇总。
- `test_candidate_metric_audit.py`：14/14 仍通过；该候选统计脚本导入相同 Evidence/解析依赖。
- `summarize_integration.py` SHA-256：`63f4e160977e4bae34fba2e9c90ec3f9ff5160794182434144a2dd64a5b66db7`。
- 候选统计脚本保持 `083ffb7881e821ab5abfa0aa47f4658a071c579eee6f61b19155bdce43a0e33e`。其依赖汇总模块已有新版本，因此新冻结清单 `integration-analysis-tools-freeze-v2.json` 保留两者及回归文件哈希；原冻结清单保留为历史记录。

上述验证只执行本地 Python 与原始文件读取；没有 Unity 或提供方调用。
