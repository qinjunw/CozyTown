# Live 最终宿主与角色证据审计

本审计读取已停止批次 `integration-coordinated-live-20260920-a`、`live-final-summary.json` 和 `live-final-candidate-metrics.json`，不读取台词判词，不执行 Unity、Replay 或模型请求。应用候选为 `19dff35147fbb7f8debc3aa0f98da44a29b5b52d`。复核脚本只写 ignored 输出，原始批次未修改。

**结论：两份最终摘要的宿主身份、世界状态、调用分母及角色上下文计数与本次核对的原始材料一致。** 16 个世界全部初始化；15 个完成并通过原运行中的严格 Replay；世界 12 保留 deadline incomplete，未执行 Replay。第二天四人均获得派发，但第二天多数决策因观察过期被拒绝，不能据此称四人都完成了第二天自主行动。本文件不作表达质量裁决，也不替代候选交付验收。

## 证据层次

| 项目 | 已验证事实 | 证据及限制 |
| --- | --- | --- |
| 原始矩阵 | 4 场景 × 2 重复 × F/S，16 世界、8 配对；F 为 7 completed + 1 incomplete，S 为 8 completed | plan、status、16 份 result；无替补世界 |
| 初始化 | 16/16 `initialized=true`；16 个不同初始运行身份；四人身体、逻辑居民与决策配置齐全；D1 12:00、零请求、零在途、空会面/经历/活动 | 原运行 `VerifyInitial` 的失败会阻止首个 tick；本次另核对 initial、origin 与 package/initial 完整 JSON 相等及上述字段 |
| 配对初态 | 8/8 完整初态只在 `completeWorld.decisions.speechMode` 不同 | 原运行 CompareInitial；本次按同一单字段规则独立完整 JSON 比较。不是只核对资产或种子 |
| 配对后续 | 8 份请求前缀报告齐全，8/8 均出现后续上下文分歧 | 首次分歧在调用序号 2、5 或 6；不能称 F/S 每句都拥有相同上下文 |
| 跨日及读档 | 16/16 保存 `post_day1`，随后两次加载，共 32 次 Load；每次更换世界代次；720、60 分钟两次 sleep 后进入 D2 05:00 | 原始 input 序列与时间线；读取早档后的旧分支不累计为现分支资产 |
| 结算 | 16 个终态的农田、畜牧 lastProcessedDay 及商店 lastRestockedDay 均为 2 | 原运行在跨日步骤直接断言时钟、农田、畜牧；商店日标记由本次终态快照另核对。完整结算机制仍引用固定测试 |
| 资产 | 16/16 初态、D1 检查点、终态的 NPC 金币与鲤鱼总量相同 | 原运行 VerifyHost 每个推进循环断言这两类总量；本次另核对保存快照。不泛称任意资源或商店补货均“总量不变” |
| 预算 | 244 条 provider_started = 244 条 trace = 244 宿主请求；243 个逻辑决策；每世界 13–19 次，均小于 32 | 账本、结果与候选摘要一致。原运行断言共享 16 次/分钟、2 在途且累计请求不回退；时间线在途峰值 2，按保留 dispatch 时间复算 60 秒窗口峰值 15 |
| 身体和活动 | 64/64 终态身体在各自下午日程目标，route.status=Arrived、坐标等于末路点、ActiveActivity=null、noLegalPosition=false | 16 世界 × 4 NPC 的保存状态；包括未完成世界 12 的 D2 15:13 终态。不宣称逐帧视觉已检验或每次活动都无延迟 |
| Replay | 15 已完成世界的原运行 Replay 通过；本次另比较 60 份快照：initial、origin、post_day1、final | 完整 JSON 比较仅按生产比较器规则规范化 meeting/activity 身份。原运行严格 Replay 还比较请求、结果、输入和终态；离线快照比较不冒充再次执行 Replay |
| 未完成 | 世界 12、seller_empty、重复 2、F，600.0012073 秒停于 D2 15:13，共 15 次调用 | `manifest.completed=false`，`replayPassed=false`，不存在 replay 目录。应标“未运行 Replay”，不是“Replay 失败”或“Replay 通过” |

原运行的 `CoordinatedMatrix_ExecutesOnlyRegisteredFreshWorlds` 在 XML 中为 1/1 Passed。这个结果说明协调测试按其停止/失败规则走完 16 个已登记世界，**不把允许保留的 deadline incomplete 转成 completed**。

四种初态的 NPC 资产总量分别为：available 金币 50/鲤鱼 2；seller_empty 为 50/0；buyer_poor 为 10/2；need_satisfied 为 50/3。实际资源交付 `meeting.deliver` 为 4 次，来自 4 个 available 世界。其余场景没有为了补齐交易而改写候选或追加世界。

## 四人 D1/D2 上下文与派发

以下按 16 个世界汇总。每个世界的每个 NPC 在 D1、D2 都至少有一条保留派发，共 128/128 个 NPC–世界–日组合。决策上下文按 decisionId 取首个保留请求；唯一一次纠正不重复计入上下文与触发分母。

| NPC | 日 | 派发数 | 首次决策上下文数 | 非空 social.memories 上下文数 | hasPending=true 采样数 | hasCurrent=true 采样数 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Mina | D1 | 50 | 49 | 33 | 285 | 105 |
| Mina | D2 | 16 | 16 | 16 | 0 | 30 |
| Eli | D1 | 61 | 61 | 45 | 1 | 126 |
| Eli | D2 | 16 | 16 | 0 | 0 | 31 |
| Ren | D1 | 24 | 24 | 15 | 25 | 47 |
| Ren | D2 | 16 | 16 | 4 | 16 | 32 |
| Sora | D1 | 37 | 37 | 13 | 221 | 76 |
| Sora | D2 | 24 | 24 | 3 | 159 | 47 |

所有 244 条实际请求的 persona 都非空且等于该角色初始配置；243 个首次决策上下文的人设和 social.memories 数组均已知，其中 129 个经历数组非空，最多 4 条。该证据证明字段进入请求，不能证明模型使用了全部经历或表现符合人设。social.memories 不是全部世界历史，已知空数组不记作缺证。

触发字段复核为**含该标签的已派发决策数**，同一决策可以含多个标签。详细逐世界/逐日数据及 callOrdinal 定位见 JSON。汇总为：

| NPC | D1 标签及决策数 | D2 标签及决策数 |
| --- | --- | --- |
| Mina | WorldRebuilt 16、SocialOpportunity 16、MeetingChanged 31、ScheduleChanged 2 | SocialOpportunity 16、ScheduleChanged 16 |
| Eli | WorldRebuilt 16、MeetingChanged 45 | ScheduleChanged 16 |
| Ren | MeetingChanged 15、ScheduleChanged 9 | ScheduleChanged 12、MeetingChanged 4 |
| Sora | SocialOpportunity 12、MeetingChanged 12、ScheduleChanged 13 | ScheduleChanged 16、SocialOpportunity 8 |

时间线全部 hasWaitingTurn 采样为 false。hasPending 可能涉及调度、冷却或等候，不能全部归因于预算不足；hasCurrent 表示当前决策状态，也不是提供方物理在途数。上述采样数不是独立等待次数，更不是等待时长。预算饱和/轮次等待续接/不合作客户端物理槽位的硬约束，应引用 H02、H05 固定故障测试；Live 的窗口峰值 15 未达到冻结的 16 次上限。

## 第二天行为与活动观察边界

D2 共 72 个逻辑决策：50 个 `agent.observation_stale`、2 个 `agent.response_invalid`，20 个属于宿主合法接受集合。其中 Mina 16/16 均为 observation_stale；Eli 为 14 次 observation_stale、2 次 response_invalid；Ren 为 12 次 observation_stale、4 次 decline_invite；Sora 为 8 次 observation_stale、4 次 invited、9 次 decision_wait、3 次 activity_accepted。

因此第二天派发覆盖成立，成功互动覆盖须按角色分开。合法 wait/decline 进入“宿主接受”集合，不等于会面完成、交换成功或人物质量合格。报告若要解释过期原因，应引用请求与执行观察差异的专项分析；本审计不据结果码猜测具体机制。

原始时间线独立复算出 45 次 hasActivity 从 true 到 false 的采样转换，全部发生在同一世界代次，前状态为 Resting 43 次、Working 2 次。此集合包含会面占用与普通活动，不可称为 45 次普通活动。实际接受普通活动只有 Sora 的 5 次 visit：世界 3 一次 45 分钟，世界 5 两次 30 分钟，世界 6、13 各一次 30 分钟。64 个终态都无活动占用且已到日程目标；精确到期释放、同目的地释放、暂停与恢复期限仍以 H07 故障/边界测试为硬证明。

会面阶段采样中，Mina/Eli 覆盖 Invited、Scheduled、Travelling、Talking、Completed、Expired；Ren/Sora 覆盖 Invited、Scheduled、Travelling、Talking、Completed、Declined。阶段出现是观测覆盖，不表示每个世界、每对人都经过全部阶段。全批身体采样为 Arrived 54,421、Travelling 3,119，没有采到 Blocked；不能将其外推为任意路线永不阻塞。

## 世界 12 与执行环境

`live-world12-deadline-diagnostic.json` 保留相邻推进采样间 166.0372891 秒间隔及与 Windows Modern Standby 事件重叠的诊断。可以写“时间间隔与待机事件重叠”；没有处理器调度追踪，不能把整段间隔精确归因于某一种执行状态。原 600 秒期限不变，世界未补跑；之后的临时防系统自动休眠请求属于运行环境干预，需与模型参数/预算不变同时披露。

`integration-generated-settings-diagnostic.json` 的 committed、postLive 与 patch 三个 SHA 已与 Git 对象和备份文件复核。Live 前 preflight 记录干净检出及 Assets/Tools/Packages/ProjectSettings 与已验证候选的 tree 等同；Live 结束后 Unity 自动序列化了 ProjectSettings，包括序列化版本升级、平台默认项/最低系统版本迁移以及测试 HTTP 配置。**不能写“全程所有文件字节未变”或“只发生格式变化”。**

适用措辞是：“检出源版本为 19d，执行期间没有应用、测试或工具源码修改；Unity 产生的工程设置改动另存原始备份及补丁，恢复 HEAD 后再从干净检出启动零提供方调用的 EditMode。”源码归属与运行环境生成文件分别记录。`integration-frozen-edit-preflight.json` 在 Live 进程结束后记录 cleanCheckout=true、providerCallsEnabled=false。原始补丁保留本地，公开文档宜列变更类别和哈希，不粘贴无关平台字段全文。

## 新 EditMode 对旧 H01–H07 映射的补证

新 `integration-frozen-edit.xml` 绑定 19d 源码，共 1,106 项：1,105 Passed、1 个显式 Live opt-in 跳过、0 Failed。XML 顶层 result 为 `Skipped:Ignored`；应报告计数，不写成 1,106 全通过。跳过项为 `NpcExpressionExperimentTests.LiveProxy_CompareEightFactCasesWithOneCallPerSample`，没有为本次补证新增模型调用。

按旧公开 manifest 的 selectedCases/fullname 逐项查询，新 XML 覆盖原先依赖 E 的 **14 条映射、14 个方法、42 个唯一参数化用例，全部 Passed**：

| H 编号 | 新 XML 逐名通过用例数 |
| --- | ---: |
| H01 | 9 |
| H02 | 4 |
| H04 | 4 |
| H05 | 3 |
| H06 | 10 |
| H07 | 12 |

H03 原映射不依赖 E。上述数值只是新 EditMode 对旧映射的补证子集，不改变原表整体 32 条映射/30 个方法/60 个唯一参数化用例。旧 E 的源码未知事实仍留在历史清单；现新增独立19d通过证据，关闭该验收来源缺口。`current-test-export/manifest.json` 的原始及公开 Live/EditMode XML SHA 均核对通过。

## 留给最终报告的限定与定位

- `hostViolations=[]` 的范围是实际执行的初始化、推进、资产/预算、导出和完成世界 Replay 断言；不是所有 H01–H07 场景都在 Live 注入过。
- 请求拒绝码不是人物已说出台词的事实裁决。F/S 表达正确性、双评阅与裁决由主流程另报，本审计不读取也不覆盖。
- 当前证据支持一次冻结矩阵的四人执行与恢复；不证明六种两两关系、长期行为质量、精确预算等待时长或逐帧视觉结果。
- 逐世界状态、资产、双 Load、身体及128行角色/日计数见 `final-live-host-coverage-audit.json`；独立复算释放、阶段与42条新 EditMode匹配见 `final-live-host-additional-audit.json`。第一份包含237个输入文件SHA；写出后复核未变化。
- 以上复核没有发现两份最终摘要与所查原始宿主数据的遗漏或计数矛盾；发现的是最终文稿需要明确保留的未完成状态、第二天过期结果及采样/硬断言边界。后继任务96仍需自己的候选入口验收。
