# 离线指标工具独立审查

日期：2026-09-20。结论针对下述冻结版本：发现 1 项 P1、1 项 P2，均能通过离线合成样本复现。现有 22 项测试全部通过；通过这些测试不能排除本文的两种缺证情形。主代理已收到发现并协调修复；本文不把后续修改视为已验证。

## 范围与依据

| 对象 | 本次审查版本 |
| --- | --- |
| `summarize_integration.py` | SHA-256 `63f4e160977e4bae34fba2e9c90ec3f9ff5160794182434144a2dd64a5b66db7` |
| `summarize_candidate_latency.py` | SHA-256 `083ffb7881e821ab5abfa0aa47f4658a071c579eee6f61b19155bdce43a0e33e` |
| 回归测试 | `test_npc_context_summary.py`、`test_candidate_metric_audit.py`，执行时共 22 项 |
| 指标合同 | `docs/verification/four-agent-integration-plan-2026-09-20.md`，主要依据第 7、8 节 |

采用 baseline 和 code-review 的规范、合同两个检查轴。此次审查对象是指定 SHA 的 ignored 文件，不是 Git 提交差异。技术文字依据任务提供的 AGENTS.md 规则逐句核对；本审查进程两次读取指定的 technical-writing-review/SKILL.md 均返回不存在，未声称读取该文件。

只运行 Python 离线检查。除本报告外，未持久写入审查结果；合成样本位于 ignored 临时目录并由测试清理。未修改工具、测试或 tracked 文件，未调用 Unity、提供方或其他 API，未读取凭据、台词评阅或 identity 文件。

## Standards

发现 1 项规范问题，与下面 F2 是同一根因，不重复计数：输入账本已明确缺证时，输出仍把剩余记录的 token 和时间样本当作完整分母。依据 baseline 的“明确假设”和“核验可观察结果”，以及报告规则对 measured results、explicit constraints 的要求，完整总量必须具备完整来源证明，或明确标记为部分观测。

没有发现需要单独登记的命名、重复代码或结构问题。本次未审查生产侧输入序列化器、调度器或日志写出实现，也未以代码风格推断宿主行为。

## Spec

### F1 — P1：只在提供方账本出现的已发起决策被排除出成功率分母

位置：`summarize_candidate_latency.py:234–250` 建立 `groups` 与 `outcome_groups`；`180–191` 据此生成 `initiatedDecisionN` 和两个 `OverAllInitiated` 比例。

合同第 8 节要求首候选通过率、最终决策成功率以“全部已发起逻辑决策”为分母；无响应仍须保留。当前分母只包含 trace 与 outcome 的决策身份并集。`provider_started` 已记录的独立决策即使有 proxy 记录，缺少 trace 和 outcome 时仍完全消失。

复现使用现有 `test_candidate_metric_audit` 的 fixture helper：

```python
first, req = call()
other = dict(req, decisionId="decision-missing-trace")
result = summarize_fixture(
    [first], [outcome("agent.decision_wait")], "live",
    [proxy_record(req), proxy_record(other)],
    [provider_event(req, 1), provider_event(other, 2)],
)
```

实际输出：提供方 `attemptN=2`，第二次 `traceMatch="missing"`；但 `initiatedDecisionN=1`、`finalHostAcceptedN=1`、`finalHostAcceptedOverAllInitiated=1.0`、`finalHostAcceptanceUnknownN=0`，且 `warnings=[]`。缺失决策也未进入整次决策时延的未知样本数。

这组证据至少证明两项不同决策已发起。应保留第二项为结果未知，得到 1/2；若其他缺证使完整逻辑分母无法建立，则必须标记分母不完整，不应将保留样本的比例标为 `OverAllInitiated`。加入账本身份时，同一决策的初次请求和纠正仍须合并，不能按尝试次数增加逻辑决策分母。

现有测试覆盖 outcome-only、取消无 outcome 和缺失身份，但未覆盖 provider-only 决策。建议回归测试同时断言决策分母、首候选/最终结果未知数，以及决策时延未知数。

### F2 — P2：部分损坏的账本被当作完整尝试分母，导致未知消耗和时间样本消失

位置：`summarize_integration.py:65–76` 的 `Evidence.load` 跳过无效 JSONL 行；`summarize_candidate_latency.py:222–233` 使用剩余提供方事件生成时间样本，`295–302` 使用事件数生成 token 总量和未知数。

合同第 8 节要求保留全部失败尝试、报告时间有效样本数并将缺少 token/时钟记为未知。当前只要 `ledger` 不为 `None`，工具就使用 `len(provider_events)` 作为完整分母，即使读取器已报告行损坏、协调器的尝试数也更大。

离线复现：建立已中止的单世界 fixture，协调器 `attemptedProviderCalls=2`；`ledger.jsonl` 第一行是完整的 `provider_started`，第二行是截断 JSON；第一条 proxy 记录含 `promptTokens=10`、`completionTokens=2`、`totalTokens=12`、`elapsedMilliseconds=10`。

实际输出：`providerAttemptsCoordinator=2`、`providerAttemptsLedger=1`、全尝试 `attemptN=1`。输入 token 输出 `applicableN=1`、`knownN=1`、`unknownN=0`、`total=10`；请求代理时延也输出 `applicableN=1`、`knownN=1`、`unknownN=0`。唯一警告为第二行 `invalid_json_line`，没有将完整总量降格为部分已知总量。

应保留来源计数差异，令无法恢复的尝试在相关指标中继续占据未知样本；不能从损坏账本得出完整 token 总量。对于没有可靠总数的情况，应将完整分母记为未知，同时保留已知记录数和已知部分总量。此问题也适用于语法正确但少了事件的账本，不能只根据 JSON 解析是否报错判断完整性。

现有测试覆盖 ledger 完全缺失，但未覆盖 ledger 部分缺失且协调器保留较大尝试数。建议分别覆盖截断行与有效行缺失两种情况。

## 已执行核验与限制

- `python -B -m unittest -v test_npc_context_summary test_candidate_metric_audit`：22 项通过，0 失败。
- 已停止的 fixed-b：先确认协调器状态为 `finished`，随后只读、内存中复算。原计划 16 个世界；保留逻辑决策 224，宿主接受 144、未接受 80，0 项最终结果未知。固定运行的时延值不能作为 Live 模型性能。
- Live 仅检查登记顺序前 8 个、且状态已为 `completed` 的 manifest 结构。各世界 trace 调用数依次为 19、19、15、15、15、15、13、13；未发现重复的 `(npcId, decisionId, step)` trace 签名。该检查没有评阅台词内容，也未生成 Live 全批汇总。
- 现有测试证明其构造样本中的取消、候选纠正、渐进披露、空值与未知值、NPC 首次保留上下文去重均符合测试预期。此次未发现这些路径的其他可复现问题；这不证明未观察到的输入或未来批次都正确。
- F1、F2 均由合成缺证样本触发。此次检查没有证明它们已经改变固定批次或 Live 前 8 个世界的实际结果。不能把修复前的缺证处理缺陷表述为已经发生的宿主违规或模型失败。

规范轴 1 项、合同轴 2 项；去重后为 2 项。规范轴最严重问题为缺证后仍报告完整总量；合同轴最严重问题为 provider-only 决策未进入已发起逻辑决策分母。
