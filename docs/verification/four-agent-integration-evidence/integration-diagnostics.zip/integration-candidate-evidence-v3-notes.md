# Offline candidate metrics: evidence denominator revision 3

This revision changes ignored analysis tools only. It does not change the frozen runtime, study files, experiment budget, or report adjudication. No Unity process or model request was started by these checks. The source study was still running when the completed first eight worlds were checked; these results are a prefix audit, not final study statistics.

## Decision identities

The logical decision denominator now joins nonempty decision IDs from retained host trace, outcomes, and durable `provider_started` records within each world. A provider admission without a host trace or outcome remains a decision with unknown host handling, final result, and decision latency. `providerEvidence` locates the corresponding world attempt details. A proxy candidate still does not establish host delivery.

The provider-only regression has one accepted traced decision and a second provider-only decision. It now produces two initiated decisions, one accepted decision, and a 0.5 observed acceptance proportion. Two admissions for one decision ID still produce one logical decision. Outcomes and trace entries sharing that ID do not add another decision.

Records without a valid decision ID remain separate source/index evidence groups. They may overlap an identified decision, so `initiatedDecisionN` and both total acceptance proportions are null. `identifiedDecisionN`, `unidentifiedEvidenceRecordN`, `decisionEvidenceGroupN`, and accepted counts among identified decisions remain available. The tool does not manufacture identities to fill a gap.

## Incomplete provider ledger

`providerEvidenceCoverage` retains visible admissions, the coordinator attempt count, their signed difference, unmatched coordinator attempts, ledger availability, and invalid-record warnings. Unreadable records or a mismatch make complete attempt and decision denominators unknown. `visibleAttemptN` remains a retained lower bound; `attemptN` becomes null. Continuation groups retain visible counts without allocating unknown attempts to a guessed group.

The regression with one visible admission, one truncated ledger line, and coordinator count two now records one visible attempt and one unmatched coordinator attempt. Proxy latency has two applicable samples, one known and one unknown. Known token usage remains a partial total of 10; the full total is null and one sample is unknown. Logical identity remains one known decision; its complete denominator and acceptance proportions are null. A non-object ledger record and a coordinator gap without a parser warning have separate regressions.

If the coordinator count is unavailable while the ledger is incomplete, full token and proxy-latency applicable/unknown counts are also null. Negative coordinator differences remain explicit mismatches. No coordinator difference is converted into a guessed logical decision.

## Verification

The candidate suite passed 20 tests; the unchanged NPC context suite passed 8 tests. Logs are `integration-candidate-tests-v3.log` and `integration-npc-context-tests-v3.log`.

`audit_candidate_first8_v3.py` read the completed world artifacts and exercised the summary through isolated one-world temporary fixtures. Only each fixture's external world key and terminal coordinator wrapper changed; retained request identities, trace entries, outcomes, proxy records, and provider entries came from the original completed world. Original files were read only, and stable input hashes were checked again after reading. The fixture wrappers are not new experiments.

The first-eight-world results remain 123 logical decisions and 124 provider attempts. First host handling is 80 accepted, 42 rejected, and one no-response; final host acceptance is 81. All 124 retained candidates parse as JSON objects; protocol validation passes 121 and rejects 3. Continuations are 123 initial attempts and one candidate correction, with no progressive-disclosure or unknown continuation. All first-eight-world IDs join across ledger, trace, and outcomes; there are no provider-only or outcome-only decisions and no denominator gaps in this prefix.

The per-world metrics, input hashes, and tool SHA are retained in `integration-candidate-first8-v3-audit.json`. `integration-analysis-tools-freeze-v3.json` freezes this revision and supersedes the v2 tool manifest; the earlier evidence and freeze files remain unchanged.
